#锁定值
function lock_value(){
local val="$1"
local file="$2"
chmod 0777 "$file" 2>/dev/null
	echo "$val" > "$file"
chmod 0444 "$file" 2>/dev/null
}


#mount --bind 对应值
function mount_hide_val() {
local file="${1}"
local hide_value="${2}"
local tmp_file="/dev/Aloazny${file}"
if [ -e "${file}" ]; then
	umount "${file}" 2>/dev/null
		[[ ! -f "$tmp_file" ]] && mkdir -p "${tmp_file%/*}" && cp -af "${file}" "${tmp_file}" 2>/dev/null
    	if [[ "${hide_value}" != "" ]];then
    		chmod 0777 "${file}" 2>/dev/null 
    		chmod 0777 "${tmp_file}" 2>/dev/null 
				echo "${hide_value}" > "${tmp_file}"
				echo "${hide_value}" > "${file}"
			chmod 0444 "${tmp_file}" 2>/dev/null 
			chmod 0444 "${file}" 2>/dev/null
    	fi
	mount --bind "${tmp_file}" "${file}"
fi
}

#禁用某些服务
function disable_some_service(){
local msm_irqbalance_service="vendor.${1}"
[ "$(getprop init.svc.$msm_irqbalance_service)" = "" ] && msm_irqbalance_service=$(getprop | sed -E "/init\.svc\.(system|vendor|odm|product|system_ext|my_product)\.${1}/!d; {s/(.*)(init\.svc)\.(.*${1})(\].*)/\3/g}" )
[ "${msm_irqbalance_service}" = "" ] && echo "- 未找到${1}服务" && return 0

if [[ "$(getprop init.svc.$msm_irqbalance_service )" != "stopped" ]];then
	setprop ctl.stop $msm_irqbalance_service >/dev/null 2>&1
	setprop init.svc.$msm_irqbalance_service stopped >/dev/null 2>&1
	stop $msm_irqbalance_service >/dev/null 2>&1
fi
}

#转换CPU掩码
function cpus_to_hex() {
local cpus="$1"
local mask=0
for item in $(echo "$cpus" | tr ',' ' '); do
if echo "$item" | grep -q '-'; then
	start=$(echo "$item" | cut -d'-' -f1)
	end=$(echo "$item" | cut -d'-' -f2)
	for i in $(seq $start $end)
	do
		mask=$((mask | (1 << i)))
	done
else
	mask=$((mask | (1 << item)))
fi
done
    printf "%x\n" $mask
}

#控制内存管理
function Memory_control(){
local architect=$(wc -w /sys/devices/system/cpu/cpufreq/*/related_cpus | sed -E 's/^[[:space:]]+//g;/total/d;s/(^[0-9]+)([[:space:]].*)/\1/g' | sed ':a;$!N;s/\n/+/g;ta;s/+$//g')
case "${architect}" in
4+3+1|4+4)
low_cpu="0-3"
middle_cpu="0-5"
heavy_cpu="4-6"
;;
3+4+1)
low_cpu="0-2"
middle_cpu="0-4"
heavy_cpu="3-6"
;;
2+3+2+1)
low_cpu="5-6,0-1"
middle_cpu="3-6"
heavy_cpu="2-4"
;;
6+2)
low_cpu="0-5"
middle_cpu="0-6"
heavy_cpu="4-6"
;;
*)
echo "- 未适配……"
return
;;
esac

if [ "${heavy_cpu}" != "" ];then
	local low_cpu_mask="$(cpus_to_hex "${low_cpu}")"
	local middle_cpu_mask="$(cpus_to_hex "${middle_cpu}")"
	local heavy_cpu_mask="$(cpus_to_hex "${heavy_cpu}")"
	pgrep "lmkd" | while read pid;do taskset -p "${low_cpu_mask}" "${pid}" ;done
	pgrep "kcompactd0" | while read pid;do taskset -p "${middle_cpu_mask}" "${pid}" ;done
	pgrep "kswapd0" | while read pid;do taskset -p "${heavy_cpu_mask}" "${pid}" ;done
fi

}

#保证最大核心
function lock_max_cpus(){
for core in /sys/devices/system/cpu/cpu*/core_ctl/need_cpus
do
	max_core=`cat ${core}`
	mount_hide_val "${core%/*}/max_cpus" "${max_core}" 
	mount_hide_val "${core%/*}/min_cpus" "${max_core}" 
	mount_hide_val "${core%/*}/enable" "0"
done
for core in /sys/devices/system/cpu/cpu*/online
do
	mount_hide_val "${core}" "1"
done
}

function lock_cpu_set_dir(){
local cpu_set_file="
/dev/cpuset/top-app/cpus
/dev/cpuset/foreground/cpus
/dev/cpuset/gamelite/cpus
/dev/cpuset/game/cpus
/dev/cpuset/rt/cpus
"
max_cpus=$(cat /sys/devices/system/cpu/present 2>/dev/null )
if [ "$(echo "${max_cpus}" | grep '[0-9]' )" != "" ];then
	for cpus in ${cpu_set_file}
	do
		mount_hide_val "${cpus}" "${max_cpus}" 
	done
fi
#rmdir /dev/cpuset/background/untrustedapp 2>/dev/null
#rmdir /dev/cpuset/foreground/boost 2>/dev/null
}

#来源于Scene
function disable_miui_migt(){
local migt=/sys/module/migt/parameters
local glk=/proc/sys/glk
local proc_migt=/proc/sys/migt
local sched_walt_migt=/sys/module/sched_walt/holders/migt/parameters
local metis_path=/sys/module/metis/parameters

    for i in $migt/*reset* $metis_path/*reset*
 	  do
  		echo "1" > "${i}"
  	done
  	
    for i in $metis_path/*enable $metis_path/cluaff_control $migt/*enable $migt/cluaff_control $migt/enable_pkg_monitor $metis_path/enable_pkg_monitor $metis_path/*affinity* $migt/*add_*
 	  do
  		lock_value "0" "${i}"
   done
  	
  if [[ -d $migt ]]; then
    mount_hide_val $migt/glk_freq_limit_start '0'
    mount_hide_val $migt/glk_freq_limit_walt '0'
    lock_value 1 $migt/glk_disable
    lock_value 0 $migt/mi_freq_enable
    lock_value 0 $migt/force_stask_to_big
    lock_value 0 $migt/glk_fbreak_enable
    mount_hide_val $migt/enable_pkg_monitor '0'
    chmod 000 $migt/* 2>/dev/null
  fi

  if [[ -d $glk ]]; then
    mount_hide_val $glk/glk_disable '1'
    mount_hide_val $glk/freq_break_enable '0'
    mount_hide_val $glk/game_minfreq_limit '0 0 0'
    mount_hide_val $glk/game_maxfreq_limit '0 0 0'
    mount_hide_val $glk/game_lowspeed_load '30 30 30'
    mount_hide_val $glk/game_hispeed_load '80 80 80'
  fi
  
  if [[ -d $proc_migt ]]; then
    mount_hide_val $proc_migt/force_stask_tob '0'
    mount_hide_val $proc_migt/enable_pkg_monitor '0'
    mount_hide_val $proc_migt/boost_pid '0'
  fi
  
  if [[ -d $sched_walt_migt ]]; then
  	chmod 000 $sched_walt_migt/*
  fi
}

#禁用高通irqbalance服务
disable_some_service "tcpdump"
disable_some_service "cnss_diag"
disable_some_service "mm-pp-dpps"
disable_some_service "msm_irqbalance"
#锁定核心
lock_max_cpus
#禁用miui的migt
disable_miui_migt 2>/dev/null
#设置前台应用所有可用CPU
lock_cpu_set_dir
#设置内存管理进程
Memory_control

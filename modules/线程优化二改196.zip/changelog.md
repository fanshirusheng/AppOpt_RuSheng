### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)

### 更新日志
> 19.6
- 限制`增量更新`时，刷入时规则变动显示内容。
- 添加BanGdream(日服)匹配。
> 19.5
- 添加Github云更新地址。
### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**，例如我下载了`线程优化二改211.zip`刷入后，想要实现(取消)增量更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。

### 更新日志
> 22.0
- 添加QuickEdit(`com.rhmsoft.edit.pro`)适配。
- [1.3.5](https://aloazny.lanzouo.com/b00jeipeeb)和[实时模式](https://aloazny.lanzouo.com/b00jeku6cd)版本加入云更新。
- 添加哔哩哔哩动画线程。
> 21.9
- 添加Microsoft 365 (Office) (`com.microsoft.office.officehub`,`com.microsoft.office.officehubrow`)适配。
- 调整媒体存储设备。
> 21.8
- 尝试修改`AppOpt`的60秒过滤机制。
- 添加Bromite Webview (`org.bromite.webview`)适配。
- 调整KB视频工厂线程。
> 21.7
- 尝试修复`Android 15`报错，`AppOpt`意外退出，感谢酷友[Broneily](http://www.coolapk.com/u/24964487)测试。
- 添加WPS (`cn.wps.moffice_eng`)适配。
- 添加kazumi新版本一个`RenderThread`线程。
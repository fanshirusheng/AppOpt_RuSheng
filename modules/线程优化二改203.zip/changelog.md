### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)

### 更新日志
> 20.3
- 修正`program_ctrl.sh`对`oiface`的运行检测。
- 调整`Apple Music`线程和更新`Spotify`线程。
> 20.2
- 添加Lanerc(`com.xuzly.hy.lanerc.app`)，LX Music(`cn.toside.music.mobile`)适配。
- 调整**番茄小说**线程。
wait_sys_boot_completed() {
	local i=9
	until [ "$(getprop sys.boot_completed)" == "1" ] || [ $i -le 0 ]; do
		i=$((i-1))
		sleep 25s
	done
}
wait_sys_boot_completed

if [ -d "/data/adb/modules/AppOpt" ] && [ ! -f "/data/adb/modules/AppOpt/disable" ];then
    echo "
    - 您已选择 Suto 大佬的模块，该模块不会运行！
    "
    exit 0
fi

#杀死上次运行的程序
killall -15 AppOpt >/dev/null 2>&1
#尝试修复开机不自动执行
cd "${0%/*}"
chmod a+x "${0%/*}/AppOpt"
#配置文件路径
module_config="${0%/*}/applist.prop"
#日志文件路径
#不设置则指定为配置文件下同一目录的affinity_manager.log
log_file="${0%/*}/affinity_manager.log"
#如果不想记录日志文件建议加上参数`--debug=false`
#例如命令
#nohup "${0%/*}/AppOpt" --debug=false >/dev/null 2>&1 &
nohup "${0%/*}/AppOpt" -f "${module_config}" >/dev/null 2>&1 &

for MAX_CPUS in /sys/devices/system/cpu/cpu*/core_ctl/max_cpus; do
	if [ -e "$MAX_CPUS" ] && [ "$(cat $MAX_CPUS)" != "$(cat ${MAX_CPUS%/*}/min_cpus)" ]; then
		chmod a+w "${MAX_CPUS%/*}/min_cpus"
		echo "$(cat $MAX_CPUS)" > "${MAX_CPUS%/*}/min_cpus"
		chmod a-w "${MAX_CPUS%/*}/min_cpus"
	fi
done

# 默认暂停绿厂oiface，如需恢复请将下面0改成1并删除stop oiface这行
if [ -n "$(getprop persist.sys.oiface.enable)" ]; then
	setprop persist.sys.oiface.enable 0
	stop oiface
fi

[[ -f /data/adb/magisk/util_functions.sh ]] && . /data/adb/magisk/util_functions.sh
[[ ! -d "${MODPATH}" ]] && MODPATH="${0%/*}"
ui_print "" >/dev/null 2>&1 || alias ui_print="echo"
grep_prop >/dev/null 2>&1 || grep_prop() { local REGEX="s/^$1=//p"; shift; local FILES="${@:-/system/build.prop}"; for FILE in "${FILES[@]}"; do [ -f "$FILE" ] && cat "$FILE" 2>/dev/null | tr -d '\r' | sed -n "$REGEX" | head -n 1; done; }

function get_cpu_core_Info(){
ui_print "**************************************************"
ui_print "- CPU代号: $(getprop ro.board.platform)"
ui_print "- 核心信息:"
for i in /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq; do
freq=$(cat "$i")
core_relate_Info="$(cat "${i%/*}/related_cpus" | tr '[[:space:]]' '\n')"
if [ $(echo "${core_relate_Info}" | wc -l) = "1" ];then
	core="${core_relate_Info}"
else
	core_start="$(echo "${core_relate_Info}" | head -n 1)"
	core_end="$(echo "${core_relate_Info}" | tail -n 1)"
	core="${core_start}-${core_end}"
fi
ui_print "Core (${core}) ${i##*/}: $((freq / 1000)) MHz"
done | sort -n | uniq -c | sort -rn # | sed -E "s/^[[:space:]]+//g"
ui_print "**************************************************"
ui_print ""
}

function check_program_Running(){
local check_program=`pgrep -lf "AppOpt|CuDaemon|uperf" | sed -E 's/^(.*)/- \1/g' `
local check_program_count=`echo "${check_program}" | wc -l`
if [ "${check_program_count}" -gt "1" ];then
echo "
- 注意
- 可能有其他相同程序影响模块运行
${check_program}
"
fi
}

function get_other_module(){
for i in /data/adb/*modules/asoul_affinity_opt /data/adb/*modules/AppOpt_Aloazny /data/adb/*modules/AppOpt /data/adb/*modules/thread_opt
do
	description_file="${i}/module.prop"
	if [[ -f "${description_file}" ]] && [ ! -f "${i}/disable" ];then
		if [[ -f "${TMPDIR}/module.prop" ]];then
			module_own_id=$(grep_prop id "${TMPDIR}/module.prop" )
		else
			module_own_id=`readlink -f "${0%/*}"`
			module_own_id="${module_own_id##*/}"
		fi
	module_id=$(grep_prop id "${description_file}" )
	[ "${module_own_id}" = "${module_id}" ] && continue
	module_name=$(grep_prop name "${description_file}" )
	module_author=$(grep_prop author "${description_file}" )
	module_description=$(grep_prop description "${description_file}" )
	ui_print "
- 名称:${module_name}
- 作者:${module_author}
- 描述:${module_description}
- 路径:${i}"
	fi
done
}


function write_core_information(){
local module_config="${1}"
[[ ! -f "${module_config}" ]] && return 
local core_content="$(echo "$(get_cpu_core_Info)" | sed -E 's/^(.*)/#\1/g' )"
sed -E -i '/^\#[[:space:]]您的核心信息/,/^\#[[:space:]]END/d' "${module_config}"
local module_config_content="$(cat "${module_config}")"
cat << Aloazny > "${module_config}"
# 您的核心信息
${core_content}
# END
${module_config_content}
Aloazny
}

#再次抄袭10007代码
#获取magisk类型
function get_magisk_lite(){
local until_function=/data/adb/magisk/util_functions.sh
local Apatch_version=$(cat /data/adb/ap/version 2>/dev/null)
if [ "${Apatch_version}" != "" ];then
	echo "- 😥当前环境非Magisk……"
	echo "- 疑似Apatch◎${Apatch_version}……"
	return
fi
if grep -q lite_modules $until_function >/dev/null 2>&1 ;then
	echo "- 🌙当前为: Magisk Lite◎$MAGISK_VER_CODE"
else
	if [ "${MAGISK_VER_CODE}" = "" ];then
		echo "- 🤔当前环境非Magisk……"
	else
case "${MAGISK_VER}" in
*alpha)
	echo "- ☀当前为: Magisk Alpha◎$MAGISK_VER_CODE"
;;
*delta)
	echo "- ☀当前为: Magisk Delta◎$MAGISK_VER_CODE"
;;
*kitsune)
	local magisk_type="${MAGISK_VER%-*}"
	if [[ -n $(echo "${magisk_type}" | grep -E '[0-9]{2}\.[0-9]') ]] ;then
		echo "- ☀当前为: Kitsune Mask◎$MAGISK_VER_CODE"
	else
		echo "- ☀当前为: Kitsune Mask(${magisk_type})◎$MAGISK_VER_CODE"
	fi
;;
*-*)
	local magisk_others="$(echo "${MAGISK_VER##*-}" | tr '[:lower:]' '[:upper:]')"
	echo "- ☀当前为: Magisk ${magisk_others}◎$MAGISK_VER_CODE"
;;
*)
	echo "- ☀当前为: Magisk Official◎$MAGISK_VER_CODE"
;;
esac
	fi
fi
}

function Move_platform_bin(){
local platform="${ABI}"
[ ! -f "${TMPDIR}/module.prop" ] && return
[ "${platform}" = "" ] && platform="$(getprop ro.product.cpu.abi)"
[ "${platform}" = "" ] && platform="$(grep_prop ro.product.cpu.abi)"
if [ "${platform}" = "" ] ;then
	ui_print "- 无法获取您的设备架构"
	abort >/dev/null 2>&1
else
	local bin_file_name="AppOpt"
	local bin_file="${MODPATH}/bin/${platform}/${bin_file_name}"
	local bin_Info="$(file "${bin_file}" | sed "s|${bin_file}:||g" | tr ',' '\n' | sed -E 's/^(.*)/-\1/g' )"
	ui_print ""
	ui_print "**************************************************"
	ui_print "- 架构: ${bin_file##*/bin/} "
	ui_print "- 构建信息: 
${bin_Info} "
	cp -rf "${bin_file}" "${MODPATH}/${bin_file_name}"
	rm -rf "${MODPATH}/bin"
	ui_print "**************************************************"
	ui_print ""
fi
}

function get_other_thread(){
[[ -f "${1}" ]] && ui_print "- 检查可能的冲突……" || return
#查找Scene线程配置文件
local local_thread_config="$(grep -Ev '^[[:space:]]*$|#' "${1}" | sed 's/{.*//g;s/=.*//g;s/:.*//g' | sort -u)"
local package_config=`echo "${local_thread_config}" | tr '\n' '|' | sed -E 's/\|$//g' `
local scene_version=`dumpsys package com.omarea.vtools 2>/dev/null | grep -i "versioncode" | sed -E 's/.*=([0-9]{9,11}).*/\1/g'`
for i in /data/user/0/com.omarea.*/files/threads.json
do
	[ "${scene_version}" -gt "820250402" ] && ui_print "- Scene 版本: ${scene_version} " && break
	haspackage=$(grep -Eo "${package_config}" "${i}" | sed -E 's/^(.)/- \1/g')
	[[ "${haspackage}" != "" ]] && ui_print "- Scene核心分配找到和用户自定义重复的包名
- 请自行确认是否开启Scene的对应的核心配置开关(我太菜了，还没找到开关记录)。
${haspackage}"
done
#查找冲突模块
[[ "$(get_other_module)" != "" ]] && ui_print "
- 检测到可能冲突模块
- 确保不要重复配置应用$(get_other_module)"
get_other_module
[ "${haspackage}" = "" -a "$(get_other_module)" = "" -a "$(get_other_module)" = "" ] && ui_print "- 未找到对应模块冲突或者应用冲突……"
}

function get_app_cpu_Info(){
#检测代码来源于@coolapk 10007
[[ "${0##*/}" = "action.sh" ]] && ui_print "- 检测程序运行状况……" || return
local cpuinfo_show=`dumpsys cpuinfo | grep -Eo '[0-9]{1,3}(\.[0-9])?%[[:space:]]+[0-9]{1,6}\/AppOpt'`
local Check_cpuinfo="$(echo "${cpuinfo_show}" | sed -E 's|[[:space:]][0-9]{1,6}/AppOpt||g' )"
case "${Check_cpuinfo}" in
0.[0-9]%|0%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 正常……"
;;
[0-9]%|[0-9].[0-9]%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 占用过大！？
"
;;
[0-9][0-9]%|[0-9][0-9].[0-9]%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 异常占用！
- 建议反馈给开发者！
"
;;
[0-9][0-9][0-9]%|[0-9][0-9][0-9].[0-9]%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 核心爆炸了，哥们！
- 我给你重启了进程，3秒后再执行action(操作)查看吧……
"
[ -f "${0%/*}/service.sh" ] && nohup "${0%/*}/service.sh" >/dev/null 2>&1
;;
*)
if [ "$(pgrep -lf AppOpt | sed "/${0##*/}/d;/^[[:space:]]*$/d" )" != "" ];then
ui_print "- ●AppOpt●
- AppOpt进程正常运行……
- 命令行 `pgrep -lf AppOpt | sed "/${0##*/}/d;/^[[:space:]]*$/d"`
"
else
ui_print "- ●AppOpt●
- 未找到AppOpt进程……
"
fi
;;
esac
}
#查找错误日志
function show_error_log_content(){
local log_file="/data/adb/modules/AppOpt_Aloazny/affinity_manager.log"
if [[ ! -f "${log_file}" ]];then
	local cmd_content="$(pgrep -lf AppOpt )"
	log_file="$(echo "${cmd_content}" | grep -Eo "\-\-log=\/.*" | sed 's/--debug=.*//g;s/.*--log=//g' )"
	[ "${log_file}" = "" ] && log_file="$(echo "${cmd_content}" | grep -Eo "\-f /.*" | sed 's/--debug=.*//g;s/.*-f//g' )"
	[ ! -f "${log_file}" ] && return
fi
[ ! -f "${log_file}" -o "${0%##*/}" = "action.sh" ] && return
local error="$(grep -v '\[I\]' "$log_file" | sed '/^[[:space:]]*$/d' )"
if [[ "${error}" != "" ]];then
ui_print "
- 有错误日志输出
- 点击magisk右上角保存
- 在/sdcard/Download(/storage/emulated/0/Download/)目录能找到错误日志。
${error}
"
cp -af "${log_file}" "/storage/emulated/0/Download/AppOpt错误日志.log"
fi
}

function fix_applist_conf(){
local target_file="${1}"
[[ ! -f "$target_file" ]] && return
sed -E -i 's/^([^#a-zA-Z0-9.-]+)/#\1/g' "${target_file}"
sed -E -i 's/=([0-9]|[0-9]-?[0-9]?,[0-9]-?[0-9]?|[0-9]-[0-9])([^0-9]+)$/=\1/g' "${target_file}"
sed -E -i 's/(^[^#][^=]*$)/#\1/g' "${target_file}"
grep -E "(=|-|,)[0-9]{2,}" "${target_file}" | sed -E 's/(.*)=(.*)/核心配置貌似不对？内容:\1=\2/g;/^[[:space:]]*$/d'
grep -Ev '^[[:space:]]*$|^#' "${target_file}" | sed -E 's/=([0-9].*)/=/g' | uniq -d | while read -r same
do
	ui_print "- 检测到重复行……"
	ui_print "- 进程名称: ${same} : `grep -n "${same}" "${target_file}" | sed -E 's|([0-9]{1,3})\:(.*)|\1行|g;s/\|$//g' |  tr '\n' ' ' `"
done | sort -u 
}

#部分来源于coolapk@10007
ui_print ""
ui_print "**************************************************"
ui_print "－品牌: `getprop ro.product.brand`"
ui_print "－代号: `getprop ro.product.device`"
ui_print "－模型: `getprop ro.product.model`"
ui_print "－安卓版本: `getprop ro.build.version.release`"
test "`getprop ro.miui.ui.version.name`" != "" && ui_print "－MIUI版本: MIUI `getprop ro.miui.ui.version.name` - `getprop ro.build.version.incremental` "
ui_print "－内核版本: `uname -a `"
ui_print "－运存大小: `free -m|grep "Mem"|awk '{print $2}'`MB  已用:`free -m|grep "Mem"|awk '{print $3}'`MB  剩余:$((`free -m|grep "Mem"|awk '{print $2}'`-`free -m|grep "Mem"|awk '{print $3}'`))MB"
ui_print "－Swap大小: `free -m|grep "Swap"|awk '{print $2}'`MB  已用:`free -m|grep "Swap"|awk '{print $3}'`MB  剩余:`free -m|grep "Swap"|awk '{print $4}'`MB"
ui_print "**************************************************"
ui_print "- 模块信息:"
ui_print "$(get_magisk_lite)"
ui_print "- Module version: $(grep_prop version "${MODPATH}/module.prop")"
ui_print "- Module versionCode: $(grep_prop versionCode "${MODPATH}/module.prop")"
ui_print "- 描述: $(grep_prop description "${MODPATH}/module.prop")"
get_app_cpu_Info
get_cpu_core_Info
[[ -f "${TMPDIR}/module.prop" ]] && {
Aloazny_script_name="Aloazny.sh"
mv -f "$MODPATH/${Aloazny_script_name}" "$MODPATH/action.sh"
chmod +x "$MODPATH/action.sh"
cp -af "$MODPATH/action.sh" "/data/adb/modules/AppOpt_Aloazny/action.sh"
rm -rf "/data/adb/modules/AppOpt_Aloazny/${Aloazny_script_name}" "$MODPATH/${Aloazny_script_name}"
}
module_config_folder="/data/adb/modules/AppOpt_Aloazny"
original_module="/data/adb/modules/AppOpt"
[ ! -d "${module_config_folder}" ] && module_config_folder="$original_module"
module_config="${module_config_folder}/applist.conf"
[ ! -f "${module_config}" ] && module_config="${module_config%/*}/applist.prop"
if [ -f "$module_config" -a -f "${TMPDIR}/module.prop" ]; then
	test -d "${original_module}" -a ! -f "${original_module}/disable" && touch "${original_module}/disable"
	mv $MODPATH/${module_config##*/} $MODPATH/${module_config##*/}.bak
	cp -af "$module_config" "$MODPATH/${module_config##*/}"
	write_core_information "$MODPATH/${module_config##*/}"
	fix_applist_conf "$MODPATH/${module_config##*/}"
fi
fix_applist_conf "${module_config}"
get_other_thread "${module_config}"
write_core_information "${module_config}"
show_error_log_content
[[ -f "${TMPDIR}/module.prop" ]] && rm -rf "$MODPATH/源码" "$MODPATH/update.md" "$MODPATH/README.md" 
Move_platform_bin
wait_sys_boot_completed() {
	local i=9
	until [ "$(getprop sys.boot_completed)" == "1" ] || [ $i -le 0 ]; do
		i=$((i-1))
		sleep 25s
	done
}

function disable_msm_irqbalance(){
local msm_irqbalance_service="vendor.msm_irqbalance"
[ "$(getprop init.svc.$msm_irqbalance_service)" = "" ] && msm_irqbalance_service=$(getprop | sed -E '/init\.svc\.(system|vendor|odm|product|system_ext|my_product)\.msm_irqbalance/!d; {s/(.*)(init\.svc)\.(.*msm_irqbalance)(\].*)/\3/g}')
[ "${msm_irqbalance_service}" = "" ] && echo "- 未找到msm_irqbalance服务" && return 0

if [[ "$(getprop init.svc.$msm_irqbalance_service )" != "stopped" ]];then
	setprop ctl.stop $msm_irqbalance_service >/dev/null 2>&1
	setprop init.svc.$msm_irqbalance_service stopped >/dev/null 2>&1
	stop $msm_irqbalance_service >/dev/null 2>&1
fi
}

function lock_val(){
local val="${1}"
local file="${2}"
chmod 0755 "${file}" >/dev/null 2>&1
	echo "$val" > "${file}" >/dev/null 2>&1
chmod 0444 "${file}" >/dev/null 2>&1
}

function lock_max_cpus(){
for core in /sys/devices/system/cpu/cpu*/core_ctl/need_cpus
do
	max_core=`cat ${core}`
	lock_val "${max_core}" "${core%/*}/min_cpus"
	lock_val "${max_core}" "${core%/*}/max_cpus"
	lock_val "0" "${core%/*}/enable"
done
for core in /sys/devices/system/cpu/cpu*/online
do
	lock_val "1" "${core}"
done
}



wait_sys_boot_completed

if [ -d "/data/adb/modules/AppOpt" ] && [ ! -f "/data/adb/modules/AppOpt/disable" ];then
    echo "
    - 您已选择 Suto 大佬的模块，该模块不会运行！
    "
    exit 0
fi

#杀死上次运行的程序
killall -15 AppOpt >/dev/null 2>&1
#尝试修复开机不自动执行
cd "${0%/*}"
chmod a+x "${0%/*}/AppOpt"
#配置文件路径
module_config="${0%/*}/applist.prop"
#日志文件路径
#不设置则指定为配置文件下同一目录的affinity_manager.log
log_file="${0%/*}/affinity_manager.log"
#如果不想记录日志文件建议加上参数`--debug=false`
#例如命令
#nohup "${0%/*}/AppOpt" --debug=false >/dev/null 2>&1 &
nohup "${0%/*}/AppOpt" -f "${module_config}" >/dev/null 2>&1 &

#禁用msm_irqbalance服务
disable_msm_irqbalance

#锁定最大核心
lock_max_cpus


# 如需暂停绿厂oiface请将下面这行的#号注释删掉，恢复oiface则将0改成1
# [ -n "$(getprop persist.sys.oiface.enable)" ] && setprop persist.sys.oiface.enable 0

# 如需禁用米系机型joyose请将下面这行pm命令的 # 号注释删掉
# pm disable-user com.xiaomi.joyose; pm clear com.xiaomi.joyose
# 恢复 
# pm enable com.xiaomi.joyose


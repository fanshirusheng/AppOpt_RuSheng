### 感谢[@coolapk SutoLiu 大佬](https://www.coolapk1s.com/u/SutoLiu)
### 原模块地址: https://gitee.com/sutoliu/AppOpt
##### 二改模块日志
> 0.1
- 更改`module_id`为`AppOpt_Aloazny`。
- 更改配置文件`applist.conf`为`applist.prop`，**舒服我自己**用MT管理器查看配置文件有高亮。
- 更改`uninstall`的`setprop`为`resetprop`，避免卸载模块可能发生的开机阻塞。
- 添加一个shell脚本更正部分用户乱写的`applist.conf(applist.prop)`。
- 添加`日志记录`，去掉`dumpsys`获取屏幕状态。
> 0.2
- 加回`dumpsys`作为备选，获取屏幕状态。
- 添加`scene`核心分配名单检测(目前无法检测开关，因为我太菜)和其他核心模块检测。
> 0.3
- 在配置文件`applist.prop`中修改`Debug_AppOpt=false`能提升一些性能。
- 因为我不打游戏，所以如果发现有的线程生效不及时的话，可以选择自己编译一下源码，把`PROC_CACHE_TIME 30`里面的`30`改回`10`或者`15`，提升响应速度。
- 添加更多冲突模块检测。
> 0.4
- 添加`action.sh`按钮，能够输出模块的一些信息。
> 0.5
- copy了@coolapk 10007代码，添加magisk或者非ksu识别。
> 0.6
- 把核心信息写入配置文件`applist.prop`。

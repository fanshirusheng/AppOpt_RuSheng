[[ -f /data/adb/magisk/util_functions.sh ]] && . /data/adb/magisk/util_functions.sh
[[ ! -d "${MODPATH}" ]] && MODPATH="${0%/*}"
export PATH="${PATH}:/data/adb/magisk:/data/adb/ksu/bin:/data/adb/ap/bin"
awk --help >/dev/null 2>&1 || alias awk="busybox awk"
ui_print "" >/dev/null 2>&1 || alias ui_print="echo"
grep_prop >/dev/null 2>&1 || grep_prop() { local REGEX="s/^$1=//p"; shift; local FILES="${@:-/system/build.prop}"; for FILE in "${FILES[@]}"; do [ -f "$FILE" ] && cat "$FILE" 2>/dev/null | tr -d '\r' | sed -n "$REGEX" | head -n 1; done; }

function cpu_name_get(){
local cpuname="$(getprop ro.soc.model)"
[ "${cpuname}" = "" ] && cpuname="$(getprop | sed -E "/ro\.(system|vendor|product|odm|system_ext).*\.soc_model/!d;s/.*\]://g;s/\].*//g;s/.*\[//g" | head -n 1)"
[ "${cpuname}" = "" ] && cpuname="$(getprop ro.board.platform)"
[ "${cpuname}" = "" ] && cpuname="$(getprop | sed -E "/ro\.(system|vendor|product|odm|system_ext).*\.platform/!d;s/.*\]://g;s/\].*//g;s/.*\[//g" | head -n 1)"
[ "${cpuname}" != "" ] && echo "${cpuname}" || echo "未知"
}

function get_cpu_core_Info(){
local core_architect="$(wc -w /sys/devices/system/cpu/cpufreq/*/related_cpus | sed -E 's/^[[:space:]]+//g;s/(^[0-9]+) total/共\1个CPU核心/;s/(^[0-9]+)([[:space:]].*)/\1/g' | sed -E ':a;$!N;s/([0-9])\n/\1\+/g;ta;s/\+([^0-9])/ \1/g;s/^([0-9])/核心配置为: \1/g')"
ui_print "**************************************************"
ui_print "- CPU代号: $(cpu_name_get)"
ui_print "- 核心信息:"
ui_print "- ${core_architect} "
for i in /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq; do
freq=$(cat "$i")
core_relate_Info="$(cat "${i%/*}/related_cpus" | tr '[[:space:]]' '\n')"
if [ $(echo "${core_relate_Info}" | wc -l) = "1" ];then
	core="${core_relate_Info}"
else
	core_start="$(echo "${core_relate_Info}" | head -n 1)"
	core_end="$(echo "${core_relate_Info}" | tail -n 1)"
	core="${core_start}-${core_end}"
fi
ui_print "Core (${core}) ${i##*/}: $((freq / 1000)) MHz"
done | sort -n | uniq -c #| sort -rn  | sed -E "s/^[[:space:]]+//g"
ui_print "**************************************************"
ui_print ""
}

function check_program_Running(){
local check_program=`pgrep -lf "AppOpt|CuDaemon|uperf" | sed -E 's/^(.*)/- \1/g' `
local check_program_count=`echo "${check_program}" | wc -l`
if [ "${check_program_count}" -gt "1" ];then
echo "
- 注意
- 可能有其他相同程序影响模块运行
${check_program}
"
fi
}

function get_other_module(){
for i in /data/adb/*modules/asoul_affinity_opt /data/adb/*modules/AppOpt_Aloazny /data/adb/*modules/AppOpt /data/adb/*modules/thread_opt
do
	description_file="${i}/module.prop"
	if [[ -f "${description_file}" ]] && [ ! -f "${i}/disable" ];then
		if [[ -f "${TMPDIR}/module.prop" ]];then
			module_own_id=$(grep_prop id "${TMPDIR}/module.prop" )
		else
			module_own_id=`readlink -f "${0%/*}"`
			module_own_id="${module_own_id##*/}"
		fi
	module_id=$(grep_prop id "${description_file}" )
	[ "${module_own_id}" = "${module_id}" ] && continue
	module_name=$(grep_prop name "${description_file}" )
	module_author=$(grep_prop author "${description_file}" )
	module_description=$(grep_prop description "${description_file}" )
	ui_print "
- 名称:${module_name}
- 作者:${module_author}
- 描述:${module_description}
- 路径:${i}"
	fi
done
}


function write_core_information(){
local module_config="${1}"
[[ ! -f "${module_config}" ]] && return 
local core_content="$(echo "$(get_cpu_core_Info)" | sed -E 's/^(.*)/#\1/g' )"
sed -E -i '/^\#[[:space:]]您的核心信息/,/^\#[[:space:]]END/d' "${module_config}"
local module_config_content="$(cat "${module_config}")"
cat << Aloazny > "${module_config}"
# 您的核心信息
${core_content}
# END
${module_config_content}
Aloazny
}

function write_cpu_information_to_module_description(){
local file="${MODPATH}/module.prop"
[ ! -f "$file" ] && return
local architect=$(wc -w /sys/devices/system/cpu/cpufreq/*/related_cpus | sed -E 's/^[[:space:]]+//g;/total/d;s/(^[0-9]+)([[:space:]].*)/\1/g' | sed ':a;$!N;s/\n/+/g;ta;s/+$//g')
sed -i 's/当前处理器.*)，//g' "${file}"
sed -E -i "s/(description=)(.*)/\1当前处理器: [ $(cpu_name_get) ] (${architect})，\2/g" "${file}"
}

#再次抄袭10007代码
#获取magisk类型
function get_magisk_lite(){
local until_function=/data/adb/magisk/util_functions.sh
local Apatch_version=${APATCH_VER_CODE}
local Ksu_version=${KSU_KERNEL_VER_CODE}
if [ "${Apatch_version}" != "" ];then
	echo "- 😥当前环境非Magisk……"
	echo "- 疑似Apatch◎${Apatch_version}……"
	return
elif [ "${Ksu_version}" != "" ];then
	echo "- 😥当前环境非Magisk……"
	echo "- 疑似kernelsu◎${Ksu_version}……"
	return
fi
if grep -q lite_modules $until_function >/dev/null 2>&1 ;then
	echo "- 🌙当前为: Magisk Lite◎$MAGISK_VER_CODE"
else
	if [ "${MAGISK_VER_CODE}" = "" ];then
		echo "- 🤔当前环境非Magisk/Ksu/Apatch……"
	else
case "${MAGISK_VER}" in
*alpha)
	echo "- ☀当前为: Magisk Alpha◎$MAGISK_VER_CODE"
;;
*delta)
	echo "- ☀当前为: Magisk Delta◎$MAGISK_VER_CODE"
;;
*kitsune)
	local magisk_type="${MAGISK_VER%-*}"
	if [[ -n $(echo "${magisk_type}" | grep -E '[0-9]{2}\.[0-9]') ]] ;then
		echo "- ☀当前为: Kitsune Mask◎$MAGISK_VER_CODE"
	else
		echo "- ☀当前为: Kitsune Mask(${magisk_type})◎$MAGISK_VER_CODE"
	fi
;;
*-*)
	local magisk_others="$(echo "${MAGISK_VER##*-}" | tr '[:lower:]' '[:upper:]')"
	echo "- ☀当前为: Magisk ${magisk_others}◎$MAGISK_VER_CODE"
;;
*)
	echo "- ☀当前为: Magisk Official◎$MAGISK_VER_CODE"
;;
esac
	fi
fi
}

function Move_platform_bin(){
local platform="${ABI}"
[ ! -f "${TMPDIR}/module.prop" ] && return
[ "${platform}" = "" ] && platform="$(getprop ro.product.cpu.abi)"
[ "${platform}" = "" ] && platform="$(grep_prop ro.product.cpu.abi)"
if [ "${platform}" = "" ] ;then
	ui_print "- 无法获取您的设备架构"
	abort >/dev/null 2>&1
else
	local bin_file_name="AppOpt"
	local bin_file="${MODPATH}/bin/${platform}/${bin_file_name}"
	local bin_Info="$(file "${bin_file}" | sed "s|${bin_file}:||g" | tr ',' '\n' | sed -E 's/^(.*)/-\1/g' )"
	ui_print ""
	ui_print "**************************************************"
	ui_print "- 架构: ${bin_file##*/bin/} "
	ui_print "- 构建信息: 
${bin_Info} "
	cp -rf "${bin_file}" "${MODPATH}/${bin_file_name}"
	rm -rf "${MODPATH}/bin"
	ui_print "**************************************************"
	ui_print ""
fi
}

function get_other_thread(){
[[ -f "${1}" ]] && ui_print "- 检查可能的冲突……" || return
#查找Scene线程配置文件
local Asoul_package="
com.tencent.tmgp.gnyx
com.tencent.tmgp.dfjs
com.tencent.tmgp.WePop
com.tencent.tmgp.dwrg
com.tencent.tmgp.ffom
com.tencent.tmgp.kr.codm
com.tencent.tmgp.speedmobile
com.tencent.tmgp.pubgmhd
com.tencent.tmgp.yys.zqb
com.tencent.tmgp.wuxia
com.tencent.tmgp.sgame
com.tencent.tmgp.bh3
com.tencent.tmgp.cf
com.tencent.tmgp.dfm
com.tencent.tmgp.supercell.boombeach
com.tencent.tmgp.cod
com.tencent.KiHan
com.tencent.letsgo
com.tencent.ig
com.tencent.lolm
com.tencent.jkchess
com.tencent.nfsonline
com.tencent.tmgp.toaa
com.tencent.mf.uam
net.wargaming.wot.blitz
net.kdt.pojavlaunch
jp.co.craftegg.band
jp.co.bandainamcoent.BNEI0242
jp.konami.masterduel
jp.YoStarJP.MajSoul
jp.YoStarJP.BlueArchive
com.miHoYo.GenshinImpact
com.miHoYo.Yuanshen
com.miHoYo.hkrpg
com.miHoYo.ys
com.miHoYo.zenless
com.miHoYo.Nap
com.miHoYo.bh3
com.miHoYo.enterprise.NGHSoD
com.netease.party
com.netease.sky
com.netease.wyclx
com.netease.idv
com.netease.lglr
com.netease.hyxd
com.netease.race
com.netease.aceracer
com.netease.mrzh
com.netease.ko
com.netease.yhtj
com.netease.tj
com.netease.onmyoji
com.netease.eve.en
com.netease.EVE
com.netease.x19
com.netease.l22
com.netease.ma84
com.netease.moba
com.netease.AVALON
com.netease.jddsaef
com.netease.tom
com.bilibili.fatego
com.bilibili.heaven
com.bilibili.priconne
com.bilibili.azurlane
com.bilibili.deadcells.mobile
com.bilibili.warmsnow
com.bilibili.star.bili
com.ubisoft.rainbowsixmobile.r6.fps.pvp.shooter
com.roblox.client
com.modx.daluandou
com.kurogame.haru
com.kurogame.mingchao
com.kurogame.wutheringwaves.global
com.garena.game.kgtw
com.garena.game.codm
com.garena.game.nfsm
com.ea.games.r3_row
com.bandainamcogames.dbzdokkanww
com.bandainamcoent.shinycolorsprism
com.bandainamcoent.idolmaster_gakuen
com.bandainamcoent.sao
com.axlebolt.standoff2
com.activision.callofduty.warzone
com.activision.callofduty.shooter
com.nianticlabs.monsterhunter
com.blizzard.diablo.immortal
com.blizzard.wtcg.hearthstone
com.valvesoftware.cswgsm
com.valvesoftware.source
com.supercell.boombeach
supercell.brawlstars
supercell.clashofclans
supercell.squad
com.epicgames.fortnite
com.mojang.minecraftpe
com.playdigious.deadcells.mobile
com.tungsten.fcl
com.rayark.implosion
com.ilongyuan.implosion
com.prpr.musedash
com.tgc.sky.android
com.t2ksports.nba2k20and
com.and.games505.Terraria
com.xd.terraria
com.Shooter.ModernWarships
com.rekoo.pubgm
com.pubg.newstate
com.pubg.krmobile
com.pubg.imobile
com.vng.pubgmobile
com.aligames.kuang.kybc
com.ztgame.bob
com.ztgame.yyzy
com.minidragon.idlefantasy
com.fantablade.icey
com.xd.rotaeno.googleplay
com.CarXTech.highWay
com.gbits.funnyfighter.android.overseas
com.TechTreeGames.TheTower
com.ChillyRoom.DungeonShooter
com.nanostudios.games.twenty.minutes
com.madfingergames.legends
com.ignm.raspberrymash.jp
com.komoe.kmumamusumegp
com.gryphline.exastris.gp
com.Flanne.MinutesTillDawn.roguelike.shooting.gp
com.xd.dxlzz.taptap
com.halo.windf.hero
com.yongshi.tenojo
com.denchi.vtubestudio
com.r2games.myhero.bilibili
com.shenlan.m.reverse1999
com.dgames.g15002002
com.denachina.g13002010
com.sega.ColorfulStage.en
com.sega.pjsekai
com.dts.freefireth
com.sy.dldlhsdj
com.bushiroad.d4dj
com.bushiroad.lovelive.schoolidolfestival2
com.cnvcs.xiangqi
com.albiononline
com.the10tons.dysmantle
com.guyou.deadstrike
com.sofunny.Sausage
com.heavenburnsred
me.tigerhix.cytoid
org.flos.phira
me.mugzone.emiria
com.HoYoverse.hkrpgoversea
com.gameloft.android.ANMP.GloftA9HM
com.miraclegames.farlight84
com.seasun.jx3
com.RoamingStar.BlueArchive
com.YoStarEN.Arknights
com.YoStarEN.MahjongSoul
com.levelinfinite.sgameGlobal
com.pinkcore.tkfm
com.hermes.j1game
com.hermes.mk.asia
com.EtherGaming.PocketRogues
com.hottapkgs.hotta
com.pwrd.hotta.laohu
com.pwrd.p5x
com.pwrd.persona5x.laohu
com.hypergryph.arknights
com.hypergryph.exastris
com.xd.TLglobal
com.xd.xdt
com.xd.sce.promotion
sh.ppy.osulazer
com.ZeroCastleGameStudio.StrikeBusterPrototype
com.ZeroCastleGameStudioINTL.StrikeBusterPrototype
com.AlfaBravo.Combat
com.nexon.kartdrift
com.nexon.bluearchive
com.lilithgames.hgame.cn
com.bingkolo.kleins.cn
com.zy.wqmt.cn
"
local local_thread_config="$(grep -Ev '^[[:space:]]*$|#' "${1}" | sed 's/{.*//g;s/=.*//g;s/:.*//g' | sort -u)"
local package_config=`echo "${local_thread_config}" | tr '\n' '|' | sed -E 's/\|$//g' `
local scene_version=`dumpsys package com.omarea.vtools 2>/dev/null | grep -i "versioncode" | sed -E 's/.*=([0-9]{9,11}).*/\1/g'`
for i in /data/user/0/com.omarea.*/files/threads.json
do
	[ "${scene_version}" -ge "820250518" ] && ui_print "- Scene 版本: ${scene_version} " && break
	haspackage=$(grep -Eo "${package_config}" "${i}" 2>/dev/null | sed -E 's/^(.)/- \1/g')
	[[ "${haspackage}" != "" ]] && ui_print "- Scene核心分配找到和用户自定义重复的包名
- 请自行确认是否开启Scene的对应的核心配置开关(我太菜了，还没找到开关记录)。
${haspackage}"
done
[ -d "/data/adb/modules/asoul_affinity_opt" -a ! -f "/data/adb/modules/asoul_affinity_opt/disable" ] && local Asoul_conflict=$(echo "${Asoul_package}" | grep -Eo "${package_config}" | sed -E 's/^(.)/- \1/g' )
[[ "${Asoul_conflict}" != "" ]] && ui_print "- 找到配置文件和A-soul模块冲突的包名，请不要重复配置
${Asoul_conflict}
"
#查找冲突模块
[[ "$(get_other_module)" != "" ]] && ui_print "
- 检测到可能冲突模块
- 确保不要重复配置应用$(get_other_module)"
#get_other_module
[ "${haspackage}" = "" -a "${Asoul_conflict}" = "" -a "$(get_other_module)" = "" -a "$(get_other_module)" = "" ] && ui_print "- 未找到对应模块冲突或者应用冲突……"
}

function get_app_cpu_Info(){
#检测代码来源于@coolapk 10007
[[ "${0##*/}" = "action.sh" ]] && ui_print "- 检测程序运行状况……" || return
local cpuinfo_show=`dumpsys cpuinfo | grep -Eo '[0-9]{1,3}(\.[0-9])?%[[:space:]]+[0-9]{1,6}\/AppOpt'`
local Check_cpuinfo="$(echo "${cpuinfo_show}" | sed -E 's|[[:space:]][0-9]{1,6}/AppOpt||g' )"
case "${Check_cpuinfo}" in
0.[0-9]%|0%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 正常……"
;;
[0-9]%|[0-9].[0-9]%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 占用过大！？
"
;;
[0-9][0-9]%|[0-9][0-9].[0-9]%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 异常占用！
- 建议反馈给开发者！
"
[ -f "${0%/*}/service.sh" ] && nohup "${0%/*}/service.sh" >/dev/null 2>&1
;;
[0-9][0-9][0-9]%|[0-9][0-9][0-9].[0-9]%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 核心爆炸了，哥们！
- 我给你重启了进程，3秒后再执行action(操作)查看吧……
"
[ -f "${0%/*}/service.sh" ] && nohup "${0%/*}/service.sh" >/dev/null 2>&1
;;
*)
if [ "$(pgrep -lf AppOpt | sed "/${0##*/}/d;/App_GET_Thread/d;/^[[:space:]]*$/d" )" != "" ];then
ui_print "- ●AppOpt●
- AppOpt进程正常运行……
- 命令行 `pgrep -lf AppOpt | sed "/${0##*/}/d;/App_GET_Thread/d;/^[[:space:]]*$/d"`
"
else
ui_print "- ●AppOpt●
- 未找到AppOpt进程……
- 尝试重启AppOpt……
"
[ -f "${0%/*}/service.sh" ] && nohup "${0%/*}/service.sh" >/dev/null 2>&1
[ "$(pgrep -lf AppOpt | sed "/${0##*/}/d;/App_GET_Thread/d;/^[[:space:]]*$/d" )" != "" ] && ui_print "- 重启完成……" || ui_print "- 重启失败……"
fi
;;
esac
}
#查找错误日志
function show_error_log_content(){
local log_file="/data/adb/modules/AppOpt_Aloazny/affinity_manager.log"
if [[ ! -f "${log_file}" ]];then
	local cmd_content="$(pgrep -lf AppOpt )"
	log_file="$(echo "${cmd_content}" | grep -Eo "\-\-log=\/.*" | sed 's/--debug=.*//g;s/.*--log=//g' )"
	[ "${log_file}" = "" ] && log_file="$(echo "${cmd_content}" | grep -Eo "\-f /.*" | sed 's/--debug=.*//g;s/.*-f//g' )"
	[ ! -f "${log_file}" ] && return
fi
[ ! -f "${log_file}" -o "${0%##*/}" = "action.sh" ] && return
local error="$(grep -v '\[I\]' "$log_file" | sed '/^[[:space:]]*$/d' | head -n 10)"
if [[ "${error}" != "" ]];then
ui_print "
- 有错误日志输出
- 点击magisk右上角保存
- 在/sdcard/Download(/storage/emulated/0/Download/)目录能找到错误日志。
${error}
"
local log_error_output_file="/storage/emulated/0/Download/AppOpt错误日志.log"
mkdir -p "${log_error_output_file%/*}"
cp -af "${log_file}" "$log_error_output_file"
[ -f "${module_config}" ] && echo -e "\n#配置文件$(cat "${module_config}" )\n#END" >> "$log_error_output_file"
fi
}

function fix_applist_conf(){
local target_file="${1}"
#local cpu_range=$(cat /sys/devices/system/cpu/present 2>/dev/null )
[[ ! -f "$target_file" ]] && return
sed -E -i '/^[[:space:]]*$/N;/\n$/d' "${target_file}"
sed -E -i 's/(=.*[0-9])([[:space:]]+#.*)/\1/g' "${target_file}"
sed -E -i 's/--/-/g' "${target_file}"
sed -E -i 's/(=)([^0-9]+)([0-9])/\1\3/g' "${target_file}"
sed -E -i 's/^(\}|\})/#\1/g' "${target_file}"
sed -E -i 's/[[:space:]]$//g' "${target_file}"
sed -E -i 's/^([^#a-zA-Z0-9.-]+)/#\1/g' "${target_file}"
sed -E -i 's/=([0-9]|[0-9]-?[0-9]?,[0-9]-?[0-9]?|[0-9]-[0-9])([^0-9]+)$/=\1/g' "${target_file}"
sed -E -i 's/(^[^#][^=]*$)/#\1/g' "${target_file}"
#grep -E "(=[0-9]{2,}|=[0-9]{2,}-[0-9]+|=[0-9]+-[0-9]{2,}|=[0-9]{2,}\,[0-9]?|=[0-9]?\,[0-9]{2,})" "${target_file}" | sed -E 's/(.*)=(.*)/核心配置貌似不对？内容:\1=\2/g;/^[[:space:]]*$/d'
#[ "${cpu_range}" != "" ] && grep -E "=[^${cpu_range}]|=[0-9]+\,[^${cpu_range}]$|=[0-9]+-[^${cpu_range}]$" "${target_file}" | sed -E '/#/d;/^[[:space:]]*$/d;/Debug_AppOpt=/d;s/(.*)=(.*)/不存在的核心 内容:\1=\2/g;/^[[:space:]]*$/d'
grep -Ev '^[[:space:]]*$|^#' "${target_file}" | sed -E 's/=([0-9].*)/=/g' | uniq -d | while read -r same
do
	ui_print "- 检测到重复行……"
	ui_print "- 进程名称: ${same} : `grep -n "${same}" "${target_file}" | sed -E 's|([0-9]{1,3})\:(.*)|\1行|g;s/\|$//g' |  tr '\n' ' ' `"
done | sort -u 
}

function core_architect_set(){
[ ! -f "${TMPDIR}/module.prop" ] && return
local file="${1}"
local flag_modtify="${2}"
[ ! -f "${file}" ] && return
local architect=$(wc -w /sys/devices/system/cpu/cpufreq/*/related_cpus | sed -E 's/^[[:space:]]+//g;/total/d;s/(^[0-9]+)([[:space:]].*)/\1/g' | sed ':a;$!N;s/\n/+/g;ta;s/+$//g')
if [ "${architect}" = "" ];then
	echo "- 核心信息无法获取？"
	return
else
[ ! -f "${flag_modtify}" -a -f "/data/adb/modules/AppOpt_Aloazny/applist.prop" ] && return
[  -f "${flag_modtify}" ] && touch "${MODPATH}/modtify_config"
echo "- 正在修改成: ${architect} 的核心配置……"
case "${architect}" in
4+3+1)
	echo "- 同核心配置，跳过配置……"
;;
3+4+1)
	echo "- 修改中……"
	sed -E -i -e 's/=4-([5|6|7])$/=3-\1/g' \
	-e 's/=0-[5|6]$/=0-5/g' \
	-e 's/=2-4$/=1-3/g' \
	-e 's/=0-3$/=0-2/g' "${file}" && echo "- 完成……"
;;
6+2)
	echo "- 修改中……"
	sed -E -i -e 's/=4-[5|6|7]$/=4-7/g' \
	-e 's/=0-[5|6]$/=0-6/g' \
	-e 's/=[5|6]$/=6/g' \
	-e 's/=4$/=6/g' \
	-e 's/=7\,([0-9])$/=6-7/g' \
	-e 's/=0-3$/=0-5/g' "${file}" && echo "- 完成……"
;;
4+4)
	echo "- 修改中……"
	sed -E -i -e 's/=4-[5|6]$/=4-7/g' \
	-e 's/\*\}=6$/\*\}=4-6/g' "${file}" && echo "- 完成……"
;;
2+3+2+1)
	echo "- 修改中……"
	sed -E -i -e 's/=2-4$/=0-2/g' \
	-e 's/=6-7$/=7\,4/g' \
	-e 's/=[4|5]-6$/=2-4/g' \
	-e 's/=0-3$/=5-6/g' \
	-e 's/=2-3$/=0-1/g' \
	-e 's/=[5|6]$/=3/g' \
	-e 's/=4-5$/=5-6/g' \
	-e 's/=0-[5|6]$/=2-6/g' "${file}" && echo "- 完成……"
;;
*)
	echo "- 暂未适配……"
	echo "- 可能需要您手动调整成自己的核心配置(${architect})……"
;;
esac
fi
}

function mtk_remove_app_cfg(){
[ ! -f "${TMPDIR}/module.prop" ] && return
local file="/system/vendor/etc/power_app_cfg.xml"
if [ -f "${file}" ];then
	mkdir -p "$MODPATH/${file%/*}"
	cp -af "${file}" "$MODPATH/${file}" >/dev/null 2>&1
echo '<?xml version="1.0" encoding="UTF-8"?>
<WHITELIST>
</WHITELIST>' > "$MODPATH/${file}"
fi
}

function set_miui_booster() {
[ ! -f "${TMPDIR}/module.prop" ] || [ "$(getprop | grep -E 'miui|mi\.os')" = "" ] && return
local architect=$(wc -w /sys/devices/system/cpu/cpufreq/*/related_cpus | sed -E 's/^[[:space:]]+//g;/total/d;s/(^[0-9]+)([[:space:]].*)/\1/g' | sed ':a;$!N;s/\n/+/g;ta;s/+$//g')
case "${architect}" in
4+3+1|4+4) booster_cpus="6-7" ;;
3+4+1) booster_cpus="6-7" ;;
2+3+2+1) booster_cpus="6-7" ;;
6+2) booster_cpus="6-7" ;;
*) return ;;
esac
echo -e "persist.sys.miui_animator_sched.bigcores=${booster_cpus}\npersist.sys.miui_animator_sched.big_prime_cores=${booster_cpus}" > "${MODPATH}/system.prop"
resetprop -n --file "${MODPATH}/system.prop" >dev/null 2>&1
}

function update_bin_file(){
local original_bin_file="/data/adb/modules/AppOpt_Aloazny/AppOpt"
local update_bin_file="${original_bin_file/modules/modules_update}"
[ ! -f "${update_bin_file}" ] && return
if ! cmp "${original_bin_file}" "${update_bin_file}" >/dev/null 2>&1 ;then
	echo "- 升级 ${original_bin_file##*/} 文件……"
	cp -af "${update_bin_file}" "${original_bin_file}" >/dev/null 2>&1
	cp -af "${update_bin_file%/*}/service.sh" "${original_bin_file%/*}/service.sh"
	cp -af "${update_bin_file%/*}/cpu_control.sh" "${original_bin_file%/*}/cpu_control.sh" >/dev/null 2>&1
	chmod a+x "${original_bin_file%/*}/service.sh"
	nohup "${original_bin_file%/*}/service.sh" >/dev/null 2>&1 && echo -e "- 已经重启AppOpt……\n- 理论上无需重启手机……"
fi
if ! cmp "${original_bin_file%/*}/cpu_control.sh" "${update_bin_file%/*}/cpu_control.sh" >/dev/null 2>&1 ;then
	cp -af "${update_bin_file%/*}/cpu_control.sh" "${original_bin_file%/*}/cpu_control.sh" >/dev/null 2>&1
	chmod a+x "${original_bin_file%/*}/cpu_control.sh"
	nohup "${original_bin_file%/*}/cpu_control.sh" >/dev/null 2>&1
fi
}

function hide_module_check(){
[ ! -f "${TMPDIR}/module.prop" ] && return
if [ ! -f "/data/adb/modules/zygisk_shamiko/module.prop" -a ! -f "/data/adb/modules/zygisk-maphide/module.prop" ];then
	touch "$MODPATH/skip_mount"
	echo "- 未安装隐藏模块，默认不挂载/system……"
fi
}

function Delete_Game_config(){
[ ! -f "${TMPDIR}/module.prop" ] && return
local flag_file="${2}"
local config_file="${1}"
if [ -f "${flag_file}" ];then
	echo "- 删除游戏配置文件……"
	touch "${MODPATH}/${flag_file##*/}"
	sed -i '/^#游戏$/,/^#游戏END$/d' "${config_file}" && echo "- 完成……" || echo "- 失败！"
fi
}

#代码来源于coolapk@10007
#获取酷安名称
function get_coolapk_user_name(){
for i in /data/user/0/com.coolapk.market/shared_prefs/*preferences*.xml
do
	username="$(grep '<string name="username">' "${i}" | sed 's/.*"username">//g;s/<.*//g')"
	if [[ -n "${username}" ]];then
	 echo "${username}"
	 break
	fi
done
}

#获取github用户名
function get_github_user(){
local github_name="$(dumpsys content | grep -Eo 'Account[[:space:]].*u[0-9]{1,3}.*com\.github\.android' | sed 's/Account[[:space:]]//g;s/[[:space:]]u[0-9].*//g' | sort -u | head -n 1)"
echo "${github_name}"
}

function echo_user_Name(){
local user_name="$(get_github_user)"
[ "${user_name}" = "" ] && user_name="$(get_coolapk_user_name)"
[ "${user_name}" = "" ] && user_name="$(getprop persist.sys.device_name)"
[ "${user_name}" != "" ] && echo "${user_name}" || echo "用户"
}

function Say_hello(){
local Time=$(date +%H)
echo -e "\n**************************************************"
case "${Time}" in
0[0-4]|19|2[0-3])
	echo -e "- 🌙晚上好！\n- 尊敬的 $(echo_user_Name) ……"
;;
0[5-9]|1[0-1])
	echo -e "- ☀早上好！\n- 尊敬的 $(echo_user_Name) ……"
;;
1[2-3])
	echo -e "- ☀中午好！\n- 尊敬的 $(echo_user_Name) ……"
;;
1[4-8])
	echo -e "- 🕓下午好！\n- 尊敬的 $(echo_user_Name) ……"
;;
*)
	echo -e "- 💬您好！\n- 尊敬的 $(echo_user_Name) ……"
;;
esac
}



#部分来源于coolapk@10007
ui_print ""
ui_print "**************************************************"
ui_print "－品牌: `getprop ro.product.brand`"
ui_print "－代号: `getprop ro.product.device`"
ui_print "－模型: `getprop ro.product.model`"
ui_print "－安卓版本: `getprop ro.build.version.release`"
test "`getprop ro.miui.ui.version.name`" != "" && ui_print "－MIUI版本: MIUI `getprop ro.miui.ui.version.name` - `getprop ro.build.version.incremental` "
ui_print "－内核版本: `uname -a `"
ui_print "－运存大小: `free -m|grep "Mem"|awk '{print $2}'`MB  已用:`free -m|grep "Mem"|awk '{print $3}'`MB  剩余:$((`free -m|grep "Mem"|awk '{print $2}'`-`free -m|grep "Mem"|awk '{print $3}'`))MB"
ui_print "－Swap大小: `free -m|grep "Swap"|awk '{print $2}'`MB  已用:`free -m|grep "Swap"|awk '{print $3}'`MB  剩余:`free -m|grep "Swap"|awk '{print $4}'`MB"
ui_print "**************************************************"
ui_print "- 模块信息:"
ui_print "$(get_magisk_lite)"
ui_print "- Module version: $(grep_prop version "${MODPATH}/module.prop")"
ui_print "- Module versionCode: $(grep_prop versionCode "${MODPATH}/module.prop")"
ui_print "- 描述: $(grep_prop description "${MODPATH}/module.prop")"
Say_hello
mtk_remove_app_cfg
set_miui_booster
hide_module_check
get_app_cpu_Info
get_cpu_core_Info
[[ -f "${TMPDIR}/module.prop" ]] && {
Aloazny_script_name="Aloazny.sh"
module_config_folder="/data/adb/modules/AppOpt_Aloazny"
mv -f "$MODPATH/${Aloazny_script_name}" "$MODPATH/action.sh"
chmod +x "$MODPATH/action.sh"
cp -af "$MODPATH/action.sh" "${module_config_folder}/action.sh"
[ ! -d "${module_config_folder}" ] && mkdir -p "${module_config_folder}" && touch "${module_config_folder}/update_config" && touch "${module_config_folder}/modtify_config" && touch "${module_config_folder}/applist.prop"
rm -rf "${module_config_folder}/${Aloazny_script_name}" "$MODPATH/${Aloazny_script_name}"
}
module_config_folder="/data/adb/modules/AppOpt_Aloazny"
original_module="/data/adb/modules/AppOpt"
[ ! -d "${module_config_folder}" ] && module_config_folder="$original_module"
module_config="${module_config_folder}/applist.conf"
[ ! -f "${module_config}" ] && module_config="${module_config%/*}/applist.prop"
if [ -f "$module_config" -a -f "${TMPDIR}/module.prop" ]; then
	test -d "${original_module}" -a ! -f "${original_module}/disable" && touch "${original_module}/disable"
	if [ -f "${module_config%/*}/update_config" ];then
		echo "- 正在使用模块配置……"
		echo "- 您的配置文件将被覆盖……"
		echo "- 无需重启生效……"
		touch "${MODPATH}/update_config"
		mv -f "$module_config" "$module_config.bak"
		cp -af "$MODPATH/${module_config##*/}" "$module_config"
		cp -af "$module_config.bak" "${MODPATH}/${module_config##*/}.bak"
	else
		echo "- 使用您的配置文件……"
		mv -f $MODPATH/${module_config##*/} $MODPATH/${module_config##*/}.bak
		cp -af "$module_config" "$MODPATH/${module_config##*/}"
	fi
		write_core_information "$MODPATH/${module_config##*/}"
		fix_applist_conf "$MODPATH/${module_config##*/}"
		Delete_Game_config "$MODPATH/${module_config##*/}" "${module_config%/*}/delete_game_config"
		core_architect_set "$MODPATH/${module_config##*/}" "${module_config%/*}/modtify_config"
		cp -af "$MODPATH/${module_config##*/}" "$module_config" 
fi

if [ ! -f "${module_config}" ];then
	core_architect_set "$MODPATH/applist.prop" "${module_config%/*}/modtify_config"
	Delete_Game_config "$MODPATH/applist.prop" "${module_config%/*}/delete_game_config"
fi

fix_applist_conf "${module_config}"
get_other_thread "${module_config}"
write_core_information "${module_config}"
write_cpu_information_to_module_description
show_error_log_content
[[ -f "${TMPDIR}/module.prop" ]] && rm -rf "$MODPATH/源码" "$MODPATH/update.md" "$MODPATH/README.md" "$MODPATH/适配应用.md" "$MODPATH/LICENSE"
Move_platform_bin
update_bin_file

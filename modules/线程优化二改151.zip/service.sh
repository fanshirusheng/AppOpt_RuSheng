wait_sys_boot_completed() {
	local i=9
	until [ "$(getprop sys.boot_completed)" == "1" ] || [ $i -le 0 ]; do
		i=$((i-1))
		sleep 25s
	done
}

wait_sys_boot_completed


if [ -d "/data/adb/modules/AppOpt" ] && [ ! -f "/data/adb/modules/AppOpt/disable" ];then
    echo "
    - 您已选择 Suto 大佬的模块，该模块不会运行！
    "
    exit 0
fi


#杀死上次运行的程序
killall -15 AppOpt >/dev/null 2>&1
#尝试修复开机不自动执行
cd "${0%/*}"
chmod a+x "${0%/*}/AppOpt"
chmod a+x "${0%/*}/cpu_control.sh" 2>/dev/null
#配置文件路径
module_config="${0%/*}/applist.prop"
[ -f "${0%/*}/applist.conf" ] && module_config="${0%/*}/applist.conf"
#启动AppOpt
nohup "${0%/*}/AppOpt" -c "${module_config}" >/dev/null 2>&1 &
#禁用一些服务
nohup "${0%/*}/cpu_control.sh" >/dev/null 2>&1 &

# 如需暂停绿厂oiface请将下面这行的#号注释删掉，恢复oiface则将0改成1
# [ -n "$(getprop persist.sys.oiface.enable)" ] && setprop persist.sys.oiface.enable 0

# 如需禁用米系机型joyose请将下面这行pm命令的 # 号注释删掉
# pm disable-user com.xiaomi.joyose; pm clear com.xiaomi.joyose
# 恢复 
# pm enable com.xiaomi.joyose


SKIPUNZIP=0
check_magisk_version() {
	ui_print "- Magisk version: $MAGISK_VER_CODE"
	ui_print "- Module version: $(grep_prop version "${TMPDIR}/module.prop")"
	ui_print "- Module versionCode: $(grep_prop versionCode "${TMPDIR}/module.prop")"
	ui_print "**************************************************"
	ui_print "- $(grep_prop description "${TMPDIR}/module.prop")"
	ui_print "**************************************************"
	ui_print "线程规则配置文件路径为："
	ui_print "/data/adb/modules/AppOpt/applist.conf"
	ui_print "修改与添加规则无需重启，即时生效"
	ui_print "**************************************************"
	ui_print "规则示例："
	ui_print "假设我现在要将“王者荣耀”绑定到骁龙8Gen3设备中的CPU中核与大核心上，"
	ui_print "而骁龙8Gen3有两个A520小核，CPU0与CPU1代表小核，CPU2到CPU7为中核与大核"
	ui_print "则在applist.conf中添加一行规则："
	ui_print "-------------------------------------------------"
	ui_print "com.tencent.tmgp.sgame=2-7"
	ui_print "-------------------------------------------------"
	ui_print "其中com.tencent.tmgp.sgame为王者荣耀的包名，2-7表示将线程绑定到CPU2到CPU7"
	ui_print "-------------------------------------------------"
	ui_print "更多规则使用说明请参考 http://AppOpt.suto.top"
	if [ "$MAGISK_VER_CODE" -lt 20400 ]; then
		ui_print "**************************************************"
		ui_print "! 请安装 Magisk v20.4+ (20400+)"
		abort    "**************************************************"
	fi
}
check_required_files() {
	REQUIRED_FILE_LIST="/sys/devices/system/cpu/present"
	for REQUIRED_FILE in $REQUIRED_FILE_LIST; do
		if [ ! -e $REQUIRED_FILE ]; then
			ui_print "**************************************************"
			ui_print "! $REQUIRED_FILE 文件不存在"
			ui_print "! 请联系模块作者"
			abort    "**************************************************"
		fi
	done
}
extract_bin() {
	ui_print "**************************************************"
	if [ "$ARCH" == "arm" ]; then
		cp $MODPATH/bin/armeabi-v7a/AppOpt $MODPATH
	elif [ "$ARCH" == "arm64" ]; then
		cp $MODPATH/bin/arm64-v8a/AppOpt $MODPATH
	elif [ "$ARCH" == "x86" ]; then
		cp $MODPATH/bin/x86/AppOpt $MODPATH
	elif [ "$ARCH" == "x64" ]; then
		cp $MODPATH/bin/x86_64/AppOpt $MODPATH
	else
		abort "! Unsupported platform: $ARCH"
	fi
	ui_print "- Device platform: $ARCH"
	rm -rf $MODPATH/bin
}
remove_sys_perf_config() {
	for SYSPERFCONFIG in $(ls /system/vendor/bin/msm_irqbalance); do
		[[ ! -d $MODPATH${SYSPERFCONFIG%/*} ]] && mkdir -p $MODPATH${SYSPERFCONFIG%/*}
		ui_print ""
		ui_print "**************************************************"
		ui_print "- Config file:$SYSPERFCONFIG"
		touch $MODPATH$SYSPERFCONFIG
		ui_print "**************************************************"
	done
}
#check_magisk_version
. "$MODPATH/Aloazny.sh"
check_required_files
#extract_bin
remove_sys_perf_config

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/*.sh" 0 2000 0755 0755
set_perm_recursive "$MODPATH/AppOpt" 0 2000 0755 0755

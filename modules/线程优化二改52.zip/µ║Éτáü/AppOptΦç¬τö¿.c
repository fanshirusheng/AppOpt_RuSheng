#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <fnmatch.h>
#include <sched.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#include <sys/inotify.h>
#include <sys/select.h>
#include "uthash.h" // 添加uthash读取配置文件包名

// 常量定义
#define MAX_LOG_SIZE (100 * 1024)
#define DEFAULT_CONFIG_FILE "./applist.conf"
#define CONFIG_RELOAD_TIME 10
#define PROC_CACHE_TIME 15 // 兼容玩游戏的同学
#define MAX_PKG_LEN 128
#define MAX_THREAD_LEN 64
#define PROC_ENTRY_CACHE_TIME 5 // 读取proc缓存间隔

// 延迟时间 检查CPU亲和性
#define SHORT_DELAY_SECONDS 0
#define SHORT_DELAY_NANOSECONDS 500000000 // 0.5秒
#define LONG_DELAY_SECONDS 5
#define LONG_DELAY_NANOSECONDS 0 // 5秒

// 日志宏
#define LOG_I(fmt, ...) do { if (log_enabled && !log_minimal) write_log("[I] " fmt, ##__VA_ARGS__); } while (0)
#define LOG_W(fmt, ...) do { if (log_enabled) write_log("[W] " fmt, ##__VA_ARGS__); } while (0)
#define LOG_E(fmt, ...) do { if (log_enabled) write_log("[E] " fmt, ##__VA_ARGS__); } while (0)

// 数据结构
typedef struct {
    char pkg[MAX_PKG_LEN];
    char thread[MAX_THREAD_LEN];
    cpu_set_t cpus;
    bool is_wildcard; // 新增：标记是否为通配符规则
} AffinityRule;

typedef struct {
    pid_t tid;
    char name[MAX_THREAD_LEN];
    cpu_set_t cpus;
    cpu_set_t last_cpus;
} ThreadInfo;

typedef struct {
    pid_t pid;
    char pkg[MAX_PKG_LEN];
    cpu_set_t base_cpus;
    ThreadInfo* threads;
    size_t num_threads;
    AffinityRule** thread_rules;
    size_t num_thread_rules;
    bool scanned;
} ProcessInfo;

typedef struct {
    cpu_set_t present_cpus;
    bool cpuset_enabled;
    char present_str[256];
} CpuTopology;

typedef struct {
    pid_t pid;
    char cmdline[MAX_PKG_LEN];
    time_t last_update;
    UT_hash_handle hh;
} ProcEntryCache;

typedef struct {
    AffinityRule* rules;
    size_t num_rules;
    AffinityRule** wildcard_rules; // 新增：存储通配符规则指针
    size_t num_wildcard_rules;    // 新增：通配符规则数量
    time_t mtime;
    CpuTopology topo;
    char** pkgs;
    size_t num_pkgs;
    struct PackageEntry* pkg_table;
} AppConfig;

typedef struct PackageEntry {
    char pkg[MAX_PKG_LEN];
    UT_hash_handle hh;
} PackageEntry;

typedef struct {
    ProcessInfo* procs;
    size_t num_procs;
    time_t last_update;
    ProcEntryCache* proc_cache;
} ProcCache;

// 日志模块
static bool log_enabled = false;
static bool log_minimal = false; // 新增：最小日志模式
static FILE* log_fp = NULL;
static bool log_writing = false;
static char log_file_path[256];
static bool debug_set_from_args = false;

static char* get_timestamp(void) {
    static char buf[32];
    time_t now = time(NULL);
    struct tm* tm = localtime(&now);
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", tm);
    return buf;
}

static void ensure_log_file(void) {
    if (!log_fp) {
        log_fp = fopen(log_file_path, "a");
        if (!log_fp) {
            fprintf(stderr, "Failed to open log file %s: %s\n", log_file_path, strerror(errno));
        }
    }
}

static void check_log_size(void) {
    if (log_writing || !log_fp) return;
    struct stat st;
    if (stat(log_file_path, &st) == 0 && st.st_size >= MAX_LOG_SIZE) {
        fclose(log_fp);
        log_fp = fopen(log_file_path, "w");
        if (log_fp) fclose(log_fp);
        log_fp = NULL;
    }
}

static void write_log(const char* fmt, ...) {
    ensure_log_file();
    if (!log_fp) return;

    check_log_size();
    if (!log_fp) {
        ensure_log_file();
        if (!log_fp) return;
    }

    log_writing = true;
    va_list args;
    va_start(args, fmt);
    fprintf(log_fp, "[%s] ", get_timestamp());
    vfprintf(log_fp, fmt, args);
    fprintf(log_fp, "\n");
    fflush(log_fp);
    va_end(args);
    log_writing = false;
}

// inotify模块
static int inotify_fd = -1;
static int inotify_wd = -1;

static void init_inotify(const char* config_file) {
    inotify_fd = inotify_init1(IN_NONBLOCK);
    if (inotify_fd == -1) {
        LOG_E("Failed to initialize inotify: %s", strerror(errno));
        return;
    }

    char* dir_path = strdup(config_file);
    char* last_slash = strrchr(dir_path, '/');
    if (last_slash) *last_slash = '\0';
    else {
        free(dir_path);
        dir_path = strdup(".");
    }

    inotify_wd = inotify_add_watch(inotify_fd, dir_path,
                                   IN_MODIFY | IN_CREATE | IN_DELETE | IN_MOVED_FROM | IN_MOVED_TO);
    if (inotify_wd == -1) {
        LOG_E("Failed to add watch for %s: %s", dir_path, strerror(errno));
        close(inotify_fd);
        inotify_fd = -1;
    } else {
        LOG_I("Inotify watching directory %s for config file changes", dir_path);
    }
    free(dir_path);
}

static bool check_inotify_config_change(const char* config_file) {
    if (inotify_fd == -1) return false;

    char buf[sizeof(struct inotify_event) + NAME_MAX + 1] __attribute__((aligned(__alignof__(struct inotify_event))));
    ssize_t len = read(inotify_fd, buf, sizeof(buf));
    if (len < 0 && errno == EAGAIN) return false;
    if (len <= 0) return false;

    char* config_name = strrchr(config_file, '/');
    config_name = config_name ? config_name + 1 : (char*)config_file;

    bool config_changed = false;
    char* ptr = buf;
    while (ptr < buf + len) {
        struct inotify_event* event = (struct inotify_event*)ptr;
        if (event->len > 0 && strcmp(event->name, config_name) == 0) {
            if (event->mask & (IN_MODIFY | IN_CREATE | IN_MOVED_TO)) {
                LOG_I("Config file %s changed (event: %x)", config_name, event->mask);
                config_changed = true;
            } else if (event->mask & (IN_DELETE | IN_MOVED_FROM)) {
                LOG_I("Config file %s deleted or moved away (event: %x)", config_name, event->mask);
                config_changed = true;
            }
        }
        ptr += sizeof(struct inotify_event) + event->len;
    }
    return config_changed;
}

// 工具函数
static inline void* xrealloc(void* ptr, size_t size) {
    void* p = realloc(ptr, size);
    if (!p) {
        free(ptr);
        return NULL;
    }
    return p;
}

static inline char* strtrim(char* s) {
    while (isspace((unsigned char)*s)) s++;
    if (!*s) return s;
    char* end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end)) end--;
    end[1] = '\0';
    return s;
}

static void set_default_log_path(const char* config_file) {
    char* last_slash = strrchr(config_file, '/');
    if (last_slash) {
        size_t dir_len = last_slash - config_file + 1;
        strncpy(log_file_path, config_file, dir_len);
        log_file_path[dir_len] = '\0';
        strncat(log_file_path, "affinity_manager.log", sizeof(log_file_path) - dir_len - 1);
    } else {
        strncpy(log_file_path, "affinity_manager.log", sizeof(log_file_path) - 1);
    }
    log_file_path[sizeof(log_file_path) - 1] = '\0';
}

// CPU拓扑初始化
static void parse_cpu_ranges(const char* spec, cpu_set_t* set, const cpu_set_t* present) {
    if (!spec || !set) return;
    const char* s = spec;
    while (*s) {
        while (isspace((unsigned char)*s)) s++;
        if (!*s) break;
        unsigned a = strtoul(s, (char**)&s, 10);
        unsigned b = a;
        if (*s == '-') b = strtoul(s + 1, (char**)&s, 10);
        if (a > b) { unsigned t = a; a = b; b = t; }
        for (; a <= b && a < CPU_SETSIZE; a++) {
            if (present && !CPU_ISSET(a, present)) continue;
            CPU_SET(a, set);
        }
        if (*s == ',') s++;
    }
}

static CpuTopology init_cpu_topo(void) {
    CpuTopology topo = { .cpuset_enabled = false };
    CPU_ZERO(&topo.present_cpus);

    int fd = open("/sys/devices/system/cpu/present", O_RDONLY);
    if (fd >= 0) {
        char buf[64] = {0};
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0) {
            char* p = strtrim(buf);
            char* end = strchr(p, '\n');
            if (end) *end = '\0';
            strncpy(topo.present_str, p, sizeof(topo.present_str) - 1);
            parse_cpu_ranges(topo.present_str, &topo.present_cpus, NULL);
        }
    } else {
        LOG_W("Failed to read /sys/devices/system/cpu/present: %s", strerror(errno));
    }

    if (access("/dev/cpuset", F_OK) != 0) return topo;

    const char* cpuset_dir = "/dev/cpuset/AppOpt";
    if (mkdir(cpuset_dir, 0755) != 0 && errno != EEXIST) {
        LOG_E("Failed to create %s: %s", cpuset_dir, strerror(errno));
        return topo;
    }

    int cpus_fd = open("/dev/cpuset/AppOpt/cpus", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (cpus_fd >= 0) {
        dprintf(cpus_fd, "%s", topo.present_str);
        close(cpus_fd);
    }

    int mems_fd = open("/dev/cpuset/AppOpt/mems", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (mems_fd >= 0) {
        write(mems_fd, "0", 1);
        close(mems_fd);
    }
    topo.cpuset_enabled = true;
    return topo;
}

// 配置加载
static bool load_config(AppConfig* cfg, const char* config_file) {
    struct stat st;
    if (stat(config_file, &st) != 0) {
        FILE* fp = fopen(config_file, "w");
        if (fp) fclose(fp);
        LOG_W("Config file %s not found, created empty file", config_file);
        return false;
    }
    if (st.st_mtime <= cfg->mtime) return false;

    FILE* fp = fopen(config_file, "r");
    if (!fp) {
        LOG_E("Failed to open %s: %s", config_file, strerror(errno));
        return false;
    }

    AffinityRule* rules = NULL;
    size_t num_rules = 0;
    AffinityRule** wildcard_rules = NULL;
    size_t num_wildcard_rules = 0;
    bool log_set = false;
    char line[256];
    PackageEntry* pkg_table = NULL;
    size_t line_number = 0;

    while (fgets(line, sizeof(line), fp)) {
        line_number++;
        char* p = strtrim(line);
        if (!*p || *p == '#') continue; // 跳过空行和整行注释

        char* eq = strchr(p, '=');
        if (!eq) {
            LOG_W("Invalid rule at line %zu: missing '=': %s", line_number, p);
            continue;
        }
        *eq++ = '\0';

        char* key = strtrim(p);
        char* value = strtrim(eq);

        // 处理行内注释
        char* comment = strchr(value, '#');
        if (comment) *comment = '\0';
        value = strtrim(value);

        if (!*key || !*value) {
            LOG_W("Invalid rule at line %zu: empty key or value: %s", line_number, p);
            continue;
        }

        if (!strcmp(key, "Debug_AppOpt")) {
            if (log_set || debug_set_from_args) continue;
            log_enabled = !strcmp(value, "true");
            log_set = true;
            LOG_I("Debug_AppOpt set to %s at line %zu", value, line_number);
            continue;
        }

        char* br = strchr(key, '{');
        char* thread = "";
        if (br) {
            *br++ = '\0';
            char* eb = strchr(br, '}');
            if (!eb) {
                LOG_W("Invalid rule at line %zu: missing closing '}': %s", line_number, p);
                continue;
            }
            *eb = '\0';
            thread = strtrim(br);
        }

        char* pkg = strtrim(key);
        if (strlen(pkg) >= MAX_PKG_LEN || strlen(thread) >= MAX_THREAD_LEN) {
            LOG_W("Invalid rule at line %zu: package or thread name too long: %s", line_number, p);
            continue;
        }

        // 检查重复规则
        bool is_duplicate = false;
        for (size_t i = 0; i < num_rules; i++) {
            if (!strcmp(rules[i].pkg, pkg) && !strcmp(rules[i].thread, thread)) {
                LOG_W("Duplicate rule at line %zu: %s{%s}=%s, skipping", line_number, pkg, thread, value);
                is_duplicate = true;
                break;
            }
        }
        if (is_duplicate) continue;

        rules = xrealloc(rules, (num_rules + 1) * sizeof(AffinityRule));
        if (!rules) {
            LOG_E("Memory allocation failed at line %zu", line_number);
            fclose(fp);
            HASH_CLEAR(hh, pkg_table);
            free(wildcard_rules);
            return false;
        }
        AffinityRule* rule = &rules[num_rules++];
        strncpy(rule->pkg, pkg, MAX_PKG_LEN - 1);
        rule->pkg[MAX_PKG_LEN - 1] = '\0';
        strncpy(rule->thread, thread, MAX_THREAD_LEN - 1);
        rule->thread[MAX_THREAD_LEN - 1] = '\0';
        CPU_ZERO(&rule->cpus);
        parse_cpu_ranges(value, &rule->cpus, &cfg->topo.present_cpus);
        if (CPU_COUNT(&rule->cpus) == 0) {
            LOG_W("Invalid CPU range at line %zu: %s in rule: %s{%s}=%s", line_number, value, pkg, thread, value);
            num_rules--; // 移除无效规则
            continue;
        }
        // 仅检查包名中的通配符
        rule->is_wildcard = (strchr(pkg, '*') != NULL || strchr(pkg, '?') != NULL);
        LOG_I("Loaded rule at line %zu: %s{%s}=%s", line_number, pkg, thread, value);

        // 只有非通配符规则加入 pkg_table
        if (!rule->is_wildcard) {
            PackageEntry* pkg_entry;
            HASH_FIND_STR(pkg_table, pkg, pkg_entry);
            if (!pkg_entry) {
                pkg_entry = malloc(sizeof(PackageEntry));
                if (!pkg_entry) {
                    LOG_E("Memory allocation failed at line %zu", line_number);
                    fclose(fp);
                    HASH_CLEAR(hh, pkg_table);
                    free(wildcard_rules);
                    free(rules);
                    return false;
                }
                strncpy(pkg_entry->pkg, pkg, MAX_PKG_LEN - 1);
                pkg_entry->pkg[MAX_PKG_LEN - 1] = '\0';
                HASH_ADD_STR(pkg_table, pkg, pkg_entry);
            }
        } else {
            wildcard_rules = xrealloc(wildcard_rules, (num_wildcard_rules + 1) * sizeof(AffinityRule*));
            if (!wildcard_rules) {
                LOG_E("Memory allocation failed at line %zu", line_number);
                fclose(fp);
                HASH_CLEAR(hh, pkg_table);
                free(rules);
                return false;
            }
            wildcard_rules[num_wildcard_rules++] = rule;
        }
    }
    fclose(fp);

    if (!num_rules) {
        free(rules);
        free(wildcard_rules);
        HASH_CLEAR(hh, pkg_table);
        return false;
    }

    size_t num_pkgs = HASH_COUNT(pkg_table);
    char** pkgs = malloc(num_pkgs * sizeof(char*));
    if (!pkgs) {
        LOG_E("Memory allocation failed for pkgs array");
        free(rules);
        free(wildcard_rules);
        HASH_CLEAR(hh, pkg_table);
        return false;
    }
    PackageEntry *entry, *tmp;
    size_t i = 0;
    HASH_ITER(hh, pkg_table, entry, tmp) {
        pkgs[i++] = strdup(entry->pkg);
    }

    LOG_I("Config loaded: %zu rules, %zu packages, %zu wildcard rules (mtime: %ld)", 
          num_rules, num_pkgs, num_wildcard_rules, st.st_mtime);

    // 清理旧数据
    if (cfg->rules) free(cfg->rules);
    if (cfg->wildcard_rules) free(cfg->wildcard_rules);
    if (cfg->pkgs) {
        for (size_t j = 0; j < cfg->num_pkgs; j++) free(cfg->pkgs[j]);
        free(cfg->pkgs);
    }
    HASH_CLEAR(hh, cfg->pkg_table);

    cfg->rules = rules;
    cfg->num_rules = num_rules;
    cfg->wildcard_rules = wildcard_rules;
    cfg->num_wildcard_rules = num_wildcard_rules;
    cfg->pkgs = pkgs;
    cfg->num_pkgs = num_pkgs;
    cfg->pkg_table = pkg_table;
    cfg->mtime = st.st_mtime;
    return true;
}

// /proc条目缓存管理
static ProcEntryCache* get_proc_entry(ProcCache* cache, pid_t pid, int pid_fd) {
    ProcEntryCache* entry;
    HASH_FIND_INT(cache->proc_cache, &pid, entry);
    
    time_t now = time(NULL);
    if (entry && (now - entry->last_update < PROC_ENTRY_CACHE_TIME)) {
        return entry;
    }

    char cmd[MAX_PKG_LEN] = {0};
    int cmd_fd = openat(pid_fd, "cmdline", O_RDONLY);
    if (cmd_fd == -1) return NULL;
    
    ssize_t n = read(cmd_fd, cmd, sizeof(cmd) - 1);
    close(cmd_fd);
    if (n <= 0) return NULL;
    cmd[n] = '\0';

    if (!entry) {
        entry = malloc(sizeof(ProcEntryCache));
        if (!entry) return NULL;
        entry->pid = pid;
        HASH_ADD_INT(cache->proc_cache, pid, entry);
    }
    strncpy(entry->cmdline, cmd, MAX_PKG_LEN - 1);
    entry->last_update = now;
    return entry;
}

static void cleanup_proc_cache(ProcCache* cache) {
    ProcEntryCache *entry, *tmp;
    HASH_ITER(hh, cache->proc_cache, entry, tmp) {
        HASH_DEL(cache->proc_cache, entry);
        free(entry);
    }
}

// 进程和线程管理
static bool scan_process_threads(ProcessInfo* proc, int pid_fd) {
    int task_fd = openat(pid_fd, "task", O_RDONLY | O_DIRECTORY);
    if (task_fd == -1) return false;

    DIR* task_dir = fdopendir(task_fd);
    if (!task_dir) {
        close(task_fd);
        return false;
    }

    ThreadInfo* threads = NULL;
    size_t num_threads = 0;
    struct dirent* ent;

    while ((ent = readdir(task_dir))) {
        if (ent->d_type != DT_DIR || !isdigit(ent->d_name[0])) continue;
        pid_t tid = atoi(ent->d_name);

        char comm_path[64];
        snprintf(comm_path, sizeof(comm_path), "%s/comm", ent->d_name);
        int comm_fd = openat(task_fd, comm_path, O_RDONLY);
        if (comm_fd == -1) continue;

        char tname[MAX_THREAD_LEN] = {0};
        ssize_t n = read(comm_fd, tname, sizeof(tname) - 1);
        close(comm_fd);
        if (n <= 0) continue;
        tname[n - 1] = '\0';
        strtrim(tname);

        cpu_set_t mask;
        CPU_ZERO(&mask);
        bool exact_match = false;

        // 优先检查精确匹配的规则
        for (size_t i = 0; i < proc->num_thread_rules; i++) {
            if (strcmp(proc->thread_rules[i]->thread, tname) == 0) { // 精确匹配
                CPU_OR(&mask, &mask, &proc->thread_rules[i]->cpus);
                exact_match = true;
                break; // 找到精确匹配后跳出
            }
        }

        // 如果没有精确匹配，检查通配符规则
        if (!exact_match) {
            for (size_t i = 0; i < proc->num_thread_rules; i++) {
                if (fnmatch(proc->thread_rules[i]->thread, tname, FNM_NOESCAPE) == 0) {
                    CPU_OR(&mask, &mask, &proc->thread_rules[i]->cpus);
                }
            }
        }

        threads = xrealloc(threads, (num_threads + 1) * sizeof(ThreadInfo));
        if (!threads) {
            closedir(task_dir);
            return false;
        }
        threads[num_threads] = (ThreadInfo){
            .tid = tid,
            .cpus = CPU_COUNT(&mask) ? mask : proc->base_cpus
        };
        strncpy(threads[num_threads].name, tname, MAX_THREAD_LEN - 1);
        CPU_ZERO(&threads[num_threads].last_cpus);
        num_threads++;
    }

    proc->threads = threads;
    proc->num_threads = num_threads;
    proc->scanned = true;
    closedir(task_dir);
    return true;
}

static ProcCache* update_proc_cache(ProcCache* cache, const AppConfig* cfg) {
    time_t now = time(NULL);
    if (now - cache->last_update < PROC_CACHE_TIME) return cache;

    DIR* proc_dir = opendir("/proc");
    if (!proc_dir) {
        LOG_E("Failed to open /proc: %s", strerror(errno));
        return cache;
    }

    ProcessInfo* procs = NULL;
    size_t num_procs = 0;
    int proc_fd = dirfd(proc_dir);

    struct dirent* ent;
    while ((ent = readdir(proc_dir))) {
        if (ent->d_type != DT_DIR || !isdigit(ent->d_name[0])) continue;
        pid_t pid = atoi(ent->d_name);

        int pid_fd = openat(proc_fd, ent->d_name, O_RDONLY | O_DIRECTORY);
        if (pid_fd == -1) continue;

        ProcEntryCache* entry = get_proc_entry(cache, pid, pid_fd);
        if (!entry) {
            close(pid_fd);
            continue;
        }

        char* name = strrchr(entry->cmdline, '/') ? strrchr(entry->cmdline, '/') + 1 : entry->cmdline;

        // 检查精确匹配
        PackageEntry* pkg_entry;
        HASH_FIND_STR(cfg->pkg_table, name, pkg_entry);
        bool matched = (pkg_entry != NULL);

        // 如果没有精确匹配，检查通配符规则
        if (!matched) {
            for (size_t i = 0; i < cfg->num_wildcard_rules; i++) {
                const AffinityRule* rule = cfg->wildcard_rules[i];
                if (fnmatch(rule->pkg, name, FNM_NOESCAPE) == 0) {
                    LOG_I("Matched wildcard rule %s for process %s", rule->pkg, name);
                    matched = true;
                    break;
                }
            }
        }

        if (!matched) {
            close(pid_fd);
            continue;
        }

        procs = xrealloc(procs, (num_procs + 1) * sizeof(ProcessInfo));
        if (!procs) {
            close(pid_fd);
            closedir(proc_dir);
            return cache;
        }
        ProcessInfo* proc = &procs[num_procs++];
        proc->pid = pid;
        strncpy(proc->pkg, name, MAX_PKG_LEN - 1);
        CPU_ZERO(&proc->base_cpus);
        proc->threads = NULL;
        proc->num_threads = 0;
        proc->thread_rules = NULL;
        proc->num_thread_rules = 0;
        proc->scanned = false;

        // 应用所有匹配的规则（精确和通配符）
        for (size_t i = 0; i < cfg->num_rules; i++) {
            const AffinityRule* rule = &cfg->rules[i];
            if ((strcmp(rule->pkg, proc->pkg) == 0) ||
                (rule->is_wildcard && fnmatch(rule->pkg, proc->pkg, FNM_NOESCAPE) == 0)) {
                if (rule->thread[0]) {
                    proc->thread_rules = xrealloc(proc->thread_rules,
                       (proc->num_thread_rules + 1) * sizeof(AffinityRule*));
                    proc->thread_rules[proc->num_thread_rules++] = (AffinityRule*)rule;
                } else {
                    CPU_OR(&proc->base_cpus, &proc->base_cpus, &rule->cpus);
                }
            }
        }

        if (proc->num_thread_rules == 0 && CPU_COUNT(&proc->base_cpus) == 0) {
            free(proc->thread_rules);
            num_procs--;
            close(pid_fd);
            continue;
        }

        if (!scan_process_threads(proc, pid_fd)) {
            free(proc->thread_rules);
            num_procs--;
        }
        close(pid_fd);
    }
    closedir(proc_dir);

    if (cache->procs) {
        for (size_t i = 0; i < cache->num_procs; i++) {
            free(cache->procs[i].threads);
            free(cache->procs[i].thread_rules);
        }
        free(cache->procs);
    }
    cache->procs = procs;
    cache->num_procs = num_procs;
    cache->last_update = now;
    return cache;
}

static bool apply_affinity(ProcessInfo* proc, const CpuTopology* topo) {
    bool applied = false;
    for (size_t i = 0; i < proc->num_threads; i++) {
        ThreadInfo* ti = &proc->threads[i];
        if (kill(ti->tid, 0) != 0) continue;
        if (CPU_EQUAL(&ti->cpus, &ti->last_cpus)) continue;

        if (topo->cpuset_enabled) {
            int fd = open("/dev/cpuset/AppOpt/tasks", O_WRONLY | O_APPEND);
            if (fd >= 0) {
                dprintf(fd, "%d\n", ti->tid);
                close(fd);
            }
        }
        if (sched_setaffinity(ti->tid, sizeof(ti->cpus), &ti->cpus) == 0) {
            ti->last_cpus = ti->cpus;
            applied = true;
        } else {
            LOG_E("Failed to set affinity for %s (TID %d): %s", ti->name, ti->tid, strerror(errno));
        }
    }
    return applied;
}

// 主函数
static bool last_logged_screen_state = true;

static bool is_screen_on(void) {
    const char* backlight_path = "/sys/class/backlight/panel0-backlight/brightness";
    int fd = open(backlight_path, O_RDONLY);
    if (fd >= 0) {
        char buf[32] = {0};
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0) {
            long value = strtol(buf, NULL, 10);
            return value > 0;
        }
        return true;
    }
    
    FILE* fp = popen("dumpsys deviceidle get screen 2>/dev/null", "r");
    if (fp) {
        char buf[32] = {0};
        size_t n = fread(buf, 1, sizeof(buf) - 1, fp);
        buf[n] = '\0';
        pclose(fp);
        return (strstr(buf, "false") == NULL);
    }
    
    return true;
}

static void cleanup(AppConfig* config, ProcCache* cache) {
    if (inotify_wd != -1) inotify_rm_watch(inotify_fd, inotify_wd);
    if (inotify_fd != -1) close(inotify_fd);
    if (log_fp) fclose(log_fp);
    
    for (size_t i = 0; i < cache->num_procs; i++) {
        free(cache->procs[i].threads);
        free(cache->procs[i].thread_rules);
    }
    free(cache->procs);
    cleanup_proc_cache(cache);
    
    free(config->rules);
    free(config->wildcard_rules); // 新增：清理通配符规则数组
    for (size_t i = 0; i < config->num_pkgs; i++) 
        free(config->pkgs[i]);
    free(config->pkgs);
    PackageEntry *entry, *tmp;
    HASH_ITER(hh, config->pkg_table, entry, tmp) {
        HASH_DEL(config->pkg_table, entry);
        free(entry);
    }
}

int main(int argc, char* argv[]) {
    const char* config_file = DEFAULT_CONFIG_FILE;

    set_default_log_path(config_file);

    for (int i = 1; i < argc; i++) {
        if (strncmp(argv[i], "-f", 2) == 0 && i + 1 < argc) {
            config_file = argv[++i];
            set_default_log_path(config_file);
        } else if (strncmp(argv[i], "--log=", 6) == 0) {
            strncpy(log_file_path, argv[i] + 6, sizeof(log_file_path) - 1);
            log_file_path[sizeof(log_file_path) - 1] = '\0';
        } else if (strncmp(argv[i], "--debug=", 8) == 0) {
            const char* debug_val = argv[i] + 8;
            log_enabled = (strcmp(debug_val, "true") == 0);
            debug_set_from_args = true;
        } else if (strncmp(argv[i], "--minimal-log", 13) == 0) {
            log_minimal = true; // 新增：启用最小日志模式
        } else {
            fprintf(stderr, "Unknown argument: %s\n", argv[i]);
            fprintf(stderr, "Usage: %s [-f config_file] [--log=log_file] [--debug=(true|false)] [--minimal-log]\n", argv[0]);
            return 1;
        }
    }

    LOG_I("Affinity Manager started, PID: %d", getpid());
    AppConfig config = { .topo = init_cpu_topo(), .mtime = 0, .pkg_table = NULL };
    ProcCache cache = { .proc_cache = NULL };
    time_t last_config_check = 0, last_affinity_time = 0, last_screen_check = 0;
    const struct timespec short_delay = {SHORT_DELAY_SECONDS, SHORT_DELAY_NANOSECONDS};
    const struct timespec long_delay = {LONG_DELAY_SECONDS, LONG_DELAY_NANOSECONDS};
    const struct timespec screen_off_delay = {30, 0};
    bool screen_state_cached = true;

    const char* backlight_path = "/sys/class/backlight/panel0-backlight/brightness";
    bool backlight_exists = (access(backlight_path, F_OK) == 0);
    int screen_check_interval = backlight_exists ? 5 : 30;

    if (debug_set_from_args) {
        LOG_I("Debug mode set from command line: %s", log_enabled ? "true" : "false");
    }
    if (log_minimal) {
        LOG_I("Minimal log mode enabled");
    }
    load_config(&config, config_file);
    init_inotify(config_file);

    for (;;) {
        time_t now = time(NULL);

        if (now - last_screen_check >= screen_check_interval) {
            screen_state_cached = is_screen_on();
            last_screen_check = now;
        }
        bool screen_on = screen_state_cached;
        if (screen_on != last_logged_screen_state) {
            LOG_I("Screen state changed to: %s", screen_on ? "ON" : "OFF");
            last_logged_screen_state = screen_on;
            // 屏幕从关闭变为开启时立即加载配置文件
            if (screen_on) {
                if (load_config(&config, config_file)) {
                    cache.last_update = 0; // 强制刷新缓存
                    LOG_I("Config reloaded immediately after screen turned ON");
                }
            }
        }

        if (!screen_on) {
            nanosleep(&screen_off_delay, NULL);
            cache.last_update = 0;
            continue;
        }

        fd_set readfds;
        struct timeval tv = { .tv_sec = CONFIG_RELOAD_TIME, .tv_usec = 0 };
        FD_ZERO(&readfds);
        if (inotify_fd != -1) FD_SET(inotify_fd, &readfds);
        int max_fd = inotify_fd != -1 ? inotify_fd + 1 : 0;

        int ret = select(max_fd, &readfds, NULL, NULL, &tv);
        if (ret < 0) {
            LOG_E("Select failed: %s", strerror(errno));
        } else if (ret > 0 && inotify_fd != -1 && FD_ISSET(inotify_fd, &readfds)) {
            if (check_inotify_config_change(config_file)) {
                if (load_config(&config, config_file)) {
                    cache.last_update = 0;
                }
            }
        } else if (ret == 0) {
            if (load_config(&config, config_file)) {
                cache.last_update = 0;
            }
        }
        last_config_check = now;

        update_proc_cache(&cache, &config);

        bool applied = false;
        for (size_t i = 0; i < cache.num_procs; i++) {
            applied |= apply_affinity(&cache.procs[i], &config.topo);
        }
        if (applied) last_affinity_time = now;

        struct timespec delay = (now - last_affinity_time <= 5) ? short_delay : long_delay;
        nanosleep(&delay, NULL);
    }

    cleanup(&config, &cache);
    return 0;
}
### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)

### 更新日志
> 20.1
- 优化上个版本通配符的性能消耗。
> 20.0
- 添加**进程通配符优先级排序**，和线程优先级逻辑一致。
> 19.9
- 删除了`riscv64`架构(**毕竟也没有人用**)，节省模块体积。
- 修复`AppOpt`一个配置文件更新可能存在的bug。
- 调整**三角洲行动、我的世界线程**。
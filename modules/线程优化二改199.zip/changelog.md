### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)

### 更新日志
> 19.9
- 删除了`riscv64`架构(**毕竟也没有人用**)，节省模块体积。
- 修复`AppOpt`一个配置文件更新可能存在的bug。
- 调整**三角洲行动、我的世界线程**。
> 19.8
- 修改`Aloazny.sh`对`/`或者`\/`开头的不做`#`注释。
- 调整`cpu_control.sh`，将`magiskd`/`zygiskd`/`charge_logger`/`mdnsd`/`logd`放到小核簇。
> 19.7
- 完善初音未来: 缤纷舞台 (`com.hermes.mk`,`com.sega.pjsekai`,`com.hermes.mk.asia`,`com.hermes.mk.bilibili`)，BanG Dream! 少女樂團派對 (`com.bilibili.star.bili`,`jp.co.craftegg.band`,`com.bushiroad.en.bangdreamgbp`,`net.gamon.bdTW`)适配。
- 添加学园偶像大师(`com.bandainamcoent.idolmaster_gakuen`)适配。
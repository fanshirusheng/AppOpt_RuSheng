#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <fnmatch.h>
#include <sched.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#include <sys/select.h>
#include <libgen.h>
#include "uthash.h"

// 常量定义
#define MAX_LOG_SIZE (100 * 1024)
#define DEFAULT_CONFIG_FILE "./applist.conf"
#define CONFIG_RELOAD_TIME 10
#define PROC_CACHE_TIME 9
#define MAX_PKG_LEN 128
#define MAX_THREAD_LEN 64
#define PROC_ENTRY_CACHE_TIME 5
#define BASE_CPUSET "/dev/cpuset/AppOpt"
#define MAX_ERROR_CACHE_SIZE 1000
#define ERROR_CACHE_TIMEOUT (600)

// 日志宏
#define LOG_I(fmt, ...) do { if (log_enabled && !log_minimal) write_log("[I] " fmt, ##__VA_ARGS__); } while (0)
#define LOG_W(fmt, ...) do { if (log_enabled) write_log("[W] " fmt, ##__VA_ARGS__); } while (0)
#define LOG_E(fmt, ...) do { if (log_enabled) write_log("[E] " fmt, ##__VA_ARGS__); } while (0)

// 数据结构
typedef struct {
    char pkg[MAX_PKG_LEN];
    char thread[MAX_THREAD_LEN];
    cpu_set_t cpus;
    bool is_wildcard;
    int priority;
    char cpuset_dir[256];
} AffinityRule;

typedef struct {
    pid_t tid;
    char name[MAX_THREAD_LEN];
    cpu_set_t cpus;
    cpu_set_t last_cpus;
    bool failed;
} ThreadInfo;

typedef struct {
    pid_t pid;
    char pkg[MAX_PKG_LEN];
    cpu_set_t base_cpus;
    ThreadInfo* threads;
    size_t num_threads;
    AffinityRule** thread_rules;
    size_t num_thread_rules;
    bool scanned;
} ProcessInfo;

typedef struct {
    cpu_set_t present_cpus;
    bool cpuset_enabled;
    char present_str[256];
    char mems_str[32];
} CpuTopology;

typedef struct {
    pid_t pid;
    char cmdline[MAX_PKG_LEN];
    time_t last_update;
    UT_hash_handle hh;
} ProcEntryCache;

typedef struct {
    AffinityRule* rules;
    size_t num_rules;
    AffinityRule** wildcard_rules;
    size_t num_wildcard_rules;
    time_t mtime;
    CpuTopology topo;
    char** pkgs;
    size_t num_pkgs;
    struct PackageEntry* pkg_table;
    char cpuset_base[256];
} AppConfig;

typedef struct PackageEntry {
    char pkg[MAX_PKG_LEN];
    UT_hash_handle hh;
} PackageEntry;

typedef struct {
    ProcessInfo* procs;
    size_t num_procs;
    time_t last_update;
    ProcEntryCache* proc_cache;
    int last_proc_count;
} ProcCache;

typedef struct {
    char key[512];
    time_t last_update;
    UT_hash_handle hh;
} ThreadErrorCache;

typedef struct {
    char rule_key[512];
    time_t last_update;
    UT_hash_handle hh;
} RuleErrorCache;

// 全局变量
static bool log_enabled = false;
static bool log_minimal = false;
static FILE* log_fp = NULL;
static bool log_writing = false;
static char log_file_path[256];
static bool debug_set_from_args = false;
static ThreadErrorCache* thread_error_cache = NULL;
static RuleErrorCache* error_cache = NULL;

// 函数原型声明
static char* get_timestamp(void);
static void ensure_log_file_dir(const char* dir);
static void ensure_log_file(void);
static void check_log_size(void);
static void write_log(const char* fmt, ...);
static void set_default_log_path(const char* config_file);
static void* xrealloc(void* ptr, size_t size);
static char* strtrim(char* s);
static char* cpu_set_to_str(const cpu_set_t* set);
static bool create_cpuset_dir(const char* path, const char* cpus, const char* mems);
static void parse_cpu_ranges(const char* spec, cpu_set_t* set, const cpu_set_t* present);
static CpuTopology init_cpu_topo(void);
static int calculate_rule_priority(const char* thread_pattern);
static void cleanup_temp_resources(AffinityRule** rules, size_t num_rules, AffinityRule*** wildcard_rules, size_t num_wildcard_rules, PackageEntry** pkg_table);
static bool load_config(AppConfig* cfg, const char* config_file);
static ProcEntryCache* get_proc_entry(ProcCache* cache, pid_t pid, int pid_fd);
static void cleanup_proc_cache(ProcCache* cache);
static bool scan_process_threads(ProcessInfo* proc, int pid_fd, const AppConfig* cfg);
static int compare_rules(const void* a, const void* b);
static int get_proc_count(void);
static ProcCache* update_proc_cache(ProcCache* cache, const AppConfig* cfg);
static bool apply_affinity(ProcessInfo* proc, const CpuTopology* topo, ProcCache* cache);
static void update_cache(ProcCache* cache, const AppConfig* cfg, int* affinity_counter);
static bool is_screen_on(void);
static void cleanup(AppConfig* config, ProcCache* cache);

// 日志模块
// 获取当前时间戳
static char* get_timestamp(void) {
    static char buf[32];
    time_t now = time(NULL);
    struct tm* tm = localtime(&now);
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", tm);
    return buf;
}

// 确保日志文件目录存在
static void ensure_log_file_dir(const char* dir) {
    struct stat st;
    if (stat(dir, &st) == 0) return;

    char* parent_dir = strdup(dir);
    if (!parent_dir) {
        fprintf(stderr, "Failed to allocate memory for parent directory path\n");
        return;
    }
    char* parent = dirname(parent_dir);
    if (strcmp(parent, dir) != 0) ensure_log_file_dir(parent);
    free(parent_dir);

    if (mkdir(dir, 0755) != 0 && errno != EEXIST) {
        fprintf(stderr, "Failed to create directory %s: %s\n", dir, strerror(errno));
    }
}

// 确保日志文件存在
static void ensure_log_file(void) {
    struct stat st;
    if (!log_fp || (stat(log_file_path, &st) != 0 && errno == ENOENT)) {
        if (log_fp) {
            fclose(log_fp);
            log_fp = NULL;
        }
        char* log_dir = strdup(log_file_path);
        if (!log_dir) {
            fprintf(stderr, "Failed to allocate memory for log directory path\n");
            return;
        }
        char* dir = dirname(log_dir);
        ensure_log_file_dir(dir);
        free(log_dir);

        log_fp = fopen(log_file_path, "a");
        if (!log_fp) {
            fprintf(stderr, "Failed to open log file %s: %s\n", log_file_path, strerror(errno));
        } else {
            LOG_I("Log file %s opened or created", log_file_path);
        }
    }
}

// 检查日志文件大小，超限时清空
static void check_log_size(void) {
    if (log_writing || !log_fp) return;
    struct stat st;
    if (stat(log_file_path, &st) == 0 && st.st_size >= MAX_LOG_SIZE) {
        fclose(log_fp);
        log_fp = fopen(log_file_path, "w");
        if (log_fp) fclose(log_fp);
        log_fp = NULL;
    }
}

// 写入日志
static void write_log(const char* fmt, ...) {
    ensure_log_file();
    if (!log_fp) return;

    check_log_size();
    if (!log_fp) {
        ensure_log_file();
        if (!log_fp) {
            fprintf(stderr, "Failed to reopen log file %s after size check\n", log_file_path);
            return;
        }
    }

    log_writing = true;
    va_list args;
    va_start(args, fmt);
    if (fprintf(log_fp, "[%s] ", get_timestamp()) < 0 ||
        vfprintf(log_fp, fmt, args) < 0 ||
        fprintf(log_fp, "\n") < 0 ||
        fflush(log_fp) != 0) {
        fprintf(stderr, "Failed to write to log file %s: %s\n", log_file_path, strerror(errno));
        fclose(log_fp);
        log_fp = NULL;
        ensure_log_file();
        if (log_fp) {
            va_list args2;
            va_start(args2, fmt);
            fprintf(log_fp, "[%s] ", get_timestamp());
            vfprintf(log_fp, fmt, args2);
            fprintf(log_fp, "\n");
            if (fflush(log_fp) != 0) {
                fprintf(stderr, "Failed to flush log file %s after retry: %s\n",
                        log_file_path, strerror(errno));
                fclose(log_fp);
                log_fp = NULL;
            }
            va_end(args2);
        } else {
            fprintf(stderr, "Failed to reopen log file %s after write failure\n", log_file_path);
        }
    }
    va_end(args);
    log_writing = false;
}

// 设置默认日志路径
static void set_default_log_path(const char* config_file) {
    char* last_slash = strrchr(config_file, '/');
    size_t config_len = strlen(config_file);
    size_t log_suffix_len = strlen("affinity_manager.log");

    if (last_slash) {
        size_t dir_len = last_slash - config_file + 1;
        if (dir_len + log_suffix_len + 1 > sizeof(log_file_path)) {
            LOG_W("Config file path too long, using default log file: affinity_manager.log");
            strncpy(log_file_path, "affinity_manager.log", sizeof(log_file_path) - 1);
        } else {
            strncpy(log_file_path, config_file, dir_len);
            log_file_path[dir_len] = '\0';
            strncat(log_file_path, "affinity_manager.log", sizeof(log_file_path) - dir_len - 1);
        }
    } else {
        if (log_suffix_len + 1 > sizeof(log_file_path)) {
            LOG_W("Log file name too long, truncating");
            strncpy(log_file_path, "affinity_manager.log", sizeof(log_file_path) - 1);
        } else {
            strncpy(log_file_path, "affinity_manager.log", sizeof(log_file_path) - 1);
        }
    }
    log_file_path[sizeof(log_file_path) - 1] = '\0';
}

// 工具函数
// 重新分配内存
static inline void* xrealloc(void* ptr, size_t size) {
    void* p = realloc(ptr, size);
    if (!p) {
        free(ptr);
        return NULL;
    }
    return p;
}

// 去除字符串首尾空白
static inline char* strtrim(char* s) {
    while (isspace((unsigned char)*s)) s++;
    if (!*s) return s;
    char* end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end)) end--;
    end[1] = '\0';
    return s;
}

// 将 CPU 集合转换为字符串
static char* cpu_set_to_str(const cpu_set_t* set) {
    size_t buf_size = 8 * CPU_SETSIZE;
    char* buf = malloc(buf_size);
    if (!buf) return NULL;
    int start = -1, end = -1;
    char* p = buf;
    size_t remain = buf_size - 1;
    bool first = true;

    for (int i = 0; i < CPU_SETSIZE; i++) {
        if (CPU_ISSET(i, set)) {
            if (start == -1) {
                start = end = i;
            } else if (i == end + 1) {
                end = i;
            } else {
                int needed;
                if (start == end) {
                    needed = snprintf(p, remain + 1, "%s%d", first ? "" : ",", start);
                } else {
                    needed = snprintf(p, remain + 1, "%s%d-%d", first ? "" : ",", start, end);
                }
                if (needed < 0 || (size_t)needed > remain) {
                    free(buf);
                    return NULL;
                }
                p += needed;
                remain -= needed;
                start = end = i;
                first = false;
            }
        }
    }
    if (start != -1) {
        int needed;
        if (start == end) {
            needed = snprintf(p, remain + 1, "%s%d", first ? "" : ",", start);
        } else {
            needed = snprintf(p, remain + 1, "%s%d-%d", first ? "" : ",", start, end);
        }
        if (needed < 0 || (size_t)needed > remain) {
            free(buf);
            return NULL;
        }
        p += needed;
    }
    *p = '\0';
    return buf;
}

// 创建 cpuset 目录并配置
static bool create_cpuset_dir(const char* path, const char* cpus, const char* mems) {
    struct stat st;
    bool need_create = true;
    if (stat(path, &st) == 0 && S_ISDIR(st.st_mode)) {
        if ((st.st_mode & 0755) == 0755 && st.st_uid == 0 && st.st_gid == 0) {
            need_create = false;
        }
    }
    if (need_create) {
        if (access(path, W_OK) != 0 && errno != ENOENT) {
            LOG_E("No write permission for %s: %s", path, strerror(errno));
            return false;
        }
        if (mkdir(path, 0755) != 0 && errno != EEXIST) {
            LOG_E("Failed to create cpuset dir %s: %s", path, strerror(errno));
            return false;
        }
        if (chmod(path, 0755) != 0) {
            LOG_E("Failed to chmod cpuset dir %s: %s", path, strerror(errno));
            return false;
        }
        if (chown(path, 0, 0) != 0) {
            LOG_E("Failed to chown cpuset dir %s: %s", path, strerror(errno));
            return false;
        }
    }

    char existing_cpus[256] = {0};
    char cpus_path[256];
    snprintf(cpus_path, sizeof(cpus_path), "%s/cpus", path);
    int cpus_fd = open(cpus_path, O_RDONLY);
    if (cpus_fd >= 0) {
        ssize_t n = read(cpus_fd, existing_cpus, sizeof(existing_cpus) - 1);
        close(cpus_fd);
        if (n > 0) {
            existing_cpus[n] = '\0';
            if (strcmp(existing_cpus, cpus) == 0) {
                goto check_mems;
            }
        } else if (n < 0) {
            LOG_W("Failed to read %s: %s", cpus_path, strerror(errno));
        }
    }
    cpus_fd = open(cpus_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (cpus_fd < 0) {
        LOG_E("Failed to open %s: %s", cpus_path, strerror(errno));
        return false;
    }
    if (write(cpus_fd, cpus, strlen(cpus)) != (ssize_t)strlen(cpus)) {
        close(cpus_fd);
        LOG_E("Failed to write to %s: %s", cpus_path, strerror(errno));
        return false;
    }
    close(cpus_fd);

check_mems: {
    char existing_mems[256] = {0};
    char mems_path[256];
    snprintf(mems_path, sizeof(mems_path), "%s/mems", path);
    int mems_fd = open(mems_path, O_RDONLY);
    if (mems_fd >= 0) {
        ssize_t n = read(mems_fd, existing_mems, sizeof(existing_mems) - 1);
        close(mems_fd);
        if (n > 0) {
            existing_mems[n] = '\0';
            if (strcmp(existing_mems, mems) == 0) {
                return true;
            }
        } else if (n < 0) {
            LOG_W("Failed to read %s: %s", mems_path, strerror(errno));
        }
    }
    mems_fd = open(mems_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (mems_fd < 0) {
        LOG_E("Failed to open %s: %s", mems_path, strerror(errno));
        return false;
    }
    if (write(mems_fd, mems, strlen(mems)) != (ssize_t)strlen(mems)) {
        close(mems_fd);
        LOG_E("Failed to write to %s: %s", mems_path, strerror(errno));
        return false;
    }
    close(mems_fd);
}
    return true;
}

// CPU 拓扑管理

// 解析 CPU 范围
static void parse_cpu_ranges(const char* spec, cpu_set_t* set, const cpu_set_t* present) {
    if (!spec) return;
    char* copy = strdup(spec);
    if (!copy) {
        LOG_E("Failed to allocate memory for parsing CPU ranges");
        return;
    }
    char* s = copy;

    while (*s) {
        char* end;
        unsigned long a = strtoul(s, &end, 10);
        if (end == s) {
            s++;
            continue;
        }

        unsigned long b = a;
        if (*end == '-') {
            s = end + 1;
            b = strtoul(s, &end, 10);
            if (end == s) b = a;
        }

        if (a > b) {
            unsigned long t = a;
            a = b;
            b = t;
        }
        for (unsigned long i = a; i <= b && i < CPU_SETSIZE; i++) {
            if (present && !CPU_ISSET(i, present)) continue;
            CPU_SET(i, set);
        }

        s = (*end == ',') ? end + 1 : end;
    }
    free(copy);
}

// 初始化 CPU 拓扑
static CpuTopology init_cpu_topo(void) {
    CpuTopology topo = { .cpuset_enabled = false };
    CPU_ZERO(&topo.present_cpus);

    int fd = open("/sys/devices/system/cpu/present", O_RDONLY);
    if (fd >= 0) {
        char buf[64] = {0};
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0) {
            char* p = strtrim(buf);
            char* end = strchr(p, '\n');
            if (end) *end = '\0';
            strncpy(topo.present_str, p, sizeof(topo.present_str) - 1);
            parse_cpu_ranges(topo.present_str, &topo.present_cpus, NULL);
        }
    } else {
        LOG_W("Failed to read /sys/devices/system/cpu/present: %s", strerror(errno));
    }

    if (access("/dev/cpuset", W_OK) != 0) {
        LOG_E("No write permission for /dev/cpuset: %s", strerror(errno));
        return topo;
    }

    const char* cpuset_dir = BASE_CPUSET;
    if (mkdir(cpuset_dir, 0755) != 0 && errno != EEXIST) {
        LOG_E("Failed to create %s: %s", cpuset_dir, strerror(errno));
        return topo;
    }

    if (!create_cpuset_dir(cpuset_dir, topo.present_str, "0")) {
        LOG_E("Failed to initialize cpuset %s", cpuset_dir);
        return topo;
    }

    char mems_path[256];
    snprintf(mems_path, sizeof(mems_path), "%s/mems", cpuset_dir);
    int mems_fd = open(mems_path, O_RDONLY);
    if (mems_fd >= 0) {
        ssize_t n = read(mems_fd, topo.mems_str, sizeof(topo.mems_str) - 1);
        close(mems_fd);
        if (n > 0) {
            topo.mems_str[n] = '\0';
            strtrim(topo.mems_str);
        } else {
            strcpy(topo.mems_str, "0");
        }
    } else {
        strcpy(topo.mems_str, "0");
    }

    topo.cpuset_enabled = true;
    return topo;
}

// 配置管理

// 计算规则优先级
static int calculate_rule_priority(const char* thread_pattern) {
    if (!thread_pattern || !*thread_pattern) {
        return 200;
    }
    int priority = 0;
    size_t len = strlen(thread_pattern);
    const char* p = thread_pattern;

    if (strchr(p, '*') == NULL && strchr(p, '?') == NULL && strchr(p, '[') == NULL) {
        return 1000 + len;
    }

    int non_wildcard_chars = 0;
    bool has_range = false;
    bool has_single_wildcard = false;
    bool has_star = false;

    while (*p) {
        if (*p == '[') has_range = true;
        else if (*p == '?') has_single_wildcard = true;
        else if (*p == '*') has_star = true;
        else non_wildcard_chars++;
        p++;
    }

    if (has_range) {
        priority = 500 + non_wildcard_chars;
    } else if (has_single_wildcard) {
        priority = 300 + non_wildcard_chars;
    } else if (has_star) {
        priority = 100 + non_wildcard_chars;
    }

    return priority;
}

// 清理临时资源
static void cleanup_temp_resources(AffinityRule** rules, size_t num_rules, AffinityRule*** wildcard_rules, size_t num_wildcard_rules, PackageEntry** pkg_table) {
    if (rules && *rules) free(*rules);
    if (wildcard_rules && *wildcard_rules) free(*wildcard_rules);
    if (pkg_table && *pkg_table) {
        PackageEntry* entry, *tmp;
        HASH_ITER(hh, *pkg_table, entry, tmp) {
            HASH_DEL(*pkg_table, entry);
            free(entry);
        }
    }
}

// 加载配置文件
static bool load_config(AppConfig* cfg, const char* config_file) {
    struct stat st;
    if (stat(config_file, &st) != 0) {
        LOG_W("Config file %s not found, waiting 5 seconds before creating empty file", config_file);
        struct timespec delay = { .tv_sec = 5, .tv_nsec = 0 };
        nanosleep(&delay, NULL);

        if (stat(config_file, &st) != 0) {
            FILE* fp = fopen(config_file, "w");
            if (fp) {
                fclose(fp);
                LOG_I("Created empty config file %s", config_file);
            } else {
                LOG_E("Failed to create config file %s: %s", config_file, strerror(errno));
                return false;
            }
        } else {
            LOG_I("Config file %s appeared during delay, skipping creation", config_file);
        }
        return false;
    }

    if (st.st_mtime <= cfg->mtime) return false;

    FILE* fp = fopen(config_file, "r");
    if (!fp) {
        LOG_E("Failed to open %s: %s", config_file, strerror(errno));
        return false;
    }

    AffinityRule* rules = NULL;
    size_t num_rules = 0;
    AffinityRule** wildcard_rules = NULL;
    size_t num_wildcard_rules = 0;
    bool log_set = false;
    char line[256];
    PackageEntry* pkg_table = NULL;
    size_t line_number = 0;

    while (fgets(line, sizeof(line), fp)) {
        line_number++;
        char* p = strtrim(line);
        if (!*p || *p == '#') continue;

        char* eq = strchr(p, '=');
        if (!eq) {
            LOG_W("Invalid rule at line %zu: missing '=': %s", line_number, p);
            continue;
        }
        *eq++ = '\0';

        char* key = strtrim(p);
        char* value = strtrim(eq);

        char* comment = strchr(value, '#');
        if (comment) *comment = '\0';
        value = strtrim(value);

        if (!*key || !*value) {
            LOG_W("Invalid rule at line %zu: empty key or value: %s", line_number, p);
            continue;
        }

        if (!strcmp(key, "Debug_AppOpt")) {
            if (log_set || debug_set_from_args) continue;
            log_enabled = !strcmp(value, "true");
            log_set = true;
            LOG_I("Debug_AppOpt set to %s at line %zu", value, line_number);
            continue;
        }

        char* br = strchr(key, '{');
        char* thread = "";
        if (br) {
            *br++ = '\0';
            char* eb = strchr(br, '}');
            if (!eb) {
                LOG_W("Invalid rule at line %zu: missing closing '}': %s", line_number, p);
                continue;
            }
            *eb = '\0';
            thread = strtrim(br);
        }

        char* pkg = strtrim(key);
        if (strlen(pkg) >= MAX_PKG_LEN || strlen(thread) >= MAX_THREAD_LEN) {
            LOG_W("Invalid rule at line %zu: package or thread name too long: %s", line_number, p);
            continue;
        }

        if (!thread[0]) {
            LOG_I("Process(empty) rule at line %zu: %s=%s", line_number, pkg, value);
        } else if (strcmp(thread, " ") == 0) {
            LOG_I("Space-only thread name at line %zu: %s{%s}=%s", line_number, pkg, thread, value);
        } else {
            LOG_I("Loaded rule at line %zu: %s{%s}=%s", line_number, pkg, thread, value);
        }

        bool is_duplicate = false;
        for (size_t i = 0; i < num_rules; i++) {
            if (!strcmp(rules[i].pkg, pkg) && !strcmp(rules[i].thread, thread)) {
                LOG_W("Duplicate rule at line %zu: %s{%s}=%s, please check configuration",
                      line_number, pkg, thread, value);
                is_duplicate = true;
                break;
            }
        }
        if (is_duplicate) continue;

        AffinityRule* temp_rules = xrealloc(rules, (num_rules + 1) * sizeof(AffinityRule));
        if (!temp_rules) {
            LOG_E("Memory allocation failed at line %zu", line_number);
            fclose(fp);
            cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
            return false;
        }
        rules = temp_rules;

        AffinityRule* rule = &rules[num_rules];
        strncpy(rule->pkg, pkg, MAX_PKG_LEN - 1);
        rule->pkg[MAX_PKG_LEN - 1] = '\0';
        strncpy(rule->thread, thread, MAX_THREAD_LEN - 1);
        rule->thread[MAX_THREAD_LEN - 1] = '\0';
        CPU_ZERO(&rule->cpus);
        parse_cpu_ranges(value, &rule->cpus, &cfg->topo.present_cpus);
        rule->is_wildcard = (strchr(pkg, '*') != NULL || strchr(pkg, '?') != NULL);
        rule->priority = calculate_rule_priority(rule->thread);

        if (CPU_COUNT(&rule->cpus) == 0) {
            LOG_E("Invalid CPU range at line %zu: %s in rule: %s{%s}=%s, check available CPUs (%s)",
                  line_number, value, pkg, thread, value, cfg->topo.present_str);
            continue; // 不增加 num_rules，跳过此规则
        }

        char* dir_name = cpu_set_to_str(&rule->cpus);
        if (!dir_name) {
            LOG_E("Failed to convert CPU set to string at line %zu", line_number);
            continue;
        }
        char cpuset_path[256];
        snprintf(cpuset_path, sizeof(cpuset_path), "%s/%s", cfg->cpuset_base, dir_name);
        if (!create_cpuset_dir(cpuset_path, dir_name, cfg->topo.mems_str)) {
            LOG_E("Failed to create cpuset directory %s at line %zu", cpuset_path, line_number);
            free(dir_name);
            continue;
        }
        strncpy(rule->cpuset_dir, dir_name, sizeof(rule->cpuset_dir) - 1);
        rule->cpuset_dir[sizeof(rule->cpuset_dir) - 1] = '\0';
        free(dir_name);

        num_rules++;

        if (!rule->is_wildcard) {
            PackageEntry* pkg_entry;
            HASH_FIND_STR(pkg_table, pkg, pkg_entry);
            if (!pkg_entry) {
                pkg_entry = malloc(sizeof(PackageEntry));
                if (!pkg_entry) {
                    LOG_E("Memory allocation failed for pkg_entry at line %zu", line_number);
                    fclose(fp);
                    cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
                    return false;
                }
                strncpy(pkg_entry->pkg, pkg, MAX_PKG_LEN - 1);
                pkg_entry->pkg[MAX_PKG_LEN - 1] = '\0';
                HASH_ADD_STR(pkg_table, pkg, pkg_entry);
            }
        } else {
            AffinityRule** temp_wildcard_rules = xrealloc(wildcard_rules, (num_wildcard_rules + 1) * sizeof(AffinityRule*));
            if (!temp_wildcard_rules) {
                LOG_E("Memory allocation failed for wildcard_rules at line %zu", line_number);
                fclose(fp);
                cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
                return false;
            }
            wildcard_rules = temp_wildcard_rules;
            wildcard_rules[num_wildcard_rules++] = rule;
        }
    }
    fclose(fp);

    if (!num_rules) {
        LOG_W("No valid rules loaded from %s", config_file);
        cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
        return false;
    }

    size_t num_pkgs = HASH_COUNT(pkg_table);
    char** pkgs = malloc(num_pkgs * sizeof(char*));
    if (!pkgs) {
        LOG_E("Memory allocation failed for pkgs array");
        cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
        return false;
    }
    PackageEntry* entry, *tmp;
    size_t i = 0;
    HASH_ITER(hh, pkg_table, entry, tmp) {
        pkgs[i] = strdup(entry->pkg);
        if (!pkgs[i]) {
            LOG_E("Memory allocation failed for pkg string at index %zu", i);
            for (size_t j = 0; j < i; j++) free(pkgs[j]);
            free(pkgs);
            cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
            return false;
        }
        i++;
    }

    LOG_I("Config loaded: %zu rules, %zu packages, %zu wildcard rules (mtime: %ld)",
          num_rules, num_pkgs, num_wildcard_rules, st.st_mtime);

    // 清理旧资源
    if (cfg->rules) free(cfg->rules);
    if (cfg->wildcard_rules) free(cfg->wildcard_rules);
    if (cfg->pkgs) {
        for (size_t j = 0; j < cfg->num_pkgs; j++) free(cfg->pkgs[j]);
        free(cfg->pkgs);
    }
    HASH_CLEAR(hh, cfg->pkg_table);
    PackageEntry* old_entry, *old_tmp;
    HASH_ITER(hh, cfg->pkg_table, old_entry, old_tmp) {
        HASH_DEL(cfg->pkg_table, old_entry);
        free(old_entry);
    }

    cfg->rules = rules;
    cfg->num_rules = num_rules;
    cfg->wildcard_rules = wildcard_rules;
    cfg->num_wildcard_rules = num_wildcard_rules;
    cfg->pkgs = pkgs;
    cfg->num_pkgs = num_pkgs;
    cfg->pkg_table = pkg_table;
    cfg->mtime = st.st_mtime;
    return true;
}

// 进程和线程管理

// 获取 /proc 条目
static ProcEntryCache* get_proc_entry(ProcCache* cache, pid_t pid, int pid_fd) {
    ProcEntryCache* entry;
    HASH_FIND_INT(cache->proc_cache, &pid, entry);

    time_t now = time(NULL);
    if (entry && (now - entry->last_update < PROC_ENTRY_CACHE_TIME)) {
        return entry;
    }

    char cmd[MAX_PKG_LEN] = {0};
    int cmd_fd = openat(pid_fd, "cmdline", O_RDONLY);
    if (cmd_fd == -1) return NULL;

    ssize_t n = read(cmd_fd, cmd, sizeof(cmd) - 1);
    close(cmd_fd);
    if (n <= 0) return NULL;
    cmd[n] = '\0';

    if (!entry) {
        entry = malloc(sizeof(ProcEntryCache));
        if (!entry) return NULL;
        entry->pid = pid;
        HASH_ADD_INT(cache->proc_cache, pid, entry);
    }
    strncpy(entry->cmdline, cmd, MAX_PKG_LEN - 1);
    entry->last_update = now;
    return entry;
}

// 清理进程缓存
static void cleanup_proc_cache(ProcCache* cache) {
    ProcEntryCache* entry, *tmp;
    time_t now = time(NULL);

    HASH_ITER(hh, cache->proc_cache, entry, tmp) {
        HASH_DEL(cache->proc_cache, entry);
        free(entry);
    }

    size_t thread_cache_size = HASH_COUNT(thread_error_cache);
    if (thread_cache_size > MAX_ERROR_CACHE_SIZE) {
        ThreadErrorCache* thread_err_entry, *thread_err_tmp;
        HASH_ITER(hh, thread_error_cache, thread_err_entry, thread_err_tmp) {
            HASH_DEL(thread_error_cache, thread_err_entry);
            free(thread_err_entry);
            if (--thread_cache_size <= MAX_ERROR_CACHE_SIZE) break;
        }
    } else {
        ThreadErrorCache* thread_err_entry, *thread_err_tmp;
        HASH_ITER(hh, thread_error_cache, thread_err_entry, thread_err_tmp) {
            if (now - thread_err_entry->last_update > ERROR_CACHE_TIMEOUT) {
                HASH_DEL(thread_error_cache, thread_err_entry);
                free(thread_err_entry);
            }
        }
    }

    size_t rule_cache_size = HASH_COUNT(error_cache);
    if (rule_cache_size > MAX_ERROR_CACHE_SIZE) {
        RuleErrorCache* rule_err_entry, *rule_err_tmp;
        HASH_ITER(hh, error_cache, rule_err_entry, rule_err_tmp) {
            HASH_DEL(error_cache, rule_err_entry);
            free(rule_err_entry);
            if (--rule_cache_size <= MAX_ERROR_CACHE_SIZE) break;
        }
    } else {
        RuleErrorCache* rule_err_entry, *rule_err_tmp;
        HASH_ITER(hh, error_cache, rule_err_entry, rule_err_tmp) {
            if (now - rule_err_entry->last_update > ERROR_CACHE_TIMEOUT) {
                HASH_DEL(error_cache, rule_err_entry);
                free(rule_err_entry);
            }
        }
    }
}

// 扫描进程线程
static bool scan_process_threads(ProcessInfo* proc, int pid_fd, const AppConfig* cfg) {
    if (proc->num_thread_rules == 0 && CPU_COUNT(&proc->base_cpus) == 0) {
        return false;
    }

    int task_fd = openat(pid_fd, "task", O_RDONLY | O_DIRECTORY);
    if (task_fd == -1) {
        LOG_E("Failed to open /proc/%d/task: %s", proc->pid, strerror(errno));
        return false;
    }

    DIR* task_dir = fdopendir(task_fd);
    if (!task_dir) {
        LOG_E("Failed to opendir /proc/%d/task: %s", proc->pid, strerror(errno));
        close(task_fd);
        return false;
    }

    ThreadInfo* threads = NULL;
    size_t num_threads = 0;

    struct dirent* ent;
    while ((ent = readdir(task_dir))) {
        if (ent->d_type != DT_DIR || !isdigit(ent->d_name[0])) continue;
        pid_t tid = atoi(ent->d_name);

        char comm_path[64];
        snprintf(comm_path, sizeof(comm_path), "%s/comm", ent->d_name);
        int comm_fd = openat(task_fd, comm_path, O_RDONLY);
        if (comm_fd == -1) {
            continue;
        }

        char tname[MAX_THREAD_LEN] = {0};
        ssize_t n = read(comm_fd, tname, sizeof(tname) - 1);
        close(comm_fd);
        if (n <= 0) {
            continue;
        }
        if (tname[n - 1] == '\n') tname[n - 1] = '\0';

        bool is_all_spaces = true;
        if (tname[0] == '\0') {
        } else {
            is_all_spaces = true;
            for (size_t i = 0; tname[i]; i++) {
                if (tname[i] != ' ') {
                    is_all_spaces = false;
                    break;
                }
            }
            if (is_all_spaces) {
                strcpy(tname, " ");
            }
        }

        cpu_set_t mask;
        CPU_ZERO(&mask);
        bool matched = false;

        for (size_t i = 0; i < proc->num_thread_rules; i++) {
            const char* rule_thread = proc->thread_rules[i]->thread;
            if (strcmp(rule_thread, tname) == 0 ||
                (rule_thread[0] == '\0' && (tname[0] == '\0' || strcmp(tname, " ") == 0))) {
                CPU_OR(&mask, &mask, &proc->thread_rules[i]->cpus);
                matched = true;
                break;
            }
            if (proc->thread_rules[i]->priority < 1000) break;
        }

        if (!matched) {
            int highest_priority = -1;
            size_t best_rule_idx = 0;
            for (size_t i = 0; i < proc->num_thread_rules; i++) {
                if (proc->thread_rules[i]->priority >= 1000) continue;
                const char* pattern = proc->thread_rules[i]->thread;
                if (fnmatch(pattern, tname, FNM_NOESCAPE) == 0) {
                    if (proc->thread_rules[i]->priority > highest_priority) {
                        highest_priority = proc->thread_rules[i]->priority;
                        best_rule_idx = i;
                    }
                }
            }
            if (highest_priority >= 0) {
                CPU_OR(&mask, &mask, &proc->thread_rules[best_rule_idx]->cpus);
                matched = true;
            }
        }

        cpu_set_t valid_mask;
        CPU_AND(&valid_mask, &mask, &cfg->topo.present_cpus);
        if (!matched && CPU_COUNT(&valid_mask) == 0 && CPU_COUNT(&proc->base_cpus) == 0) {
            continue;
        }

        ThreadInfo* temp_threads = xrealloc(threads, (num_threads + 1) * sizeof(ThreadInfo));
        if (!temp_threads) {
            LOG_E("Failed to allocate memory for threads of process %s", proc->pkg);
            free(threads);
            closedir(task_dir);
            return false;
        }
        threads = temp_threads;

        ThreadInfo* new_thread = &threads[num_threads];
        new_thread->tid = tid;
        new_thread->cpus = CPU_COUNT(&valid_mask) ? valid_mask : proc->base_cpus;
        strncpy(new_thread->name, tname, MAX_THREAD_LEN - 1);
        CPU_ZERO(&new_thread->last_cpus);

        char thread_key[512];
        snprintf(thread_key, sizeof(thread_key), "%s:%d", proc->pkg, tid);
        ThreadErrorCache* thread_entry;
        HASH_FIND_STR(thread_error_cache, thread_key, thread_entry);
        new_thread->failed = (thread_entry != NULL);

        num_threads++;
    }

    closedir(task_dir);

    // 替换旧的 threads
    free(proc->threads);
    proc->threads = threads;
    proc->num_threads = num_threads;
    proc->scanned = true;
    return true;
}

// 比较规则优先级
static int compare_rules(const void* a, const void* b) {
    AffinityRule* ra = *(AffinityRule**)a;
    AffinityRule* rb = *(AffinityRule**)b;
    return rb->priority - ra->priority;
}

// 获取进程数量
static int get_proc_count(void) {
    char buf[64];
    int fd = open("/proc/loadavg", O_RDONLY);
    if (fd == -1) {
        LOG_E("Failed to open /proc/loadavg: %s", strerror(errno));
        return -1;
    }
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) {
        LOG_E("Failed to read /proc/loadavg: %s", n == -1 ? strerror(errno) : "empty file");
        return -1;
    }
    buf[n] = '\0';

    char* pos = buf;
    for (int i = 0; i < 3; i++) {
        pos = strchr(pos, ' ');
        if (!pos) {
            LOG_W("Invalid /proc/loadavg format: missing spaces");
            return -1;
        }
        pos++;
    }
    char* slash = strchr(pos, '/');
    if (!slash || slash == pos) {
        LOG_W("Invalid /proc/loadavg format: missing or invalid slash");
        return -1;
    }

    char* endptr;
    errno = 0;
    unsigned long total = strtoul(slash + 1, &endptr, 10);
    if (endptr == slash + 1 || (*endptr != ' ' && *endptr != '\0') || errno != 0) {
        LOG_W("Invalid /proc/loadavg format: cannot parse total processes");
        return -1;
    }
    return (int)total;
}

// 更新进程缓存
static ProcCache* update_proc_cache(ProcCache* cache, const AppConfig* cfg) {
    time_t now = time(NULL);

    int current_proc_count = get_proc_count();
    bool use_proc_loadavg = (current_proc_count != -1);

    if (use_proc_loadavg) {
        if (current_proc_count > cache->last_proc_count + 5) {
            cache->last_update = 0;
        }
        cache->last_proc_count = current_proc_count;

        if (now - cache->last_update < PROC_CACHE_TIME && cache->last_update != 0) {
            return cache;
        }
    } else {
        LOG_W("Failed to get process count, bypassing PROC_CACHE_TIME and updating cache");
        cache->last_update = 0;
    }

    DIR* proc_dir = opendir("/proc");
    if (!proc_dir) {
        LOG_E("Failed to open /proc: %s", strerror(errno));
        return cache;
    }

    ProcessInfo* procs = NULL;
    size_t num_procs = 0;
    int proc_fd = dirfd(proc_dir);

    struct dirent* ent;
    while ((ent = readdir(proc_dir))) {
        if (ent->d_type != DT_DIR || !isdigit(ent->d_name[0])) continue;
        pid_t pid = atoi(ent->d_name);

        int pid_fd = openat(proc_fd, ent->d_name, O_RDONLY | O_DIRECTORY);
        if (pid_fd == -1) continue;

        ProcEntryCache* entry = get_proc_entry(cache, pid, pid_fd);
        if (!entry) {
            close(pid_fd);
            continue;
        }

        char* name = strrchr(entry->cmdline, '/') ? strrchr(entry->cmdline, '/') + 1 : entry->cmdline;

        PackageEntry* pkg_entry;
        HASH_FIND_STR(cfg->pkg_table, name, pkg_entry);
        bool matched = (pkg_entry != NULL);

        if (!matched) {
            for (size_t i = 0; i < cfg->num_wildcard_rules; i++) {
                const AffinityRule* rule = cfg->wildcard_rules[i];
                if (fnmatch(rule->pkg, name, FNM_NOESCAPE) == 0) {
                    matched = true;
                    break;
                }
            }
        }

        if (!matched) {
            close(pid_fd);
            continue;
        }

        ProcessInfo* temp_procs = xrealloc(procs, (num_procs + 1) * sizeof(ProcessInfo));
        if (!temp_procs) {
            LOG_E("Failed to allocate memory for procs");
            for (size_t i = 0; i < num_procs; i++) {
                free(procs[i].threads);
                free(procs[i].thread_rules);
            }
            free(procs);
            close(pid_fd);
            closedir(proc_dir);
            return cache;
        }
        procs = temp_procs;

        ProcessInfo* proc = &procs[num_procs++];
        proc->pid = pid;
        strncpy(proc->pkg, name, MAX_PKG_LEN - 1);
        CPU_ZERO(&proc->base_cpus);
        proc->threads = NULL;
        proc->num_threads = 0;
        proc->thread_rules = NULL;
        proc->num_thread_rules = 0;
        proc->scanned = false;

        for (size_t i = 0; i < cfg->num_rules; i++) {
            const AffinityRule* rule = &cfg->rules[i];
            if ((strcmp(rule->pkg, proc->pkg) == 0) ||
                (rule->is_wildcard && fnmatch(rule->pkg, proc->pkg, FNM_NOESCAPE) == 0)) {
                if (rule->thread[0] || strcmp(rule->thread, " ") == 0) {
                    AffinityRule** temp_thread_rules = xrealloc(proc->thread_rules,
                        (proc->num_thread_rules + 1) * sizeof(AffinityRule*));
                    if (!temp_thread_rules) {
                        LOG_E("Failed to allocate memory for thread_rules");
                        free(proc->thread_rules);
                        proc->thread_rules = NULL;
                        proc->num_thread_rules = 0;
                        num_procs--;
                        close(pid_fd);
                        continue;
                    }
                    proc->thread_rules = temp_thread_rules;
                    proc->thread_rules[proc->num_thread_rules++] = (AffinityRule*)rule;
                } else {
                    CPU_OR(&proc->base_cpus, &proc->base_cpus, &rule->cpus);
                }
            }
        }

        if (proc->num_thread_rules > 1) {
            qsort(proc->thread_rules, proc->num_thread_rules, sizeof(AffinityRule*), compare_rules);
        }

        if (proc->num_thread_rules == 0 && CPU_COUNT(&proc->base_cpus) == 0) {
            free(proc->thread_rules);
            proc->thread_rules = NULL;
            num_procs--;
            close(pid_fd);
            continue;
        }

        if (!scan_process_threads(proc, pid_fd, cfg)) {
            free(proc->thread_rules);
            proc->thread_rules = NULL;
            num_procs--;
        }
        close(pid_fd);
    }
    closedir(proc_dir);

    // 清理旧的 cache->procs
    if (cache->procs) {
        for (size_t i = 0; i < cache->num_procs; i++) {
            free(cache->procs[i].threads);
            free(cache->procs[i].thread_rules);
        }
        free(cache->procs);
    }
    cache->procs = procs;
    cache->num_procs = num_procs;
    cache->last_update = now;
    return cache;
}

// 应用 CPU 亲和性
static bool apply_affinity(ProcessInfo* proc, const CpuTopology* topo, ProcCache* cache) {
    bool cpuset_enabled = topo->cpuset_enabled;
    cpu_set_t present_cpus = topo->present_cpus;
    bool applied = false;

    for (size_t i = 0; i < proc->num_threads; i++) {
        ThreadInfo* ti = &proc->threads[i];

        char thread_key[512];
        snprintf(thread_key, sizeof(thread_key), "%s:%d", proc->pkg, ti->tid);
        ThreadErrorCache* thread_entry;
        HASH_FIND_STR(thread_error_cache, thread_key, thread_entry);
        if (thread_entry || CPU_EQUAL(&ti->cpus, &ti->last_cpus) || ti->failed) {
            continue;
        }

        if (cpuset_enabled) {
            bool cpuset_written = false;
            for (size_t j = 0; j < proc->num_thread_rules && !cpuset_written; j++) {
                const AffinityRule* rule = proc->thread_rules[j];
                if (CPU_EQUAL(&ti->cpus, &rule->cpus)) {
                    char tasks_path[256];
                    snprintf(tasks_path, sizeof(tasks_path), "%s/%s/tasks", BASE_CPUSET, rule->cpuset_dir);
                    int fd = open(tasks_path, O_WRONLY | O_APPEND);
                    if (fd >= 0) {
                        dprintf(fd, "%d\n", ti->tid);
                        close(fd);
                        cpuset_written = true;
                    } else {
                        LOG_E("Failed to open %s: %s", tasks_path, strerror(errno));
                    }
                }
            }
            if (!cpuset_written) {
                int fd = open("/dev/cpuset/AppOpt/tasks", O_WRONLY | O_APPEND);
                if (fd >= 0) {
                    dprintf(fd, "%d\n", ti->tid);
                    close(fd);
                } else {
                    LOG_E("Failed to open /dev/cpuset/AppOpt/tasks: %s", strerror(errno));
                }
            }
        }

        cpu_set_t affinity_mask = ti->cpus;
        if (CPU_COUNT(&affinity_mask) == 0) {
            LOG_W("Empty CPU affinity for thread %s (TID %d, pkg %s), using all available CPUs",
                  ti->name, ti->tid, proc->pkg);
            affinity_mask = present_cpus;
        }

        char* mask_str = cpu_set_to_str(&affinity_mask);
        if (!mask_str) {
            LOG_E("Failed to convert CPU mask to string for thread %s (TID %d)", ti->name, ti->tid);
            continue;
        }

        if (sched_setaffinity(ti->tid, sizeof(affinity_mask), &affinity_mask) == 0) {
            ti->last_cpus = affinity_mask;
            ti->failed = false;
            applied = true;
            free(mask_str); // 释放 mask_str
        } else {
            if (errno == ESRCH) {
                cache->last_proc_count = 0;
                free(mask_str);
                continue;
            }
            ti->failed = true;

            ThreadErrorCache* new_entry = malloc(sizeof(ThreadErrorCache));
            if (new_entry) {
                strncpy(new_entry->key, thread_key, sizeof(new_entry->key) - 1);
                new_entry->key[sizeof(new_entry->key) - 1] = '\0';
                new_entry->last_update = time(NULL);
                HASH_ADD_STR(thread_error_cache, key, new_entry);
            } else {
                LOG_E("Failed to allocate memory for thread error cache");
            }

            const char* reason;
            switch (errno) {
                case EINVAL: reason = "Invalid CPU affinity mask"; break;
                case EPERM: reason = "Permission denied"; break;
                case EFAULT: reason = "Invalid memory address"; break;
                default: reason = strerror(errno); break;
            }
            char rule_key[512] = {0};
            char* rule_str = NULL;
            for (size_t j = 0; j < proc->num_thread_rules; j++) {
                if (CPU_EQUAL(&ti->cpus, &proc->thread_rules[j]->cpus)) {
                    snprintf(rule_key, sizeof(rule_key), "%s{%s}=%s",
                             proc->thread_rules[j]->pkg,
                             proc->thread_rules[j]->thread,
                             proc->thread_rules[j]->cpuset_dir);
                    rule_str = rule_key;
                    break;
                }
            }
            if (!rule_str) {
                snprintf(rule_key, sizeof(rule_key), "no_matching_rule");
                rule_str = "no matching rule";
            }

            RuleErrorCache* entry;
            HASH_FIND_STR(error_cache, rule_key, entry);
            if (!entry) {
                entry = malloc(sizeof(RuleErrorCache));
                if (entry) {
                    strncpy(entry->rule_key, rule_key, sizeof(entry->rule_key) - 1);
                    entry->rule_key[sizeof(entry->rule_key) - 1] = '\0';
                    entry->last_update = time(NULL);
                    HASH_ADD_STR(error_cache, rule_key, entry);
                    LOG_E("Failed to set affinity for thread %s (TID %d, pkg %s): %s, mask: %s, rule: %s, system CPUs: %s",
                          ti->name, ti->tid, proc->pkg, reason,
                          mask_str, rule_str, topo->present_str);
                } else {
                    LOG_E("Failed to allocate memory for error cache");
                }
            } else {
                LOG_E("Failed to set affinity for thread %s (TID %d, pkg %s): %s, mask: %s",
                      ti->name, ti->tid, proc->pkg, reason, mask_str);
            }
            free(mask_str);
        }
    }
    return applied;
}

// 更新缓存
static void update_cache(ProcCache* cache, const AppConfig* cfg, int* affinity_counter) {
    int current_proc_count = get_proc_count();
    if (current_proc_count == -1) {
        update_proc_cache(cache, cfg);
        return;
    }
    if (current_proc_count > cache->last_proc_count + 5) {
        update_proc_cache(cache, cfg);
        bool applied = false;
        for (size_t i = 0; i < cache->num_procs; i++) {
            applied |= apply_affinity(&cache->procs[i], &cfg->topo, cache);
        }
        *affinity_counter = 1;
    }
    cache->last_proc_count = current_proc_count;
}

// 屏幕状态检查
static bool is_screen_on(void) {
    const char* backlight_path = "/sys/class/backlight/panel0-backlight/brightness";
    int fd = open(backlight_path, O_RDONLY);
    if (fd >= 0) {
        char buf[32] = {0};
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0) {
            long value = strtol(buf, NULL, 10);
            return value > 0;
        }
        return true;
    }

    FILE* fp = popen("dumpsys deviceidle get screen 2>/dev/null", "r");
    if (fp) {
        char buf[32] = {0};
        size_t n = fread(buf, 1, sizeof(buf) - 1, fp);
        buf[n] = '\0';
        pclose(fp);
        return (strstr(buf, "false") == NULL);
    }

    return true;
}

// 清理资源
static void cleanup(AppConfig* config, ProcCache* cache) {
    if (log_fp) {
        if (fclose(log_fp) != 0) {
            fprintf(stderr, "Failed to close log file %s: %s\n", log_file_path, strerror(errno));
        }
        log_fp = NULL;
    }

    for (size_t i = 0; i < cache->num_procs; i++) {
        free(cache->procs[i].threads);
        free(cache->procs[i].thread_rules);
    }
    free(cache->procs);
    cleanup_proc_cache(cache);

    free(config->rules);
    free(config->wildcard_rules);
    for (size_t i = 0; i < config->num_pkgs; i++) free(config->pkgs[i]);
    free(config->pkgs);
    PackageEntry* entry, *tmp;
    HASH_ITER(hh, config->pkg_table, entry, tmp) {
        HASH_DEL(config->pkg_table, entry);
        free(entry);
    }

    RuleErrorCache* err_entry, *err_tmp;
    HASH_ITER(hh, error_cache, err_entry, err_tmp) {
        HASH_DEL(error_cache, err_entry);
        free(err_entry);
    }

    ThreadErrorCache* thread_err_entry, *thread_err_tmp;
    HASH_ITER(hh, thread_error_cache, thread_err_entry, thread_err_tmp) {
        HASH_DEL(thread_error_cache, thread_err_entry);
        free(thread_err_entry);
    }
}

// 主函数
int main(int argc, char* argv[]) {
    const char* config_file = DEFAULT_CONFIG_FILE;
    int sleep_interval = 3;

    set_default_log_path(config_file);

    for (int i = 1; i < argc; i++) {
        if (strncmp(argv[i], "-f", 2) == 0 && i + 1 < argc) {
            config_file = argv[++i];
            set_default_log_path(config_file);
        } else if (strncmp(argv[i], "--log=", 6) == 0) {
            strncpy(log_file_path, argv[i] + 6, sizeof(log_file_path) - 1);
            log_file_path[sizeof(log_file_path) - 1] = '\0';
        } else if (strncmp(argv[i], "--debug=", 8) == 0) {
            const char* debug_val = argv[i] + 8;
            log_enabled = (strcmp(debug_val, "true") == 0);
            debug_set_from_args = true;
        } else if (strncmp(argv[i], "--minimal-log", 13) == 0) {
            log_minimal = true;
        } else if (strncmp(argv[i], "-s", 2) == 0 && i + 1 < argc) {
            char* endptr;
            long val = strtol(argv[++i], &endptr, 10);
            if (endptr == argv[i] || *endptr != '\0' || val < 1) {
                fprintf(stderr, "Invalid interval value: %s\n", argv[i]);
                fprintf(stderr, "Interval must be an integer >=1\n");
                return 1;
            }
            sleep_interval = (int)val;
            LOG_I("Sleep interval set to %d seconds", sleep_interval);
        } else {
            fprintf(stderr, "Unknown argument: %s\n", argv[i]);
            fprintf(stderr, "Usage: %s [-f config_file] [--log=log_file] [--debug=(true|false)] [--minimal-log] [-s interval]\n", argv[0]);
            return 1;
        }
    }

    LOG_I("Affinity Manager started, PID: %d", getpid());
    AppConfig config = { .topo = init_cpu_topo(), .mtime = 0, .pkg_table = NULL };
    strncpy(config.cpuset_base, BASE_CPUSET, sizeof(config.cpuset_base) - 1);
    config.cpuset_base[sizeof(config.cpuset_base) - 1] = '\0';
    ProcCache cache = { .proc_cache = NULL, .last_proc_count = 0 };
    time_t last_screen_check = 0;
    bool screen_state_cached = true;
    bool last_logged_screen_state = true;
    int config_counter = 3;
    int affinity_counter = 1;

    const char* backlight_path = "/sys/class/backlight/panel0-backlight/brightness";
    bool backlight_exists = (access(backlight_path, F_OK) == 0);
    int screen_check_interval = backlight_exists ? 5 : 30;

    if (debug_set_from_args) {
        LOG_I("Debug mode set from command line: %s", log_enabled ? "true" : "false");
    }
    if (log_minimal) {
        LOG_I("Minimal log mode enabled");
    }
    load_config(&config, config_file);

    for (;;) {
        time_t now = time(NULL);

        if (now - last_screen_check >= screen_check_interval) {
            screen_state_cached = is_screen_on();
            last_screen_check = now;
            if (screen_state_cached != last_logged_screen_state) {
                LOG_I("Screen state changed to: %s", screen_state_cached ? "ON" : "OFF");
                last_logged_screen_state = screen_state_cached;
                if (screen_state_cached) {
                    if (load_config(&config, config_file)) {
                        cache.last_proc_count = 0;
                        LOG_I("Config reloaded after screen turned ON");
                    }
                }
            }
        }

        if (!screen_state_cached) {
            sleep(30);
            cache.last_proc_count = 0;
            continue;
        }

        config_counter++;
        if (config_counter > 3) {
            if (load_config(&config, config_file)) {
                cache.last_proc_count = 0;
                LOG_I("Config reloaded periodically");
            }
            config_counter = 0;
        }

        update_cache(&cache, &config, &affinity_counter);

        affinity_counter++;
        if (affinity_counter > 1) {
            bool applied = false;
            for (size_t i = 0; i < cache.num_procs; i++) {
                applied |= apply_affinity(&cache.procs[i], &config.topo, &cache);
            }
            affinity_counter = 0;
        }

        if (now % 120 == 0) {
            cleanup_proc_cache(&cache);
        }

        sleep(sleep_interval);
    }
    
    cleanup(&config, &cache);
    return 0;
}
### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**，例如我下载了`线程优化二改211.zip`刷入后，想要实现(取消)增加更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。

### 更新日志
> 21.6
- 调整内存分配，感谢酷友[糕手吃蟹堡](http://www.coolapk.com/u/32321784)和[老张子z](http://www.coolapk.com/u/10543701)测试。
> 21.5
- 添加Fold Craft Launcher (`com.tungsten.fcl`)，炽焰天穹(绯染天空) (`com.bilibili.heaven`,`com.heavenburnsred.kbinstaller`,`com.heavenburnsred`)，创造与魔法 (`com.hero.sm.bz`,`com.hero.sm.android.hero`,`com.hero.sm.mi`,`com.hero.sm.aligames`,`com.hero.sm.huawei`,`com.tencent.tmgp.sm`)，数据备份 (`com.xayah.databackup.premium`,`com.xayah.databackup.foss`)适配。
> 21.4
- 添加航海王：燃烧意志 (`com.pkwan.op.toufang.dy`,`com.tencent.tmgp.pkwan.op`)适配。
- 添加DNF一个新线程`LogicThread`，感谢酷友[墨色mosse](http://www.coolapk.com/u/27642366)分享。

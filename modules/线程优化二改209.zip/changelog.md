### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)

### 更新日志
> 20.9
- 优化内存占用。
> 20.8
- 添加`persist.sys.miui_animator_sched.enabled=false`值，**用于禁用MIUI自带线程绑定**。
- 调整网易云/`lspd`线程。
> 20.7
- 添加飞书(Lark) (`com.larksuite.suite`,`com.ss.android.lark`)，招商银行 (`cmb.pb`)适配。
> 20.6
- 添加小黑盒(`com.max.xiaoheihe`)，Steam(`com.valvesoftware.android.steam.community`)适配。
> 20.5
- 调整`6+2`核心设计修改，区分高性能和中低端性能的处理器，高性能处理器减少跨簇的情况。
- 调整`哔哩哔哩`和`永劫无间`线程。
> 20.4
- 添加百度贴吧(`com.baidu.tieba`)，Google谷歌相机(AGC) (`com.agc.gcam92`,`com.samsung.agc.gcam92`)适配。
- 完善影之诗(ShadowverseWB) (`com.netease.yzs`,`jp.co.cygames.ShadowverseWorldsBeyond`)适配。

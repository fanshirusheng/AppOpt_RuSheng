### 感谢[@coolapk SutoLiu 大佬](https://www.coolapk1s.com/u/SutoLiu)
### 原模块地址: https://gitee.com/sutoliu/AppOpt
#### 二改模块日志

> 10.7
- 添加LibChecker(`com.absinthe.libchecker`)，Roblox(`com.roblox.client`)适配。
- 调整**浏览器线程**。
> 10.6
- 优化`AppOpt`的`load_config`性能。
> 10.5
- 添加弹弹play概念版(`com.xyoye.dandanplay`)适配。
- 调整Animeko(`me.him188.ani`)线程。
> 10.4
- 修复`Appopt`一个内存泄露的问题。
> 10.3
- 添加kiwi Browser(`com.kiwibrowser.browser`)，雨见(国际版) (`com.yjllq.internet`)，可拓浏览器 (`com.yjllq.kito`)，红雨见(chromium内核) (`com.yjllq.chrome.beta`,`com.yjllq.chrome`)适配。
> 10.2
- 调整`AppOpt`可能存在的问题。
- 添加巅峰极速(`com.netease.race`,`com.netease.race.ua`)，阴阳师(`com.netease.onmyoji`,`com.netease.onmyoji.vivo`,`com.netease.onmyoji.wyzymnqsd_cps`,`com.netease.onmyoji.bili`,`com.netease.onmyoji.mi`)，对峙2 (standoff2) (`com.axlebolt.standoff2.huawei`,`com.axlebolt.standoff2`)适配。
> 10.1
- 创建`/data/adb/modules/AppOpt_Aloazny/delete_game_config`空文件，**就会删除自带的游戏配置**。
> 10.0
- 添加QQ浏览器国际版(`com.tencent.mtt.intl`)，QQ浏览器(`com.tencent.mtt`)，M浏览器(3.X)(`cn.mujiankeji.mbrowser`)适配。
> 9.9
- 适配迅雷(`com.xunlei.downloadprovider`)。
> 9.8
- 添加心绪日记(`cn.yooss.moodiary`)，小米笔记 (`com.miui.notes`)，Quetta浏览器 (`net.quetta.browser`)适配。
- 调整支付宝(`com.eg.android.AlipayGphone`)，UC浏览器(`com.UCMobile`)，极速浏览器(`com.qihoo.contents`)线程。
> 9.7
- 移除`Fnmatch`的`FNM_NOESCAPE`flag，线程中的特殊符号`*?[]{}`，只需要一个转义使用"\"作为转义即可，不需要"\\"。
> 9.6
- 添加元气骑士(`com.ChillyRoom.DungeonShooter`)，少女前线(`com.Sunborn.SnqxExilium`, `com.sunborn.snqxexilium.glo`)，皇室战争(`com.tencent.tmgp.supercell.clashroyale`)
适配。
- 修复阅读一个线程分配的错误。
> 9.5
- 添加Tyranor(`com.akira.tyranoemu`)，Minecraft(`com.mojang.minecraftpe`)，我的世界(网易)(`com.netease.x19`)，迷你世界(`com.minitech.miniworld`,`com.minitech.miniworld.TMobile.mi`,`com.tencent.tmgp.minitech.miniworld`,`com.minitech.miniworld.uc`,`com.playmini.miniworld`)，尘白禁区(`com.dragonli.projectsnow.lhm`,`com.dragonli.projectsnow.bilibili`)，Snapseed (`com.niksoftware.snapseed`)，UC浏览器 (`com.UCMobile`)，Outlook(`com.microsoft.office.outlook`)，网易邮箱(大师)(`com.netease.mail`)，QQ邮箱(`com.tencent.androidqqmail`)适配。
> 9.4
- 添加狂野飙车9 (`com.aligames.kuang.kybc.aligames`,`com.tencent.tmgp.aligames.kybc`,`com.aligames.kuang.kybc.mi`,`com.aligames.kuang.kybc.tap`,`com.aligames.kuang.kybc`)，荒野乱斗 (`com.tencent.tmgp.supercell.brawlstars`)适配。
- 调整`2+3+2+1`配置，调整`cpu_control.sh`代码。
> 9.3
- 修改`AppOpt`部分代码，减少性能开销。
> 9.2
- 添加隐藏应用列表 (`com.tsng.hidemyapplist`)，百度网盘(小米联合开发版) (`com.baidu.netdisk.xiaomi.appunion`)，百度网盘 (`com.baidu.netdisk`)，123网盘 (`com.mfcloudcalculate.networkdisk`)适配。
> 9.1
- 修复海阔视界(`com.example.hikerview`)进程规则复制成嗅觉(`com.hiker.youtoo`)的bug。
> 9.0
- 添加Rians 浏览器(`com.rainsee.create`)和网梭浏览器(`com.x.webshuttle`)，海阔视界(`com.example.hikerview`)，移动云盘 (`com.chinamobile.mcloud`)，小米搜索(`com.android.quicksearchbox`)适配。
> 8.9
- 减少`kill`调用和`stat`读取。
> 8.8
- 添加Via浏览器(`mark.via`,`mark.via.gp`)，X浏览器(`com.mmbox.xbrowser`,`com.mmbox.browser`,`com.x.browser.x5`,`com.xbrowser.play`)，Soul浏览器(`com.mycompany.app.soulbrowser`)，嗅觉浏览器(`com.hiker.youtoo`)适配。
> 8.7
- 添加Joplin笔记 (`net.cozic.joplin`)，Javaloader (`ru.woesss.j2meloader`,`ru.playsoftware.j2meloader`)适配。
> 8.6
- 同步上游`1.3.2`更新`AppOpt`，`-f`参数改为`-c`参数，避免不一致。
- 添加农业银行 (`com.android.bankabc`)，建设银行 (`com.chinamworld.main`)，云闪付 (`com.unionpay`)，北部湾银行 (`com.yitong.bbw.mbank.android`)适配。
> 8.5
- 添加现代战争3(MC3) (`com.gameloft.android.GAND.GloftM3HP`)，Google文件(`com.android.documentsui`)，快手极速版 (`com.kuaishou.nebula`)适配。
> 8.4
- 添加光遇 (`com.netease.sky`,`com.tgc.sky.android`,`com.netease.sky.nearme.gamecenter`,`com.netease.sky.bilibili`,`com.tencent.tmgp.eyou.eygy`,`com.netease.sky.mi`,`com.netease.sky.m4399`,`com.netease.sky.vivo`)，绝区零 (`com.miHoYo.Nap`,`com.mihoyo.nap.bilibili`)适配，Comic Screen (`com.viewer.comicscreen`)，Perfect Viewer (`com.rookiestudio.perfectviewer`)，MH-ARK (`com.mhdh.mh_ark`)，Sudachi (`org.sudachi.sudachi_emu`)。
> 8.3
- 尝试修复部分设备`AppOpt`无法启动的情况，如果`AppOpt`无法启动，把`/data/adb/modules/AppOpt_Aloazny/affinity_manager.log`文件通过[文叔叔](https://www.wenshushu.cn/) (免登陆)发给我(记得复制链接)。
> 8.2
- `action.sh`添加重启`AppOpt`的选项，不知道执行`action.sh`，有的设备会让AppOpt终止。
> 8.1
- 修复`AppOpt`可能存在的bug。
- 添加MIUI智能助理(负一屏) (`com.miui.personalassistant`)，Apple music (`com.apple.android.music`)，Spotify (`com.spotify.music`)适配。
> 8.0
- 添加Google 文件 (`com.google.android.documentsui`)，狐猴浏览器 (`com.lemurbrowser.exts`,`com.lemurbrowser.exts.beta`)适配。
> 7.9
- 调整了`uthash.h`缓存的部分机制。
- 添加小米浏览器(`com.android.browser`)，豆包 (`com.larus.nova`)，DeepSeek (`com.deepseek.chat`)，问小白 (`com.yuanshi.wenxiaobai`)，通义千问 (`com.aliyun.tongyi`)。
> 7.8
- 添加`cpu_control.sh`脚本。
- 添加对QQ音乐(play)版的适配以及QQ音乐(魅族定制)(`com.meizu.media.music`)适配。
- 添加AcFun(`tv.acfundanmaku.video`)适配。
> 7.7
- 添加小爱扫一扫 (`com.xiaomi.scanner`)，小爱同学(`com.miui.voiceassist`)适配。
> 7.6
- 修复上个版本`AppOpt`的一些bug。
- 添加Stay(`com.dajiu.stay`)浏览器，NGA玩家社区 (`gov.pianzong.androidnga`)，LocalSend(`org.localsend.localsend_app`)，纯纯看番 (`com.heyanle.easybangumi4`)，Mihon (`app.mihon`)，Miru (`miru.miaomint`)适配。
> 7.5
- 改回`Aloazny.sh`对`Scene核心分配的判定`，加入上游的`/proc/loadavg`机制和移除`inotify`。
- 添加阅读(`io.legado.app.release`)，阅读(play) (`io.legado.play.release`)适配。
> 7.4
- 本来想偷懒，懒得下载那些垃圾流氓应用的，结果发现别人作业里面的**虎牙线程**写错好几个线程名，就这样都没有人发现，绝了，现在已经自己下载了重写了。
- 添加斗鱼极速(play) (`com.douyu.rush`)，斗鱼直播(`air.tv.douyu.android`)适配。
> 7.3
- 添加LeapMusic (`com.leapmusic.leapmusic`)，豆瓣 (`com.douban.frodo`)，虎牙直播 (`com.duowan.kiwi`)，虎牙直播(play) (`com.huya.kiwi`)适配。
> 7.2
- 添加夸克 (`com.quark.browser`)，ALook (`alook.browser`)，最右 (`cn.xiaochuankeji.tieba`)，车来了 (`com.ygkj.chelaile.standard`)，滴滴打车 (`com.sdu.didi.psnger`)适配。
> 7.1
- 改为未安装`zygisk-maphide`或者`shamiko`两种中任意一个时才会跳过挂载`/system`。
- 添加Markor(`net.gsantner.markor`)，RAR(`com.rarlab.rar`)，ZArchiver(`ru.zdevs.zarchiver.pro`,`ru.zdevs.zarchiver`)，Edge(`com.microsoft.emmx`)，360极速浏览器(`com.qihoo.contents`)，WeTV/腾讯视频海外版 (`com.tencent.qqlivei18n`)适配。
> 7.0
- 修复上个版本`3+4+1`和`2+3+2+1`核心配置对于`2-4`未适配的bug。
- 添加Poweramp(`com.maxmpz.audioplayer`)，Image Toolbox(`ru.tech.imageresizershrinker`)，Instagram(`com.instagram.android`)适配。
> 6.9
- 微调**MT文件管理器**，稍微加快MT管理器解压速度，但是降低功耗。
- 优化**Joiplay**解密游戏速度。
- 添加酷狗音乐(`com.kugou.android`,`com.kugou.android.lite`)，Obsidian(`md.obsidian`)适配。
- 添加黄油模拟器Aopaop (`com.aopaop.app`)，Maldives (`net.miririt.maldivesplayer`)，MTOOLS (`app.mtool.mtoolmobile`)适配。
> 6.8
- 炉石传说 (`com.blizzard.wtcg.hearthstone`,`com.blizzard.wtcg.hearthstone.cn.dashen`,`com.blizzard.wtcg.hearthstone.cn.huawei`)，IDM+/1DM+ (`idm.internet.download.manager.plus`)，MIUI player/小米音乐 (`com.miui.player`)，QQ音乐 (`com.tencent.qqmusic`)，酷我音乐 (`cn.kuwo.player`)。
> 6.7
- 适配剪映(`com.lemon.lv`)，红果短剧(`com.phoenix.read`)，QQ(`com.tencent.mobileqq`)，TIM(`com.tencent.tim`)。
> 6.6
- 添加一个如果出现笔误，规则写错情况下，执行`action.sh`的修复。
- 更细致的**网易云音乐**匹配。
- 添加无限暖暖 (`com.papegames.infinitynikki`)，决战平安京 (`com.netease.moba`)，腾讯视频 (`com.tencent.qqlive`)，爱奇艺 (`com.qiyi.video`)适配。
> 6.5
- 添加虎扑 (`com.hupu.games`)，Bangumi (`com.czy0729.bangumi`)，钉钉 (`com.alibaba.android.rimet`)，PiliPala (`com.guozhigq.pilipala`)，PiliPalaX (`com.orz12.PiliPalaX`)。
> 6.4
- 添加菜鸟裹裹(`com.cainiao.wireless`)，顺丰速运(`com.sf.activity`)。
- 添加`Aloazny.sh`修改一个配置文件可能乱写导致的错误。
> 6.3
- 修复可能存在内存泄露的几个bug。
- 适配PipePipe (`InfinityLoop1309.NewPipeEnhanced`)，什么值得买 (`com.smzdm.client.android`)。
> 6.1
- 同步上游部分`1.19`代码，因为修修又补补和源码变化有点多，所以只抄了主要部分。
- 添加不能无法设置的`CPU`亲和规则日志记录。
- 适配微博 (`com.sina.weibo`)
> 6.0
- 添加空线程适配，如`example.app.com{ }=6`。
- 修复`AppOpt`可能存在的几个配置文件解析和优先级匹配的bug。
- 添加MIUI系统应用 相册 (`com.miui.gallery`)，相册编辑 (`com.miui.mediaeditor`)适配，游戏碧蓝航线(`com.bilibili.azurlane`)。
> 5.8
- 添加`Failed to set affinity`的原因。
- 配置文件如果不存在，延迟`5秒`后才会创建，避免和MT管理器冲突(MT管理器会删除再创建文件)。
> 5.7
- 细化线程匹配优先级，从低到高`example.app.com=0-3` **→** `example.app.com{Thread-*}=4-6` **→** `example.app.com{Thread-2*}=4-6` **→** `example.app.com{Thread-[0-9]}=4-6` **→** `example.app.com{Thread-2[0-9]}` **→** `example.app.com{Thread-2}=7`。
- 添加"毒奶粉"(`com.tencent.tmgp.dnf`)，快手(`com.smile.gifmaker`)匹配。
- 调整`system_server`线程分配。
> 5.6
- 修复一个`AppOpt`的bug。
- 添加JJ象棋 (`cn.jj.chess`,`cn.jj.chess.mi`)。
> 5.5
- 调整`applist.prop`配置。
- 添加哔哩哔哩play版(`com.bilibili.app.in`)，航海王热血航线(`com.hermes.h1game`,`com.hermes.h1game.m4399`)，明日之后(`com.netease.mrzh`,`com.netease.mrzh.mi`)，超自然行动组(`com.pi.czrxdfirst`)，Grok(`ai.x.grok`)。
> 5.4
- 添加对`/system/vendor/bin/msm_irqbalance`处理，如果未安装隐藏模块，则默认不挂载`/system`。
> 5.3
- 添加SD Maid(`eu.thedarken.sdm`,`eu.darken.sdmse`)，Telegram(`org.telegram.messenger`,`org.telegram.messenger.web`,`org.telegram.messenger.beta`)适配。
> 5.2
- 调整`6+2`配置，避免`sdm710`都分配给大核，部分场景卡顿。
- 修复一个**配置文件因为错误规则**卡死的bug。
- 添加kazumi(`com.predidit.kazumi`)和Animeko(`me.him188.ani`)适配。
> 5.1
- 调整`applist.prop`部分应用线程。
- 加回`Scene`版本判定(这么久了，应该改好了吧)。
> 5.0
- 添加通配符匹配进程，通配符会稍微增加性能消耗，推荐优先使用精确匹配，自行斟酌。
- 适配游戏荒野行动(`com.netease.hyxd.mi`, `com.netease.hyxd.aligames`, `com.netease.hyxd.nearme.gamecenter`, `com.netease.hyxd.wyzymnqsd_cps`)，三角洲行动(`com.tencent.tmgp.dfm`)，部落冲突(`com.tencent.tmgp.supercell.clashofclans`)
> 4.9
- 添加饿了么(`me.ele`)，美团(`com.sankuai.meituan`)。
> 4.8
- 添加日常应用适配，小红书(`com.xingin.xhs`)，高德地图(`com.autonavi.minimap`)，百度地图(`com.baidu.BaiduMap`)，闲鱼(`com.taobao.idlefish`)，淘宝(`com.taobao.taobao`)，拼多多(`com.xunmeng.pinduoduo`)。
> 4.7
- 新增优先级匹配，精确匹配优先级高于通配符匹配，如下。
```C++
exp.com{Thread-3}=7
exp.com{Thread-[1-2]3}=6
exp.com{Thread-*}=4-6
```
- 模块会优先绑定`exp.com{Thread-3}`到CPU7，`exp.com{Thread-[1-2]3}`也就是`Thread-13/Thread-23`会被绑定到CPU6，剩下的`Thread-*`会给到CPU4-6。
> 4.6
- 添加金铲铲(`com.tencent.jkchess`)。
- 添加适配应用列表，可以在`适配应用.md`查看。
> 4.5
- 添加一个MIUI相机(`com.android.camera`)的线程。
- 修改酷安、MIUI桌面线程。
> 4.4
- 添加对`system_server`的修改。
- 修复`applist.prop`中新的线程把`tv.danmaku.bili`打成`tv.danmaku.bilibilihd`。
- 调整`6+2`和`2+3+2+1`的机械性配置。
> 4.3
- 修复`4+4`把`*}`替换成`=`的错误。
- MTK屏蔽`/system/vendor/etc/power_app_cfg.xml`文件。
- 修复`核心配置`更改的一个bug。
> 4.2
- 更改一个`4+4`配置，新增`2+3+2+1`机械性配置修改。
> 4.1
- 调整`surfaceflinger`线程匹配。
> 4.0
- 添加两个`BILIBILI`线程`IJK`和`Thread-*`。
> 3.9
- 改成`aarch64-linux-android23-clang`编译，和Magisk最低支持的版本同步。
> 3.8
- 修复刷入后不修改`/data/adb/modules_update/AppOpt_Aloazny/applist.prop`的问题。
- 修改机械性适配地部分描述。
> 3.7
- 添加机械性适配`6+2` `3+4+1` `4+4` CPU核心配置的适配，创建`/data/adb/modules/AppOpt_Aloazny/modtify_config`空文件，就会修改配置。
- 创建`/data/adb/modules/AppOpt_Aloazny/update_config`空文件，就会使用模块的配置，而不是读取上一次配置。
> 3.6
- 云适配了`CF`。
> 3.5
- 添加一项配置文件`applist.prop`移除多行，**只保留一行空行**。
- 云适配了一些游戏。
> 3.4
- 添加winlator(`com.winlator`)的核心配置(其实这个主要还是看GPU)。
> 3.3
- 机械地检测了了`A-soul`模块可能会冲突的包名，自行点击Action检测。
> 3.2
- 修改`Job.worker`为`Job.worker*`。
> 3.1
- 同步`SutoLiu`的`1.0.2`版本，默认不暂停`oiface`。
- 更改卸载脚本`uninstall.sh`。
- 退回`Aloazny.sh`的核心显示。
> 3.0
- 抄了`Scene`的作业，把`Scene`的游戏核心分配置(仅配置)，改了改，加到了上面，效果可能不好。
- 添加KB视频工厂(`com.idaodan.video.factory`)的核心分配，空闲小核，减少卡顿。
- 修改`com.google.android.webview`的`Compositor`为核心6，避免在玩Joiplay时，7负载太高，有点卡顿。
> 2.9
- 修正`applist.prop`对webview和Joiplay的部分核心配置，偏向更流畅。
> 2.8
- 添加Joiplay(`cyou.joiplay.joiplay`)配置。
- 修复**inotify**的一个息屏bug，息屏后亮起，即刻修改配置文件，不会生效。
> 2.7
- Scene根本就没兼容，加回Scene检测。
- 修复`applist.prop`把`Twitter`复制粘贴成`coolapk`的一个错误线程。
> 2.6
- 修改**错误日志**输出限制为10行，剩下会在错误日志文件。
- 添加`CPU核心范围`检测。
> 2.5
- 修复`Aloazny.sh`对配置检查报错的bug。
> 2.4
- 添加对`CuDaemon`和`uperf`调度的运行检测。
- 修复对**亮屏逻辑的一个检测**。
> 2.3
- 尝试适配天机不存在`/sys/class/backlight`目录，改为30秒用`dumpsys`检测一次屏幕状态。
> 2.2
- 增加`/proc`缓存，避免反复读取`/proc`，减少部分性能开销。
- 添加`uthash.h`，用于读取配置包名，规则数量到`800+`时，差异明显，`100+`两者差不多。
- 添加MT文件管理器(`bin.mt.plus`)一条新的规则。
- 有了上面的优化，我把`PROC_CACHE_TIME`从`30`该到了`15`，兼容玩游戏的同学，原`SutoLiu`大佬的设定是`10`，但是运行起来CPU占用太高(2%左右)，现在优化好了改成`10`或者`15`运行都能在`0.8%`以下。
> 2.1
- 添加调整`applist.prop`部分配置。
- 替换`@coolapk 10007`大佬的`update-binary`(感谢！)，用于兼容**20400**低版本的Magisk。
> 2.0
- arm64的架构改成用`aarch64-linux-android32-clang`(Android12)编译了。
- 修正一个Apatch错误。
> 1.9
- 还是换回`O3`了，`-O2`省的那点内存还不如不省。
- 添加几个**哔哩哔哩**的附加进程配置参考。
- 修正`Aloazny.sh`在刷入的时候把自己给扬了。
> 1.8
- 配置文件监控改成`inotify`监控，理论上能降低一些Cpu占用和资源消耗。
- 编译时从`-O3`改为`-O2`，理论上内存占用没那么高了。
> 1.7
- **Scene** versioncode大于`820250402`不再检测Scene冲突。
> 1.6
- 新增对**配置文件**存在重复配置进程的提醒。
> 1.5
- 添加抖音(`com.ss.android.ugc.aweme`)配置参考。
- 添加椒盐笔记(`com.moriafly.note`)。
- 更新`Aloazny.sh`脚本(`action.sh`)，模块`action.sh`也能在原模块(@SutoLiu)中使用。
- 修正`service.sh`中把`/data/adb/modules/AppOpt`打错成`/data/adb/module/AppOpt`。
- 修改架构安装。
> 1.4
- 修复非`magisk`，**Ksu/Apatch** 刷入action报错问题。
> 1.3
- 在配置文件中未使用`=`的进程或者中文会被加上`#`注释。
- 酷安加上一个`com.coolapk.market{OkHttp Dispatch}=4-6`的配置，你也可以改成`com.coolapk.market{OkHttp*}=4-6`。
> 1.2
- 修复一个action检测`AppOpt`占用为0%和未运行的情况未区分，导致显示不准确的bug。
> 1.1
- 添加一个命令参数`-f 配置文件路径` `--log=日志文件路径` `--debug=填写true或者false`，如果不指定，那么就是模块默认配置。
- 英文说明`Usage: %s [-f config_file] [--log=log_file] [--debug=(true|false)]`
- 例如下面这个命令就是，指定配置文件`/data/adb/modules/AppOpt_Aloazny/applist.prop`，日志文件`/data/adb/modules/AppOpt_Aloazny/affinity_manager.log`，`关闭调试日志`。
```shell
AppOpt -f /data/adb/modules/AppOpt_Aloazny/applist.prop --log=/data/adb/modules/AppOpt_Aloazny/affinity_manager.log --debug=false
```
> 1.0
- 添加一个8+的`surfaceflinger`和`vendor.qti.hardware.display.composer-service`配置服务。
> 0.9
- 核心信息添加`sort -rn`排序后显示。
> 0.8
- 增加支付宝(`com.eg.android.AlipayGphone`) 番茄小说(`com.dragon.read`) iceraven(`io.github.forkmaintainers.iceraven`)配置。
- 修复`action.sh`识别冲突模块的一个逻辑错误。
> 0.7
- 修改`service.sh`语法，避免有的设备无法识别？
- 修复开机不自动执行。
> 0.6
- 把核心信息写入配置文件`applist.prop`。
> 0.5
- copy了@coolapk 10007代码，添加magisk或者非ksu识别。
> 0.4
- 添加`action.sh`按钮，能够输出模块的一些信息。
> 0.3
- 在配置文件`applist.prop`中修改`Debug_AppOpt=false`能提升一些性能。
- 因为我不打游戏，所以如果发现有的线程生效不及时的话，可以选择自己编译一下源码，把`PROC_CACHE_TIME 30`里面的`30`改回`10`或者`15`，提升响应速度。
- 添加更多冲突模块检测。
> 0.2
- 加回`dumpsys`作为备选，获取屏幕状态。
- 添加`scene`核心分配名单检测(目前无法检测开关，因为我太菜)和其他核心模块检测。
> 0.1
- 更改`module_id`为`AppOpt_Aloazny`。
- 更改配置文件`applist.conf`为`applist.prop`，**舒服我自己**用MT管理器查看配置文件有高亮。
- 更改`uninstall`的`setprop`为`resetprop`，避免卸载模块可能发生的开机阻塞。
- 添加一个shell脚本更正部分用户乱写的`applist.conf(applist.prop)`。
- 添加`日志记录`，去掉`dumpsys`获取屏幕状态。
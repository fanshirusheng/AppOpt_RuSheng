#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <fnmatch.h>
#include <libgen.h>
#include <sched.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/sysinfo.h>
#include <time.h>
#include <unistd.h>
#include "uthash.h"

// 常量定义
#define MAX_LOG_SIZE (500 * 1024)
#define DEFAULT_CONFIG_FILE "./applist.conf"
#define CONFIG_RELOAD_TIME 10
#define PROC_CACHE_TIME 9
#define MAX_PKG_LEN 128
#define MAX_THREAD_LEN 64
#define PROC_ENTRY_CACHE_TIME 10
#define BASE_CPUSET "/dev/cpuset/AppOpt"
#define MAX_ERROR_CACHE_SIZE 1000
#define ERROR_CACHE_TIMEOUT (600)
#define MAX_CPU_SET_CACHE_SIZE 1000
#define INITIAL_RULE_CAPACITY 4096
#define INITIAL_WILDCARD_CAPACITY 128
#define INITIAL_PKG_CAPACITY (128 * 5)
#define DENT_BUF_SIZE (128 * 1024)

// 日志宏
#define LOG_I(fmt, ...) do { if (log_enabled && !log_minimal) write_log("[I] " fmt, ##__VA_ARGS__); } while (0)
#define LOG_W(fmt, ...) do { if (log_enabled) write_log("[W] " fmt, ##__VA_ARGS__); } while (0)
#define LOG_E(fmt, ...) do { if (log_enabled) write_log("[E] " fmt, ##__VA_ARGS__); } while (0)

// 数据结构
typedef struct {
    char pkg[MAX_PKG_LEN] __attribute__((aligned(64)));
    char thread[MAX_THREAD_LEN];
    cpu_set_t cpus;
    bool is_wildcard;
    int priority;
    char cpuset_dir[256];
} AffinityRule;

typedef struct {
    pid_t tid;
    char name[MAX_THREAD_LEN];
    cpu_set_t cpus;
    cpu_set_t last_cpus;
    time_t create_time;
} ThreadInfo;

typedef struct {
    pid_t pid;
    char pkg[MAX_PKG_LEN];
    cpu_set_t base_cpus;
    ThreadInfo* threads;
    size_t num_threads;
    AffinityRule** thread_rules;
    size_t num_thread_rules;
    bool scanned;
} ProcessInfo;

typedef struct {
    cpu_set_t present_cpus;
    bool cpuset_enabled;
    char present_str[256];
    char mems_str[32];
} CpuTopology;

typedef struct {
    pid_t pid;
    char cmdline[MAX_PKG_LEN];
    time_t last_update;
    unsigned long start_time;
    bool start_time_valid;
    time_t last_checked;
    time_t stat_mtime;
    UT_hash_handle hh;
} ProcEntryCache;

typedef struct {
    AffinityRule* rules;
    size_t num_rules;
    AffinityRule** wildcard_rules;
    size_t num_wildcard_rules;
    time_t mtime;
    CpuTopology topo;
    char** pkgs;
    size_t num_pkgs;
    struct PackageEntry* pkg_table;
    char cpuset_base[256];
} AppConfig;

typedef struct PackageEntry {
    char pkg[MAX_PKG_LEN];
    UT_hash_handle hh;
} PackageEntry;

typedef struct {
    ProcessInfo* procs;
    size_t num_procs;
    time_t last_update;
    ProcEntryCache* proc_cache;
    int last_proc_count;
} ProcCache;

typedef struct {
    char key[256];
    char* value;
    time_t last_update;
    UT_hash_handle hh;
} CpuSetCache;

struct linux_dirent64 {
    ino64_t d_ino;
    off64_t d_off;
    unsigned short d_reclen;
    unsigned char d_type;
    char d_name[];
};

// 全局变量
static bool log_enabled = false;
static bool log_minimal = false;
static FILE* log_fp = NULL;
static bool log_writing = false;
static char log_file_path[256];
static bool debug_set_from_args = false;
static CpuSetCache* cpu_set_cache = NULL;

// 函数原型声明
static char* get_timestamp(void);
static void ensure_log_file_dir(const char* dir);
static void ensure_log_file(void);
static void check_log_size(void);
static void write_log(const char* fmt, ...);
static void set_default_log_path(const char* config_file);
static void* xrealloc(void* ptr, size_t size);
static char* strtrim(char* s);
static char* cpu_set_to_str(const cpu_set_t* set);
static bool create_cpuset_dir(const char* path, const char* cpus, const char* mems);
static void parse_cpu_ranges(const char* spec, cpu_set_t* set, const cpu_set_t* present);
static CpuTopology init_cpu_topo(void);
static int calculate_rule_priority(const char* thread_pattern);
static void cleanup_temp_resources(AffinityRule** rules, size_t num_rules, AffinityRule*** wildcard_rules, size_t num_wildcard_rules, PackageEntry** pkg_table);
static bool load_config(AppConfig* cfg, const char* config_file);
static ProcEntryCache* get_proc_entry(ProcCache* cache, pid_t pid, int pid_fd);
static void cleanup_proc_cache(ProcCache* cache);
static bool scan_process_threads(ProcessInfo* proc, int pid_fd, const AppConfig* cfg);
static int compare_rules(const void* a, const void* b);
static ProcCache* update_proc_cache(ProcCache* cache, const AppConfig* cfg);
static bool apply_affinity(ProcessInfo* proc, const CpuTopology* topo, ProcCache* cache);
static void update_cache(ProcCache* cache, const AppConfig* cfg, int* affinity_counter);
static bool is_screen_on(void);
static void cleanup(AppConfig* config, ProcCache* cache);
static char log_buffer[4096];
static size_t log_buffer_len = 0;

// 日志模块
// 获取当前时间戳
static char* get_timestamp(void) {
    static char buf[32];
    time_t now = time(NULL);
    struct tm* tm = localtime(&now);
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", tm);
    return buf;
}

// 确保日志文件目录存在
static void ensure_log_file_dir(const char* dir) {
    struct stat st;
    if (stat(dir, &st) == 0) return;

    char* parent_dir = strdup(dir);
    if (!parent_dir) {
        return;
    }
    char* parent = dirname(parent_dir);
    if (strcmp(parent, dir) != 0) ensure_log_file_dir(parent);
    free(parent_dir);

    if (mkdir(dir, 0755) != 0 && errno != EEXIST) {
        fprintf(stderr, "Failed to create directory %s: %s\n", dir, strerror(errno));
    }
}

// 确保日志文件存在
static void ensure_log_file(void) {
    struct stat st;
    if (!log_fp || (stat(log_file_path, &st) != 0 && errno == ENOENT)) {
        if (log_fp) {
            fclose(log_fp);
            log_fp = NULL;
        }
        char* log_dir = strdup(log_file_path);
        if (!log_dir) {
            fprintf(stderr, "Failed to allocate memory for log directory path\n");
            return;
        }
        char* dir = dirname(log_dir);
        ensure_log_file_dir(dir);
        free(log_dir);

        log_fp = fopen(log_file_path, "a");
        if (!log_fp) {
            fprintf(stderr, "Failed to open log file %s: %s\n", log_file_path, strerror(errno));
        } else {
            LOG_I("Log file %s opened or created", log_file_path);
        }
    }
}

// 检查日志文件大小，超限时清空
static void check_log_size(void) {
    if (log_writing || !log_fp) return;
    struct stat st;
    if (stat(log_file_path, &st) == 0 && st.st_size >= MAX_LOG_SIZE) {
        fclose(log_fp);
        log_fp = fopen(log_file_path, "w");
        if (log_fp) fclose(log_fp);
        log_fp = NULL;
    }
}


static void flush_log_buffer(void) {
    if (log_buffer_len > 0 && log_fp) {
        fwrite(log_buffer, 1, log_buffer_len, log_fp);
        fflush(log_fp);
        log_buffer_len = 0;
    }
}

// 写入日志
static void write_log(const char* fmt, ...) {
    if (!log_enabled || (log_minimal && strstr(fmt, "[I]") != fmt)) return;
    ensure_log_file();
    if (!log_fp) {
        log_enabled = false;
        fprintf(stderr, "Logging disabled due to persistent file errors\n");
        return;
    }

    check_log_size();
    if (!log_fp) {
        ensure_log_file();
        if (!log_fp) {
            fprintf(stderr, "Failed to reopen log file %s after size check\n", log_file_path);
            return;
        }
    }

    char temp_buffer[2048];
    int len = snprintf(temp_buffer, sizeof(temp_buffer), "[%s] ", get_timestamp());
    if (len < 0 || len >= (int)sizeof(temp_buffer)) {
        return;
    }

    va_list args;
    va_start(args, fmt);
    len += vsnprintf(temp_buffer + len, sizeof(temp_buffer) - len, fmt, args);
    va_end(args);
    if (len < 0 || len >= (int)sizeof(temp_buffer)) {
        return;
    }

    if (len + 1 < (int)sizeof(temp_buffer)) {
        temp_buffer[len++] = '\n';
        temp_buffer[len] = '\0';
    } else {
        return;
    }
    
    if (log_buffer_len + len > sizeof(log_buffer) - 1) {
        flush_log_buffer();
    }
    memcpy(log_buffer + log_buffer_len, temp_buffer, len);
    log_buffer_len += len;
    if (log_buffer_len > sizeof(log_buffer) - 256) {
        flush_log_buffer();
    }
}

// 设置默认日志路径
static void set_default_log_path(const char* config_file) {
    char* last_slash = strrchr(config_file, '/');
    size_t config_len = strlen(config_file);
    size_t log_suffix_len = strlen("affinity_manager.log");

    if (last_slash) {
        size_t dir_len = last_slash - config_file + 1;
        if (dir_len + log_suffix_len + 1 > sizeof(log_file_path)) {
            LOG_W("Config file path too long, using default log file: affinity_manager.log");
            strncpy(log_file_path, "affinity_manager.log", sizeof(log_file_path) - 1);
        } else {
            strncpy(log_file_path, config_file, dir_len);
            log_file_path[dir_len] = '\0';
            strncat(log_file_path, "affinity_manager.log", sizeof(log_file_path) - dir_len - 1);
        }
    } else {
        if (log_suffix_len + 1 > sizeof(log_file_path)) {
            LOG_W("Log file name too long, truncating");
            strncpy(log_file_path, "affinity_manager.log", sizeof(log_file_path) - 1);
        } else {
            strncpy(log_file_path, "affinity_manager.log", sizeof(log_file_path) - 1);
        }
    }
   log_file_path[sizeof(log_file_path) - 1] = '\0';
}

// 工具函数
// 重新分配内存
static inline void* xrealloc(void* ptr, size_t size) {
    void* p = realloc(ptr, size);
    if (!p) {
        LOG_E("Memory allocation failed for size %zu, retaining original pointer", size);
        free(ptr);
        return NULL;
    }
    return p;
}

// 去除字符串首尾空白
static inline char* strtrim(char* s) {
    while (isspace((unsigned char)*s)) s++;
    if (!*s) return s;
    char* end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end)) end--;
    end[1] = '\0';
    return s;
}

// 将 CPU 集合转换为字符串
static char* cpu_set_to_str(const cpu_set_t* set) {
    char key[256];
    size_t key_len = sizeof(cpu_set_t);
    if (key_len > sizeof(key) - 1) {
        return NULL;
    }
    memcpy(key, set, key_len);
    key[key_len] = '\0';

    CpuSetCache* entry;
    HASH_FIND_STR(cpu_set_cache, key, entry);
    time_t now = time(NULL);
    if (entry) {
        entry->last_update = now;
        char* result = strdup(entry->value);
        if (!result) {
            return NULL;
        }
        return result;
    }

    size_t buf_size = 8 * CPU_SETSIZE;
    char* buf = malloc(buf_size);
    if (!buf) {
        return NULL;
    }

    int start = -1, end = -1;
    char* p = buf;
    size_t remain = buf_size - 1;
    bool first = true;

    for (int i = 0; i < CPU_SETSIZE; i++) {
        if (CPU_ISSET(i, set)) {
            if (start == -1) {
                start = end = i;
            } else if (i == end + 1) {
                end = i;
            } else {
                int needed;
                if (start == end) {
                    needed = snprintf(p, remain + 1, "%s%d", first ? "" : ",", start);
                } else {
                    needed = snprintf(p, remain + 1, "%s%d-%d", first ? "" : ",", start, end);
                }
                if (needed < 0 || (size_t)needed > remain) {
                    free(buf);
                    return NULL;
                }
                p += needed;
                remain -= needed;
                start = end = i;
                first = false;
            }
        }
    }

    if (start != -1) {
        int needed;
        if (start == end) {
            needed = snprintf(p, remain + 1, "%s%d", first ? "" : ",", start);
        } else {
            needed = snprintf(p, remain + 1, "%s%d-%d", first ? "" : ",", start, end);
        }
        if (needed < 0 || (size_t)needed > remain) {
            free(buf);
            return NULL;
        }
        p += needed;
    }
    *p = '\0';

    CpuSetCache* new_entry = malloc(sizeof(CpuSetCache));
    if (!new_entry) {
        free(buf);
        return NULL;
    }

    size_t len = sizeof(cpu_set_t);
    if (len >= sizeof(new_entry->key)) len = sizeof(new_entry->key) - 1;
    memcpy(new_entry->key, key, len);
    new_entry->key[len] = '\0';
    new_entry->value = strdup(buf);
    if (!new_entry->value) {
        free(new_entry);
        free(buf);
        return NULL;
    }
    new_entry->last_update = now;
    HASH_ADD_STR(cpu_set_cache, key, new_entry);

    size_t cache_size = HASH_COUNT(cpu_set_cache);
    if (cache_size > MAX_CPU_SET_CACHE_SIZE) {
        CpuSetCache* tmp, *iter;
        HASH_ITER(hh, cpu_set_cache, iter, tmp) {
            HASH_DEL(cpu_set_cache, iter);
            free(iter->value);
            free(iter);
            if (--cache_size <= MAX_CPU_SET_CACHE_SIZE) break;
        }
    }

    return buf;
}

// 创建 cpuset 目录并配置
static bool create_cpuset_dir(const char* path, const char* cpus, const char* mems) {
    struct stat st;
    bool need_create = true;
    if (stat(path, &st) == 0 && S_ISDIR(st.st_mode)) {
        if ((st.st_mode & 0755) == 0755 && st.st_uid == 0 && st.st_gid == 0) {
            need_create = false;
        }
    }
    if (need_create) {
        if (access(path, W_OK) != 0 && errno != ENOENT) {
            return false;
        }
        if (mkdir(path, 0755) != 0 && errno != EEXIST) {
            return false;
        }
        if (chmod(path, 0755) != 0) {
            return false;
        }
        if (chown(path, 0, 0) != 0) {
            return false;
        }
    }

    char existing_cpus[256] = {0};
    char cpus_path[256];
    snprintf(cpus_path, sizeof(cpus_path), "%s/cpus", path);
    int cpus_fd = open(cpus_path, O_RDONLY);
    if (cpus_fd >= 0) {
        ssize_t n = read(cpus_fd, existing_cpus, sizeof(existing_cpus) - 1);
        close(cpus_fd);
        if (n > 0) {
            existing_cpus[n] = '\0';
            if (strcmp(existing_cpus, cpus) == 0) {
                goto check_mems;
            }
        }
    }
    cpus_fd = open(cpus_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (cpus_fd < 0) {
        return false;
    }
    if (write(cpus_fd, cpus, strlen(cpus)) != (ssize_t)strlen(cpus)) {
        close(cpus_fd);
        return false;
    }
    close(cpus_fd);

check_mems: {
    char existing_mems[256] = {0};
    char mems_path[256];
    snprintf(mems_path, sizeof(mems_path), "%s/mems", path);
    int mems_fd = open(mems_path, O_RDONLY);
    if (mems_fd >= 0) {
        ssize_t n = read(mems_fd, existing_mems, sizeof(existing_mems) - 1);
        close(mems_fd);
        if (n > 0) {
            existing_mems[n] = '\0';
            if (strcmp(existing_mems, mems) == 0) {
                return true;
            }
        }
    }
    mems_fd = open(mems_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (mems_fd < 0) {
        return false;
    }
    if (write(mems_fd, mems, strlen(mems)) != (ssize_t)strlen(mems)) {
        close(mems_fd);
        LOG_E("Failed to write to %s: %s", mems_path, strerror(errno));
        return false;
    }
    close(mems_fd);
}
    return true;
}

// CPU 拓扑管理
// 解析 CPU 范围
static void parse_cpu_ranges(const char* spec, cpu_set_t* set, const cpu_set_t* present) {
    if (!spec) return;
    char* copy = strdup(spec);
    if (!copy) {
        return;
    }
    char* s = copy;

    while (*s) {
        char* end;
        unsigned long a = strtoul(s, &end, 10);
        if (end == s) {
            s++;
            continue;
        }

        unsigned long b = a;
        if (*end == '-') {
            s = end + 1;
            b = strtoul(s, &end, 10);
            if (end == s) b = a;
        }

        if (a > b) {
            unsigned long t = a;
            a = b;
            b = t;
        }
        for (unsigned long i = a; i <= b && i < CPU_SETSIZE; i++) {
            if (present && !CPU_ISSET(i, present)) continue;
            CPU_SET(i, set);
        }

        s = (*end == ',') ? end + 1 : end;
    }
    free(copy);
}

// 初始化 CPU 拓扑
static CpuTopology init_cpu_topo(void) {
    CpuTopology topo = { .cpuset_enabled = false };
    CPU_ZERO(&topo.present_cpus);

    int fd = open("/sys/devices/system/cpu/present", O_RDONLY);
    if (fd >= 0) {
        char buf[64] = {0};
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0) {
            char* p = strtrim(buf);
            char* end = strchr(p, '\n');
            if (end) *end = '\0';
            strncpy(topo.present_str, p, sizeof(topo.present_str) - 1);
            parse_cpu_ranges(topo.present_str, &topo.present_cpus, NULL);
        }
    }

    if (access("/dev/cpuset", W_OK) != 0) {
        return topo;
    }

    const char* cpuset_dir = BASE_CPUSET;
    if (mkdir(cpuset_dir, 0755) != 0 && errno != EEXIST) {
        return topo;
    }

    if (!create_cpuset_dir(cpuset_dir, topo.present_str, "0")) {
        return topo;
    }

    char mems_path[256];
    snprintf(mems_path, sizeof(mems_path), "%s/mems", cpuset_dir);
    int mems_fd = open(mems_path, O_RDONLY);
    if (mems_fd >= 0) {
        ssize_t n = read(mems_fd, topo.mems_str, sizeof(topo.mems_str) - 1);
        close(mems_fd);
        if (n > 0) {
            topo.mems_str[n] = '\0';
            strtrim(topo.mems_str);
        } else {
            strcpy(topo.mems_str, "0");
        }
    } else {
        strcpy(topo.mems_str, "0");
    }

    topo.cpuset_enabled = true;
    return topo;
}

// 配置管理
// 计算规则优先级
static int calculate_rule_priority(const char* thread_pattern) {
    if (!thread_pattern || !*thread_pattern) {
        return 200;
    }
    int priority = 0;
    size_t len = strlen(thread_pattern);
    const char* p = thread_pattern;

    if (strchr(p, '*') == NULL && strchr(p, '?') == NULL && strchr(p, '[') == NULL) {
        return 1000 + len;
    }

    int non_wildcard_chars = 0;
    bool has_range = false;
    bool has_single_wildcard = false;
    bool has_star = false;

    while (*p) {
        if (*p == '[') has_range = true;
        else if (*p == '?') has_single_wildcard = true;
        else if (*p == '*') has_star = true;
        else non_wildcard_chars++;
        p++;
    }

    if (has_range) {
        priority = 500 + non_wildcard_chars;
    } else if (has_single_wildcard) {
        priority = 300 + non_wildcard_chars;
    } else if (has_star) {
        priority = 100 + non_wildcard_chars;
    }

    return priority;
}

// 清理临时资源
static void cleanup_temp_resources(AffinityRule** rules, size_t num_rules, AffinityRule*** wildcard_rules, size_t num_wildcard_rules, PackageEntry** pkg_table) {
    if (rules && *rules) {
        free(*rules);
        *rules = NULL;
    }
    if (wildcard_rules && *wildcard_rules) {
        free(*wildcard_rules);
        *wildcard_rules = NULL;
    }
    if (pkg_table && *pkg_table) {
        PackageEntry* entry, *tmp;
        HASH_ITER(hh, *pkg_table, entry, tmp) {
            HASH_DEL(*pkg_table, entry);
            free(entry);
        }
        *pkg_table = NULL;
    }
}

// 加载配置文件
static char* strtrim_line(char* s) {
    char* start = s;
    while (isspace((unsigned char)*start)) start++;
    if (!*start) return start;
    char* end = start + strlen(start) - 1;
    while (end > start && (isspace((unsigned char)*end) || *end == '#')) end--;
    end[1] = '\0';
    return start;
}

static bool load_config(AppConfig* cfg, const char* config_file) {
    struct stat st;
    if (stat(config_file, &st) != 0) {
        LOG_W("Config file %s not found, waiting 5 seconds before creating empty file", config_file);
        struct timespec delay = { .tv_sec = 5, .tv_nsec = 0 };
        nanosleep(&delay, NULL);

        if (stat(config_file, &st) != 0) {
            FILE* fp = fopen(config_file, "w");
            if (fp) {
                fclose(fp);
                LOG_I("Created empty config file %s", config_file);
            } else {
                LOG_E("Failed to create config file %s: %s", config_file, strerror(errno));
                return false;
            }
        }
        return false;
    }

    if (st.st_mtime <= cfg->mtime) return false;

    int fd = open(config_file, O_RDONLY);
    if (fd < 0) {
        LOG_E("Failed to open %s: %s", config_file, strerror(errno));
        return false;
    }

    char* data = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    if (data == MAP_FAILED) {
        LOG_E("Failed to mmap %s: %s", config_file, strerror(errno));
        return false;
    }

    AffinityRule* rules = malloc(INITIAL_RULE_CAPACITY * sizeof(AffinityRule));
    size_t rules_capacity = INITIAL_RULE_CAPACITY;
    size_t num_rules = 0;
    AffinityRule** wildcard_rules = malloc(INITIAL_WILDCARD_CAPACITY * sizeof(AffinityRule*));
    size_t wildcard_capacity = INITIAL_WILDCARD_CAPACITY;
    size_t num_wildcard_rules = 0;
    bool log_set = false;
    char line[256];
    PackageEntry* pkg_table = NULL;
    size_t line_number = 0;

    if (!rules || !wildcard_rules) {
        munmap(data, st.st_size);
        free(rules);
        free(wildcard_rules);
        return false;
    }

    char* line_ptr = data;
    char* end = data + st.st_size;
    while (line_ptr < end) {
        char* newline = memchr(line_ptr, '\n', end - line_ptr);
        if (!newline) newline = end;
        size_t line_len = newline - line_ptr;
        line_number++;

        if (line_len >= sizeof(line)) {
            LOG_W("Line %zu too long, skipping", line_number);
            line_ptr = newline + 1;
            continue;
        }

        strncpy(line, line_ptr, line_len);
        line[line_len] = '\0';
        line_ptr = newline + 1;

        char* p = strtrim_line(line);
        if (!*p || *p == '#') continue;

        char* eq = strchr(p, '=');
        if (!eq) {
            LOG_W("Invalid rule at line %zu: missing '=': %s", line_number, p);
            continue;
        }
        *eq++ = '\0';

        char* key = strtrim(p);
        char* value = strtrim(eq);

        char* comment = strchr(value, '#');
        if (comment) *comment = '\0';
        value = strtrim(value);

        if (!*key || !*value) {
            LOG_W("Invalid rule at line %zu: empty key or value: %s", line_number, p);
            continue;
        }

        if (!strcmp(key, "Debug_AppOpt")) {
            if (log_set || debug_set_from_args) continue;
            log_enabled = !strcmp(value, "true");
            log_set = true;
            LOG_I("Debug_AppOpt set to %s at line %zu", value, line_number);
            continue;
        }

        char* br = strchr(key, '{');
        char* thread = "";
        if (br) {
            *br++ = '\0';
            char* eb = strchr(br, '}');
            if (!eb) {
                LOG_W("Invalid rule at line %zu: missing closing '}': %s", line_number, p);
                continue;
            }
            *eb = '\0';
            thread = strtrim(br);
        }

        char* pkg = strtrim(key);
        if (strlen(pkg) >= MAX_PKG_LEN || strlen(thread) >= MAX_THREAD_LEN) {
            LOG_W("Invalid rule at line %zu: package or thread name too long: %s", line_number, p);
            continue;
        }
        
        /*
        if (!thread[0]) {
            LOG_I("Process(empty) rule at line %zu: %s=%s", line_number, pkg, value);
        } else if (strcmp(thread, " ") == 0) {
            LOG_I("Space-only thread name at line %zu: %s{%s}=%s", line_number, pkg, thread, value);
        } else {
            LOG_I("Loaded rule at line %zu: %s{%s}=%s", line_number, pkg, thread, value);
        }
        */

        bool is_duplicate = false;
        for (size_t i = 0; i < num_rules; i++) {
            if (!strcmp(rules[i].pkg, pkg) && !strcmp(rules[i].thread, thread)) {
                LOG_W("Duplicate rule at line %zu: %s{%s}=%s, please check configuration",
                      line_number, pkg, thread, value);
                is_duplicate = true;
                break;
            }
        }
        if (is_duplicate) continue;

        if (num_rules >= rules_capacity) {
            rules_capacity *= 2;
            AffinityRule* temp_rules = realloc(rules, rules_capacity * sizeof(AffinityRule));
            if (!temp_rules) {
                munmap(data, st.st_size);
                cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
                return false;
            }
            rules = temp_rules;
        }

        AffinityRule* rule = &rules[num_rules];
        strncpy(rule->pkg, pkg, MAX_PKG_LEN - 1);
        rule->pkg[MAX_PKG_LEN - 1] = '\0';
        strncpy(rule->thread, thread, MAX_THREAD_LEN - 1);
        rule->thread[MAX_THREAD_LEN - 1] = '\0';
        CPU_ZERO(&rule->cpus);
        parse_cpu_ranges(value, &rule->cpus, &cfg->topo.present_cpus);
        rule->is_wildcard = (strchr(pkg, '*') != NULL || strchr(pkg, '?') != NULL);
        rule->priority = calculate_rule_priority(rule->thread);

        if (CPU_COUNT(&rule->cpus) == 0) {
            LOG_E("Invalid CPU range at line %zu: %s in rule: %s{%s}=%s, check available CPUs (%s)",
                  line_number, value, pkg, thread, value, cfg->topo.present_str);
            continue;
        }

        char* dir_name = cpu_set_to_str(&rule->cpus);
        if (!dir_name) {
            LOG_E("Failed to convert CPU set to string at line %zu", line_number);
            continue;
        }
        char cpuset_path[256];
        snprintf(cpuset_path, sizeof(cpuset_path), "%s/%s", cfg->cpuset_base, dir_name);
        if (!create_cpuset_dir(cpuset_path, dir_name, cfg->topo.mems_str)) {
            LOG_E("Failed to create cpuset directory %s at line %zu", cpuset_path, line_number);
            free(dir_name);
            continue;
        }
        strncpy(rule->cpuset_dir, dir_name, sizeof(rule->cpuset_dir) - 1);
        rule->cpuset_dir[sizeof(rule->cpuset_dir) - 1] = '\0';
        free(dir_name);

        num_rules++;

        if (!rule->is_wildcard) {
            PackageEntry* pkg_entry;
            HASH_FIND_STR(pkg_table, pkg, pkg_entry);
            if (!pkg_entry) {
                pkg_entry = malloc(sizeof(PackageEntry));
                if (!pkg_entry) {
                    munmap(data, st.st_size);
                    cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
                    return false;
                }
                strncpy(pkg_entry->pkg, pkg, MAX_PKG_LEN - 1);
                pkg_entry->pkg[MAX_PKG_LEN - 1] = '\0';
                HASH_ADD_STR(pkg_table, pkg, pkg_entry);
            }
        } else {
            if (num_wildcard_rules >= wildcard_capacity) {
                wildcard_capacity *= 2;
                AffinityRule** temp_wildcard_rules = realloc(wildcard_rules, wildcard_capacity * sizeof(AffinityRule*));
                if (!temp_wildcard_rules) {
                    munmap(data, st.st_size);
                    cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
                    return false;
                }
                wildcard_rules = temp_wildcard_rules;
            }
            wildcard_rules[num_wildcard_rules++] = rule;
        }
    }

    munmap(data, st.st_size);

    if (!num_rules) {
        LOG_W("No valid rules loaded from %s", config_file);
        cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
        return false;
    }

    size_t num_pkgs = HASH_COUNT(pkg_table);
    char** pkgs = malloc(INITIAL_PKG_CAPACITY * sizeof(char*));
    size_t pkgs_capacity = INITIAL_PKG_CAPACITY;
    if (!pkgs) {
        cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
        return false;
    }
    PackageEntry* entry, *tmp;
    size_t i = 0;
    HASH_ITER(hh, pkg_table, entry, tmp) {
        if (i >= pkgs_capacity) {
            pkgs_capacity *= 2;
            char** temp_pkgs = realloc(pkgs, pkgs_capacity * sizeof(char*));
            if (!temp_pkgs) {
                for (size_t j = 0; j < i; j++) free(pkgs[j]);
                free(pkgs);
                cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
                return false;
            }
            pkgs = temp_pkgs;
        }
        pkgs[i] = strdup(entry->pkg);
        if (!pkgs[i]) {
            for (size_t j = 0; j < i; j++) free(pkgs[j]);
            free(pkgs);
            cleanup_temp_resources(&rules, num_rules, &wildcard_rules, num_wildcard_rules, &pkg_table);
            return false;
        }
        i++;
    }

    LOG_I("Config loaded: %zu rules, %zu packages, %zu wildcard rules (mtime: %ld)",
          num_rules, num_pkgs, num_wildcard_rules, st.st_mtime);

    // 清理旧资源
    if (cfg->rules) free(cfg->rules);
    if (cfg->wildcard_rules) free(cfg->wildcard_rules);
    if (cfg->pkgs) {
        for (size_t j = 0; j < cfg->num_pkgs; j++) free(cfg->pkgs[j]);
        free(cfg->pkgs);
    }
    HASH_CLEAR(hh, cfg->pkg_table);
    PackageEntry* old_entry, *old_tmp;
    HASH_ITER(hh, cfg->pkg_table, old_entry, old_tmp) {
        HASH_DEL(cfg->pkg_table, old_entry);
        free(old_entry);
    }

    cfg->rules = rules;
    cfg->num_rules = num_rules;
    cfg->wildcard_rules = wildcard_rules;
    cfg->num_wildcard_rules = num_wildcard_rules;
    cfg->pkgs = pkgs;
    cfg->num_pkgs = num_pkgs;
    cfg->pkg_table = pkg_table;
    cfg->mtime = st.st_mtime;
    return true;
}

// 进程和线程管理
static int get_proc_entries(int dir_fd, struct linux_dirent64* buffer, size_t buf_size) {
    return syscall(__NR_getdents64, dir_fd, buffer, buf_size);
}

static bool read_file(int dir_fd, const char* filename, char* buf, size_t buf_size) {
    int fd = openat(dir_fd, filename, O_RDONLY | O_CLOEXEC);
    if (fd == -1) {
        return false;
    }
    bool success = false;
    ssize_t total = 0;
    while (total < (ssize_t)(buf_size - 1)) {
        ssize_t n = read(fd, buf + total, buf_size - 1 - total);
        if (n == -1) {
            if (errno == EINTR) continue;
            goto cleanup;
        }
        if (n == 0) break;
        total += n;
    }
    if (total > 0) {
        buf[total] = '\0';
        success = true;
    }
cleanup:
    close(fd);
    return success;
}

// 获取 /proc 条目
static ProcEntryCache* get_proc_entry(ProcCache* cache, pid_t pid, int proc_fd) {
    ProcEntryCache* entry;
    HASH_FIND_INT(cache->proc_cache, &pid, entry);
    time_t now = time(NULL);

    struct stat stat_info;
    if (fstatat(proc_fd, "stat", &stat_info, 0) != 0) {
        return NULL;
    }

    unsigned long uptime = 0;
    char stat_buf[1024];
    struct timespec ts;
    if (clock_gettime(CLOCK_BOOTTIME, &ts) == 0) {
        uptime = (unsigned long)ts.tv_sec;
    } else {
        if (read_file(AT_FDCWD, "/proc/uptime", stat_buf, sizeof(stat_buf))) {
            uptime = strtoul(stat_buf, NULL, 10);
        }
    }

    if (entry && entry->start_time_valid && stat_info.st_mtime <= entry->last_update) {
        entry->last_checked = now;
        return entry;
    }

    if (entry && entry->start_time_valid) {
        long ticks_per_sec = sysconf(_SC_CLK_TCK);
        time_t runtime = (uptime * ticks_per_sec - entry->start_time) / ticks_per_sec;
        int entry_cache_time = (runtime < 10) ? 1 : (runtime < 30) ? 3 : 5;
        if (now - entry->last_update < entry_cache_time) {
            entry->last_checked = now;
            return entry;
        }
    }

    if (!read_file(proc_fd, "stat", stat_buf, sizeof(stat_buf))) {
        return NULL;
    }
    
    char* field = stat_buf;
    for (int i = 1; i < 22; i++) {
        field = strchr(field + 1, ' ');
        if (!field) return NULL;
    }
    unsigned long starttime = strtoul(field + 1, NULL, 10);

    long ticks_per_sec = sysconf(_SC_CLK_TCK);
    time_t runtime = (uptime * ticks_per_sec - starttime) / ticks_per_sec;
    int entry_cache_time = (runtime < 10) ? 1 : (runtime < 30) ? 3 : 5;

    char cmd[MAX_PKG_LEN] = {0};
    if (!read_file(proc_fd, "cmdline", cmd, sizeof(cmd))) {
        return NULL;
    }

    if (!entry) {
        entry = malloc(sizeof(ProcEntryCache));
        if (!entry) return NULL;
        memset(entry, 0, sizeof(ProcEntryCache));
        entry->pid = pid;
        HASH_ADD_INT(cache->proc_cache, pid, entry);
    }
    strncpy(entry->cmdline, cmd, MAX_PKG_LEN - 1);
    entry->last_update = (runtime < 30) ? now - entry_cache_time : now;
    entry->start_time = starttime;
    entry->start_time_valid = true;
    entry->last_checked = now;
    entry->stat_mtime = stat_info.st_mtime;

    if (HASH_COUNT(cache->proc_cache) > 100) {
        ProcEntryCache* tmp, *iter;
        size_t cache_size = HASH_COUNT(cache->proc_cache);
        HASH_ITER(hh, cache->proc_cache, iter, tmp) {
            HASH_DEL(cache->proc_cache, iter);
            memset(iter, 0, sizeof(ProcEntryCache));
            free(iter);
            if (--cache_size <= 80) break;
        }
    }
    return entry;
}

// 清理进程缓存
static void cleanup_proc_cache(ProcCache* cache) {
    ProcEntryCache* entry, *tmp;
    time_t now = time(NULL);

    HASH_ITER(hh, cache->proc_cache, entry, tmp) {
        if (now - entry->last_update > PROC_ENTRY_CACHE_TIME * 2) {
            HASH_DEL(cache->proc_cache, entry);
            memset(entry, 0, sizeof(ProcEntryCache));
            free(entry);
        } else if (now - entry->last_checked >= ERROR_CACHE_TIMEOUT) {
            entry->start_time_valid = false;
            entry->last_checked = 0;
        }
    }

    CpuSetCache* cpu_set_entry, *cpu_set_tmp;
    HASH_ITER(hh, cpu_set_cache, cpu_set_entry, cpu_set_tmp) {
        if (now - cpu_set_entry->last_update > ERROR_CACHE_TIMEOUT * 2) {
            HASH_DEL(cpu_set_cache, cpu_set_entry);
            free(cpu_set_entry->value);
            free(cpu_set_entry);
        }
    }
}

// 扫描进程线程
static bool scan_process_threads(ProcessInfo* proc, int pid_fd, const AppConfig* cfg) {
    if (proc->num_thread_rules == 0 && CPU_COUNT(&proc->base_cpus) == 0) {
        return false;
    }

    int task_fd = openat(pid_fd, "task", O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (task_fd == -1) {
        return false;
    }

    ThreadInfo* threads = NULL;
    size_t num_threads = 0;

    char* dent_buf = malloc(DENT_BUF_SIZE);
    if (!dent_buf) {
        close(task_fd);
        LOG_E("Memory allocation failed for dent_buf in scan_process_threads");
        return false;
    }

    while (1) {
        int nread = syscall(__NR_getdents64, task_fd, dent_buf, DENT_BUF_SIZE);
        if (nread == -1) {
            LOG_E("getdents64 failed for /proc/%d/task: %s", proc->pid, strerror(errno));
            free(dent_buf);
            close(task_fd);
            free(threads);
            return false;
        }
        if (nread == 0) break;

        for (int pos = 0; pos < nread;) {
            struct linux_dirent64* ent = (struct linux_dirent64*)(dent_buf + pos);
            if (ent->d_type != DT_DIR || !isdigit(ent->d_name[0])) {
                pos += ent->d_reclen;
                continue;
            }

            pid_t tid = atoi(ent->d_name);

            char comm_path[64];
            snprintf(comm_path, sizeof(comm_path), "%s/comm", ent->d_name);
            int comm_fd = openat(task_fd, comm_path, O_RDONLY | O_CLOEXEC);
            if (comm_fd == -1) {
                pos += ent->d_reclen;
                continue;
            }

            char tname[MAX_THREAD_LEN] = {0};
            ssize_t n = read(comm_fd, tname, sizeof(tname) - 1);
            close(comm_fd);
            if (n <= 0) {
                pos += ent->d_reclen;
                continue;
            }
            if (tname[n - 1] == '\n') tname[n - 1] = '\0';

            bool is_all_spaces = true;
            if (tname[0] == '\0') {
            } else {
                is_all_spaces = true;
                for (size_t i = 0; tname[i]; i++) {
                    if (tname[i] != ' ') {
                        is_all_spaces = false;
                        break;
                    }
                }
                if (is_all_spaces) {
                    strcpy(tname, " ");
                }
            }

            cpu_set_t mask;
            CPU_ZERO(&mask);
            bool matched = false;
            int highest_priority = -1;
            size_t best_rule_idx = 0;

            for (size_t i = 0; i < proc->num_thread_rules; i++) {
                const AffinityRule* rule = proc->thread_rules[i];
                const char* rule_thread = rule->thread;

                if (strcmp(rule_thread, tname) == 0 ||
                    (rule_thread[0] == '\0' && (tname[0] == '\0' || strcmp(tname, " ") == 0))) {
                    CPU_OR(&mask, &mask, &rule->cpus);
                    matched = true;
                    break;
                } else if (rule->priority < 1000 && fnmatch(rule_thread, tname, 0) == 0) {
                    if (rule->priority > highest_priority) {
                        highest_priority = rule->priority;
                        best_rule_idx = i;
                    }
                }
            }

            if (!matched && highest_priority >= 0) {
                CPU_OR(&mask, &mask, &proc->thread_rules[best_rule_idx]->cpus);
                matched = true;
            }

            cpu_set_t valid_mask;
            CPU_AND(&valid_mask, &mask, &cfg->topo.present_cpus);
            if (!matched && CPU_COUNT(&valid_mask) == 0 && CPU_COUNT(&proc->base_cpus) == 0) {
                pos += ent->d_reclen;
                continue;
            }

            ThreadInfo* temp_threads = xrealloc(threads, (num_threads + 1) * sizeof(ThreadInfo));
            if (!temp_threads) {
                free(threads);
                free(dent_buf);
                close(task_fd);
                LOG_E("Memory allocation failed for threads in scan_process_threads");
                return false;
            }
            threads = temp_threads;

            ThreadInfo* new_thread = &threads[num_threads];
            memset(new_thread, 0, sizeof(ThreadInfo));
            new_thread->tid = tid;
            new_thread->cpus = CPU_COUNT(&valid_mask) ? valid_mask : proc->base_cpus;
            strncpy(new_thread->name, tname, MAX_THREAD_LEN - 1);
            CPU_ZERO(&new_thread->last_cpus);
            new_thread->create_time = time(NULL);

            num_threads++;
            pos += ent->d_reclen;
        }
    }

    free(dent_buf);
    close(task_fd);

    free(proc->threads);
    proc->threads = threads;
    proc->num_threads = num_threads;
    proc->scanned = true;
    return true;
}

// 比较规则优先级
static int compare_rules(const void* a, const void* b) {
    AffinityRule* ra = *(AffinityRule**)a;
    AffinityRule* rb = *(AffinityRule**)b;
    return rb->priority - ra->priority;
}

// 更新进程缓存
static ProcCache* update_proc_cache(ProcCache* cache, const AppConfig* cfg) {
    time_t now = time(NULL);
    bool force_update = (now - cache->last_update >= PROC_CACHE_TIME || cache->last_update == 0);

    int proc_fd = open("/proc", O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    size_t procs_capacity = cache->num_procs ? cache->num_procs * 2 : 128;
    ProcessInfo* procs = malloc(procs_capacity * sizeof(ProcessInfo));
    if (!procs) {
        close(proc_fd);
        LOG_E("Memory allocation failed for procs");
        return cache;
    }
    size_t num_procs = 0;
    bool has_changes = false;

    struct PidEntry {
        pid_t pid;
        UT_hash_handle hh;
    };
    struct PidEntry* existing_pids = NULL;
    for (size_t i = 0; i < cache->num_procs; i++) {
        struct PidEntry* entry = malloc(sizeof(struct PidEntry));
        if (entry) {
            entry->pid = cache->procs[i].pid;
            HASH_ADD_INT(existing_pids, pid, entry);
        }
    }

    char* dent_buf = malloc(DENT_BUF_SIZE);
    if (!dent_buf) {
        for (size_t i = 0; i < num_procs; i++) {
            free(procs[i].threads);
            free(procs[i].thread_rules);
        }
        free(procs);
        close(proc_fd);
        struct PidEntry* pid_entry, *pid_tmp;
        HASH_ITER(hh, existing_pids, pid_entry, pid_tmp) {
            HASH_DEL(existing_pids, pid_entry);
            free(pid_entry);
        }
        LOG_E("Memory allocation failed for dent_buf");
        return cache;
    }

    while (1) {
        int nread = get_proc_entries(proc_fd, (struct linux_dirent64*)dent_buf, DENT_BUF_SIZE);
        if (nread == -1) {
            LOG_E("getdents64 failed: %s", strerror(errno));
            break;
        }
        if (nread == 0) break;

        for (int pos = 0; pos < nread;) {
            struct linux_dirent64* ent = (struct linux_dirent64*)(dent_buf + pos);
            if (ent->d_type != DT_DIR || !isdigit(ent->d_name[0])) {
                pos += ent->d_reclen;
                continue;
            }

            pid_t pid = atoi(ent->d_name);
            int pid_fd = openat(proc_fd, ent->d_name, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
            if (pid_fd == -1) {
                pos += ent->d_reclen;
                continue;
            }

            char cmd[MAX_PKG_LEN] = {0};
            if (!read_file(pid_fd, "cmdline", cmd, sizeof(cmd))) {
                close(pid_fd);
                pos += ent->d_reclen;
                continue;
            }
            char* name = strrchr(cmd, '/') ? strrchr(cmd, '/') + 1 : cmd;
            PackageEntry* pkg_entry;
            HASH_FIND_STR(cfg->pkg_table, name, pkg_entry);
            bool matched = (pkg_entry != NULL);
            if (!matched) {
                for (size_t i = 0; i < cfg->num_wildcard_rules; i++) {
                    const AffinityRule* rule = cfg->wildcard_rules[i];
                    if (fnmatch(rule->pkg, name, 0) == 0) {
                        matched = true;
                        break;
                    }
                }
            }
            if (!matched) {
                close(pid_fd);
                pos += ent->d_reclen;
                continue;
            }

            struct PidEntry* pid_entry;
            HASH_FIND_INT(existing_pids, &pid, pid_entry);
            bool is_new = (pid_entry == NULL);

            struct stat st;
            if (fstatat(pid_fd, "stat", &st, 0) != 0) {
                close(pid_fd);
                pos += ent->d_reclen;
                continue;
            }
            bool stat_changed = (pid_entry && st.st_mtime > cache->last_update);

            if (!force_update && !is_new && !stat_changed) {
                close(pid_fd);
                pos += ent->d_reclen;
                continue;
            }

            ProcEntryCache* entry = get_proc_entry(cache, pid, pid_fd);
            if (!entry) {
                close(pid_fd);
                pos += ent->d_reclen;
                continue;
            }

            if (num_procs >= procs_capacity) {
                procs_capacity *= 2;
                ProcessInfo* temp_procs = xrealloc(procs, procs_capacity * sizeof(ProcessInfo));
                if (!temp_procs) {
                    for (size_t i = 0; i < num_procs; i++) {
                        free(procs[i].threads);
                        free(procs[i].thread_rules);
                    }
                    free(procs);
                    procs = NULL;
                    close(pid_fd);
                    free(dent_buf);
                    struct PidEntry* pid_entry, *pid_tmp;
                    HASH_ITER(hh, existing_pids, pid_entry, pid_tmp) {
                        HASH_DEL(existing_pids, pid_entry);
                        free(pid_entry);
                    }
                    LOG_E("Memory allocation failed for procs");
                    close(proc_fd);
                    return cache;
                }
                procs = temp_procs;
            }

            ProcessInfo* proc = &procs[num_procs++];
            proc->pid = pid;
            strncpy(proc->pkg, name, MAX_PKG_LEN - 1);
            CPU_ZERO(&proc->base_cpus);
            proc->threads = NULL;
            proc->num_threads = 0;
            proc->thread_rules = NULL;
            proc->num_thread_rules = 0;
            proc->scanned = false;

            for (size_t i = 0; i < cfg->num_rules; i++) {
                const AffinityRule* rule = &cfg->rules[i];
                if ((strcmp(rule->pkg, proc->pkg) == 0) ||
                    (rule->is_wildcard && fnmatch(rule->pkg, proc->pkg, 0) == 0)) {
                    if (rule->thread[0] || strcmp(rule->thread, " ") == 0) {
                        AffinityRule** temp_thread_rules = xrealloc(proc->thread_rules,
                            (proc->num_thread_rules + 1) * sizeof(AffinityRule*));
                        if (!temp_thread_rules) {
                            free(proc->thread_rules);
                            proc->thread_rules = NULL;
                            proc->num_thread_rules = 0;
                            num_procs--;
                            close(pid_fd);
                            pos += ent->d_reclen;
                            continue;
                        }
                        proc->thread_rules = temp_thread_rules;
                        proc->thread_rules[proc->num_thread_rules++] = (AffinityRule*)rule;
                    } else {
                        CPU_OR(&proc->base_cpus, &proc->base_cpus, &rule->cpus);
                    }
                }
            }

            if (proc->num_thread_rules > 1) {
                qsort(proc->thread_rules, proc->num_thread_rules, sizeof(AffinityRule*), compare_rules);
            }

            if (proc->num_thread_rules == 0 && CPU_COUNT(&proc->base_cpus) == 0) {
                free(proc->thread_rules);
                proc->thread_rules = NULL;
                num_procs--;
                close(pid_fd);
                pos += ent->d_reclen;
                continue;
            }

            if (force_update || is_new || stat_changed) {
                if (scan_process_threads(proc, pid_fd, cfg)) {
                    has_changes |= apply_affinity(proc, &cfg->topo, cache);
                } else {
                    free(proc->thread_rules);
                    proc->thread_rules = NULL;
                    num_procs--;
                }
            }
            close(pid_fd);
            pos += ent->d_reclen;
        }
    }

    free(dent_buf);
    close(proc_fd);

    struct PidEntry* pid_entry, *pid_tmp;
    HASH_ITER(hh, existing_pids, pid_entry, pid_tmp) {
        HASH_DEL(existing_pids, pid_entry);
        free(pid_entry);
    }

    if (cache->procs) {
        for (size_t i = 0; i < cache->num_procs; i++) {
            free(cache->procs[i].threads);
            free(cache->procs[i].thread_rules);
        }
        free(cache->procs);
        cache->procs = NULL;
        cache->num_procs = 0;
    }

    cache->procs = procs;
    cache->num_procs = num_procs;
    cache->last_update = now;

    return cache;
}

// 应用 CPU 亲和性
static bool apply_affinity(ProcessInfo* proc, const CpuTopology* topo, ProcCache* cache) {
    bool applied = false;

    for (size_t i = 0; i < proc->num_threads; i++) {
        ThreadInfo* ti = &proc->threads[i];

        if (CPU_EQUAL(&ti->cpus, &ti->last_cpus)) {
            continue;
        }

        cpu_set_t affinity_mask = ti->cpus;
        if (sched_setaffinity(ti->tid, sizeof(affinity_mask), &affinity_mask) == 0) {
            ti->last_cpus = affinity_mask;
            applied = true;
        } else if (errno == ESRCH) {
            cache->last_proc_count = 0;
            continue;
        }

        if (topo->cpuset_enabled) {
            bool cpuset_written = false;
            for (size_t j = 0; j < proc->num_thread_rules && !cpuset_written; j++) {
                const AffinityRule* rule = proc->thread_rules[j];
                if (CPU_EQUAL(&ti->cpus, &rule->cpus)) {
                    char tasks_path[256];
                    snprintf(tasks_path, sizeof(tasks_path), "%s/%s/tasks", BASE_CPUSET, rule->cpuset_dir);
                    int fd = open(tasks_path, O_WRONLY | O_APPEND);
                    if (fd >= 0) {
                        dprintf(fd, "%d\n", ti->tid);
                        close(fd);
                        cpuset_written = true;
                    }
                }
            }
            if (!cpuset_written) {
                int fd = open("/dev/cpuset/AppOpt/tasks", O_WRONLY | O_APPEND);
                if (fd >= 0) {
                    dprintf(fd, "%d\n", ti->tid);
                    close(fd);
                }
            }
        }
    }
    return applied;
}

static void update_cache(ProcCache* cache, const AppConfig* cfg, int* affinity_counter) {
    bool need_reload = false;
    struct sysinfo info;
    time_t now = time(NULL);

    unsigned long uptime = 0;
    struct timespec ts;
    if (clock_gettime(CLOCK_BOOTTIME, &ts) == 0) {
        uptime = (unsigned long)ts.tv_sec;
    } else {
        char stat_buf[1024];
        if (read_file(AT_FDCWD, "/proc/uptime", stat_buf, sizeof(stat_buf))) {
            uptime = strtoul(stat_buf, NULL, 10);
        }
    }

    if (sysinfo(&info) != 0) {
        need_reload = true;
    } else {
        int current_proc_count = info.procs;
        if (current_proc_count > cache->last_proc_count + 5) {
            need_reload = true;
        } else if (current_proc_count > cache->last_proc_count) {
            *affinity_counter = 0;
        }
        cache->last_proc_count = current_proc_count;
    }

    if (cache->procs != NULL && !need_reload) {
        long ticks_per_sec = sysconf(_SC_CLK_TCK);
        for (size_t i = 0; i < cache->num_procs; i++) {
            ProcEntryCache* entry;
            HASH_FIND_INT(cache->proc_cache, &cache->procs[i].pid, entry);
            if (entry && entry->start_time_valid) {
                time_t runtime = (uptime * ticks_per_sec - entry->start_time) / ticks_per_sec;
                if (runtime >= 0 && runtime < 300) {
                    if (now - entry->last_checked >= 5) {
                        if (kill(cache->procs[i].pid, 0) != 0) {
                            need_reload = true;
                            break;
                        }
                        entry->last_checked = now;
                    }
                    continue;
                }
            }
            if (kill(cache->procs[i].pid, 0) != 0) {
                need_reload = true;
                break;
            }
            if (entry) entry->last_checked = now;
        }
    }

    if (need_reload) {
        ProcCache* new_cache = update_proc_cache(cache, cfg);
        if (new_cache != cache) {
            return;
        }
        cache->last_update = now;
        *affinity_counter = 0;
    }
    cleanup_proc_cache(cache);
}

// 屏幕状态检查
static bool is_screen_on(void) {
    const char* backlight_path = "/sys/class/backlight/panel0-backlight/brightness";
    int fd = open(backlight_path, O_RDONLY);
    if (fd >= 0) {
        char buf[32] = {0};
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0) {
            long value = strtol(buf, NULL, 10);
            return value > 0;
        }
        return true;
    }

    FILE* fp = popen("dumpsys deviceidle get screen 2>/dev/null", "r");
    if (fp) {
        char buf[32] = {0};
        size_t n = fread(buf, 1, sizeof(buf) - 1, fp);
        buf[n] = '\0';
        pclose(fp);
        return (strstr(buf, "false") == NULL);
    }

    return true;
}

// 清理资源
static void cleanup(AppConfig* config, ProcCache* cache) {
    flush_log_buffer();
    if (log_fp) {
        if (fclose(log_fp) != 0) {
            fprintf(stderr, "Failed to close log file %s: %s\n", log_file_path, strerror(errno));
        }
        log_fp = NULL;
    }

    for (size_t i = 0; i < cache->num_procs; i++) {
        free(cache->procs[i].threads);
        free(cache->procs[i].thread_rules);
    }
    free(cache->procs);
    cleanup_proc_cache(cache);

    free(config->rules);
    free(config->wildcard_rules);
    for (size_t i = 0; i < config->num_pkgs; i++) free(config->pkgs[i]);
    free(config->pkgs);
    PackageEntry* entry, *tmp;
    HASH_ITER(hh, config->pkg_table, entry, tmp) {
        HASH_DEL(config->pkg_table, entry);
        free(entry);
    }
    
    CpuSetCache* cpu_set_entry, *cpu_set_tmp;
    HASH_ITER(hh, cpu_set_cache, cpu_set_entry, cpu_set_tmp) {
        HASH_DEL(cpu_set_cache, cpu_set_entry);
        free(cpu_set_entry->value);
        free(cpu_set_entry);
    }
}

static void print_help(const char* prog_name) {
    printf("Usage: %s [OPTIONS]\n", prog_name);
    printf("\nOptions:\n");
    printf("  -c <config_file>        Specify the configuration file path\n");
    printf("                          Default: %s\n", DEFAULT_CONFIG_FILE);
    printf("  -s <interval>           Set the sleep interval in seconds (integer >= 1)\n");
    printf("                          Default: 3 seconds\n");
    printf("  --log=<log_file>        Specify the log file path\n");
    printf("                          Default: Derived from config file path (e.g., affinity_manager.log)\n");
    printf("  --debug=<true|false>    Enable or disable debug logging\n");
    printf("                          Default: false\n");
    printf("  --minimal-log           Enable minimal logging mode (reduces log verbosity)\n");
    printf("                          Default: disabled\n");
    printf("  -h, --help              Display this help message and exit\n");
    printf("\nExamples:\n");
    printf("  %s -c /data/applist.conf -s 5\n", prog_name);
    printf("  %s --log=/var/log/affinity.log --debug=true\n", prog_name);
    printf("  %s --minimal-log -s 2\n", prog_name);
    printf("\nDescription:\n");
    printf("  This program manages CPU affinity for processes and threads based on\n");
    printf("  a configuration file. It monitors processes, applies CPU affinity rules,\n");
    printf("  and logs operations when enabled.\n");
}

// 主函数
int main(int argc, char* argv[]) {
    const char* config_file = DEFAULT_CONFIG_FILE;
    int sleep_interval = 3;

    set_default_log_path(config_file);

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            print_help(argv[0]);
            return 0;
        } else if (strcmp(argv[i], "-c") == 0 && i + 1 < argc) {
            config_file = argv[++i];
            if (access(config_file, F_OK) != 0 && errno != ENOENT) {
                fprintf(stderr, "Error: Config file %s is not accessible: %s\n", config_file, strerror(errno));
                return 1;
            }
            set_default_log_path(config_file);
        } else if (strncmp(argv[i], "--log=", 6) == 0) {
            const char* log_path = argv[i] + 6;
            if (strlen(log_path) == 0) {
                fprintf(stderr, "Error: Log file path cannot be empty\n");
                return 1;
            }
            if (strlen(log_path) >= sizeof(log_file_path)) {
                fprintf(stderr, "Error: Log file path too long (max %zu characters)\n", sizeof(log_file_path) - 1);
                return 1;
            }
            strncpy(log_file_path, log_path, sizeof(log_file_path) - 1);
            log_file_path[sizeof(log_file_path) - 1] = '\0';
        } else if (strncmp(argv[i], "--debug=", 8) == 0) {
            const char* debug_val = argv[i] + 8;
            if (strcmp(debug_val, "true") == 0) {
                log_enabled = true;
                debug_set_from_args = true;
            } else if (strcmp(debug_val, "false") == 0) {
                log_enabled = false;
                debug_set_from_args = true;
            } else {
                fprintf(stderr, "Error: Invalid --debug value: %s (must be 'true' or 'false')\n", debug_val);
                return 1;
            }
        } else if (strcmp(argv[i], "--minimal-log") == 0) {
            log_minimal = true;
        } else if (strcmp(argv[i], "-s") == 0 && i + 1 < argc) {
            char* endptr;
            long val = strtol(argv[++i], &endptr, 10);
            if (endptr == argv[i] || *endptr != '\0' || val < 1) {
                fprintf(stderr, "Error: Invalid interval value: %s (must be an integer >= 1)\n", argv[i]);
                return 1;
            }
            sleep_interval = (int)val;
            LOG_I("Sleep interval set to %d seconds", sleep_interval);
        } else {
            fprintf(stderr, "Error: Unknown or invalid argument: %s\n", argv[i]);
            print_help(argv[0]);
            return 1;
        }
    }

    AppConfig config = { .topo = init_cpu_topo(), .mtime = 0, .pkg_table = NULL };
    strncpy(config.cpuset_base, BASE_CPUSET, sizeof(config.cpuset_base) - 1);
    config.cpuset_base[sizeof(config.cpuset_base) - 1] = '\0';
    ProcCache cache = { .proc_cache = NULL, .last_proc_count = 0 };
    time_t last_screen_check = 0;
    bool screen_state_cached = true;
    bool last_logged_screen_state = true;
    int config_counter = 3;
    int affinity_counter = 0;
    time_t last_cleanup = 0;

    const char* backlight_path = "/sys/class/backlight/panel0-backlight/brightness";
    bool backlight_exists = (access(backlight_path, F_OK) == 0);
    int screen_check_interval = backlight_exists ? 5 : 30;

    if (debug_set_from_args) {
        LOG_I("Debug mode set from command line: %s", log_enabled ? "true" : "false");
    }
    if (log_minimal) {
        LOG_I("Minimal log mode enabled");
    }
    load_config(&config, config_file);

    for (;;) {
        time_t now = time(NULL);

        if (now - last_screen_check >= screen_check_interval) {
            screen_state_cached = is_screen_on();
            last_screen_check = now;
            if (screen_state_cached != last_logged_screen_state) {
                LOG_I("Screen state changed to: %s", screen_state_cached ? "ON" : "OFF");
                last_logged_screen_state = screen_state_cached;
                if (screen_state_cached) {
                    if (load_config(&config, config_file)) {
                        cache.last_proc_count = 0;
                        update_proc_cache(&cache, &config);
                        LOG_I("Config reloaded after screen turned ON");
                    }
                }
            }
        }

        if (!screen_state_cached) {
            sleep(10);
            cache.last_proc_count = 0;
            continue;
        }

        config_counter++;
        if (config_counter > 3) {
            if (load_config(&config, config_file)) {
                cache.last_proc_count = 0;
                update_proc_cache(&cache, &config);
                LOG_I("Config reloaded periodically");
            }
            config_counter = 0;
        }

        update_cache(&cache, &config, &affinity_counter);

        affinity_counter++;
        if (affinity_counter > 1) {
            bool applied = false;
            for (size_t i = 0; i < cache.num_procs; i++) {
                applied |= apply_affinity(&cache.procs[i], &config.topo, &cache);
            }
            affinity_counter = 0;
        }

        if (now - last_cleanup >= 300) {
            cleanup_proc_cache(&cache);
        }
        
        flush_log_buffer();
        sleep(sleep_interval);
    }

    cleanup(&config, &cache);
    LOG_I("Program exiting normally");
    return 0;
}
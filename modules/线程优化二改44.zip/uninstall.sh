uninstall_module(){
while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 3m
done
if [ -n "$(getprop persist.sys.oiface.enable)" ]; then
	prop_value=$(grep '^persist\.sys\.oiface\.enable=' /system_ext/etc/build.prop | cut -d= -f2)
    if [ -n "$prop_value" ]; then
		 resetprop persist.sys.oiface.enable "$prop_value"
	else
		resetprop persist.sys.oiface.enable 1
		start oiface >/dev/null 2>&1
	fi
fi
until $(dumpsys deviceidle get screen) ;do
	sleep 2m
done
pm enable com.xiaomi.joyose >/dev/null 2>&1
}


( uninstall_module &)

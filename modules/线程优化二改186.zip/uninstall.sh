uninstall_module(){
while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 3m
done
if [[ "$(pgrep -f oiface)" = "" ]];then
	if [ -n "$(getprop persist.sys.oiface.enable)" ]; then
		prop_value=$(grep -E '^persist\.sys\.oiface\.enable=' /system_ext/etc/build.prop | cut -d= -f2)
  	  if [ -n "$prop_value" ]; then
		 	resetprop persist.sys.oiface.enable "$prop_value"
		else
			resetprop persist.sys.oiface.enable 2
		fi
	fi
fi
until $(dumpsys deviceidle get screen) ;do
	sleep 2m
done
pm enable com.xiaomi.joyose >/dev/null 2>&1
pm enable com.xiaomi.joyose/.smartop.SmartOpService >/dev/null 2>&1
am broadcast --user 0 -a update_profile com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
}


( uninstall_module &)

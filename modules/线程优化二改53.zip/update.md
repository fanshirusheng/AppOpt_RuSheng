### 感谢[@coolapk SutoLiu 大佬](https://www.coolapk1s.com/u/SutoLiu)
### 原模块地址: https://gitee.com/sutoliu/AppOpt
#### 二改模块日志
> 0.1
- 更改`module_id`为`AppOpt_Aloazny`。
- 更改配置文件`applist.conf`为`applist.prop`，**舒服我自己**用MT管理器查看配置文件有高亮。
- 更改`uninstall`的`setprop`为`resetprop`，避免卸载模块可能发生的开机阻塞。
- 添加一个shell脚本更正部分用户乱写的`applist.conf(applist.prop)`。
- 添加`日志记录`，去掉`dumpsys`获取屏幕状态。
> 0.2
- 加回`dumpsys`作为备选，获取屏幕状态。
- 添加`scene`核心分配名单检测(目前无法检测开关，因为我太菜)和其他核心模块检测。
> 0.3
- 在配置文件`applist.prop`中修改`Debug_AppOpt=false`能提升一些性能。
- 因为我不打游戏，所以如果发现有的线程生效不及时的话，可以选择自己编译一下源码，把`PROC_CACHE_TIME 30`里面的`30`改回`10`或者`15`，提升响应速度。
- 添加更多冲突模块检测。
> 0.4
- 添加`action.sh`按钮，能够输出模块的一些信息。
> 0.5
- copy了@coolapk 10007代码，添加magisk或者非ksu识别。
> 0.6
- 把核心信息写入配置文件`applist.prop`。
> 0.7
- 修改`service.sh`语法，避免有的设备无法识别？
- 修复开机不自动执行。
> 0.8
- 增加支付宝(`com.eg.android.AlipayGphone`) 番茄小说(`com.dragon.read`) iceraven(`io.github.forkmaintainers.iceraven`)配置。
- 修复`action.sh`识别冲突模块的一个逻辑错误。
> 0.9
- 核心信息添加`sort -rn`排序后显示。
> 1.0
- 添加一个8+的`surfaceflinger`和`vendor.qti.hardware.display.composer-service`配置服务。
> 1.1
- 添加一个命令参数`-f 配置文件路径` `--log=日志文件路径` `--debug=填写true或者false`，如果不指定，那么就是模块默认配置。
- 英文说明`Usage: %s [-f config_file] [--log=log_file] [--debug=(true|false)]`
- 例如下面这个命令就是，指定配置文件`/data/adb/modules/AppOpt_Aloazny/applist.prop`，日志文件`/data/adb/modules/AppOpt_Aloazny/affinity_manager.log`，`关闭调试日志`。
```shell
AppOpt -f /data/adb/modules/AppOpt_Aloazny/applist.prop --log=/data/adb/modules/AppOpt_Aloazny/affinity_manager.log --debug=false
```

> 1.2
- 修复一个action检测`AppOpt`占用为0%和未运行的情况未区分，导致显示不准确的bug。
> 1.3
- 在配置文件中未使用`=`的进程或者中文会被加上`#`注释。
- 酷安加上一个`com.coolapk.market{OkHttp Dispatch}=4-6`的配置，你也可以改成`com.coolapk.market{OkHttp*}=4-6`。
> 1.4
- 修复非`magisk`，**Ksu/Apatch** 刷入action报错问题。
> 1.5
- 添加抖音(`com.ss.android.ugc.aweme`)配置参考。
- 添加椒盐笔记(`com.moriafly.note`)。
- 更新`Aloazny.sh`脚本(`action.sh`)，模块`action.sh`也能在原模块(@SutoLiu)中使用。
- 修正`service.sh`中把`/data/adb/modules/AppOpt`打错成`/data/adb/module/AppOpt`。
- 修改架构安装。
> 1.6
- 新增对**配置文件**存在重复配置进程的提醒。
> 1.7
- **Scene** versioncode大于`820250402`不再检测Scene冲突。
> 1.8
- 配置文件监控改成`inotify`监控，理论上能降低一些Cpu占用和资源消耗。
- 编译时从`-O3`改为`-O2`，理论上内存占用没那么高了。
> 1.9
- 还是换回`O3`了，`-O2`省的那点内存还不如不省。
- 添加几个**哔哩哔哩**的附加进程配置参考。
- 修正`Aloazny.sh`在刷入的时候把自己给扬了。
> 2.0
- arm64的架构改成用`aarch64-linux-android32-clang`(Android12)编译了。
- 修正一个Apatch错误。
> 2.1
- 添加调整`applist.prop`部分配置。
- 替换`@coolapk 10007`大佬的`update-binary`(感谢！)，用于兼容**20400**低版本的Magisk。
> 2.2
- 增加`/proc`缓存，避免反复读取`/proc`，减少部分性能开销。
- 添加`uthash.h`，用于读取配置包名，规则数量到`800+`时，差异明显，`100+`两者差不多。
- 添加MT文件管理器(`bin.mt.plus`)一条新的规则。
- 有了上面的优化，我把`PROC_CACHE_TIME`从`30`该到了`15`，兼容玩游戏的同学，原`SutoLiu`大佬的设定是`10`，但是运行起来CPU占用太高(2%左右)，现在优化好了改成`10`或者`15`运行都能在`0.8%`以下。
> 2.3
- 尝试适配天机不存在`/sys/class/backlight`目录，改为30秒用`dumpsys`检测一次屏幕状态。
> 2.4
- 添加对`CuDaemon`和`uperf`调度的运行检测。
- 修复对**亮屏逻辑的一个检测**。
> 2.5
- 修复`Aloazny.sh`对配置检查报错的bug。
> 2.6
- 修改**错误日志**输出限制为10行，剩下会在错误日志文件。
- 添加`CPU核心范围`检测。
> 2.7
- Scene根本就没兼容，加回Scene检测。
- 修复`applist.prop`把`Twitter`复制粘贴成`coolapk`的一个错误线程。
> 2.8
- 添加Joiplay(`cyou.joiplay.joiplay`)配置。
- 修复**inotify**的一个息屏bug，息屏后亮起，即刻修改配置文件，不会生效。
> 2.9
- 修正`applist.prop`对webview和Joiplay的部分核心配置，偏向更流畅。
> 3.0
- 抄了`Scene`的作业，把`Scene`的游戏核心分配置(仅配置)，改了改，加到了上面，效果可能不好。
- 添加KB视频工厂(`com.idaodan.video.factory`)的核心分配，空闲小核，减少卡顿。
- 修改`com.google.android.webview`的`Compositor`为核心6，避免在玩Joiplay时，7负载太高，有点卡顿。
> 3.1
- 同步`SutoLiu`的`1.0.2`版本，默认不暂停`oiface`。
- 更改卸载脚本`uninstall.sh`。
- 退回`Aloazny.sh`的核心显示。
> 3.2
- 修改`Job.worker`为`Job.worker*`。
> 3.3
- 机械地检测了了`A-soul`模块可能会冲突的包名，自行点击Action检测。
> 3.4
- 添加winlator(`com.winlator`)的核心配置(其实这个主要还是看GPU)。
> 3.5
- 添加一项配置文件`applist.prop`移除多行，**只保留一行空行**。
- 云适配了一些游戏。
> 3.6
- 云适配了`CF`。
> 3.7
- 添加机械性适配`6+2` `3+4+1` `4+4` CPU核心配置的适配，创建`/data/adb/modules/AppOpt_Aloazny/modtify_config`空文件，就会修改配置。
- 创建`/data/adb/modules/AppOpt_Aloazny/update_config`空文件，就会使用模块的配置，而不是读取上一次配置。
> 3.8
- 修复刷入后不修改`/data/adb/modules_update/AppOpt_Aloazny/applist.prop`的问题。
- 修改机械性适配地部分描述。
> 3.9
- 改成`aarch64-linux-android23-clang`编译，和Magisk最低支持的版本同步。
> 4.0
- 添加两个`BILIBILI`线程`IJK`和`Thread-*`。
> 4.1
- 调整`surfaceflinger`线程匹配。
> 4.2
- 更改一个`4+4`配置，新增`2+3+2+1`机械性配置修改。
> 4.3
- 修复`4+4`把`*}`替换成`=`的错误。
- MTK屏蔽`/system/vendor/etc/power_app_cfg.xml`文件。
- 修复`核心配置`更改的一个bug。
> 4.4
- 添加对`system_server`的修改。
- 修复`applist.prop`中新的线程把`tv.danmaku.bili`打成`tv.danmaku.bilibilihd`。
- 调整`6+2`和`2+3+2+1`的机械性配置。
> 4.5
- 添加一个MIUI相机(`com.android.camera`)的线程。
- 修改酷安、MIUI桌面线程。
> 4.6
- 添加金铲铲(`com.tencent.jkchess`)。
- 添加适配应用列表，可以在`适配应用.md`查看。
> 4.7
- 新增优先级匹配，精确匹配优先级高于通配符匹配，如下。
```C++
exp.com{Thread-3}=7
exp.com{Thread-[1-2]3}=6
exp.com{Thread-*}=4-6
```
- 模块会优先绑定`exp.com{Thread-3}`到CPU7，`exp.com{Thread-[1-2]3}`也就是`Thread-13/Thread-23`会被绑定到CPU6，剩下的`Thread-*`会给到CPU4-6。
> 4.8
- 添加日常应用适配，小红书(`com.xingin.xhs`)，高德地图(`com.autonavi.minimap`)，百度地图(`com.baidu.BaiduMap`)，闲鱼(`com.taobao.idlefish`)，淘宝(`com.taobao.taobao`)，拼多多(`com.xunmeng.pinduoduo`)。
> 4.9
- 添加饿了么(`me.ele`)，美团(`com.sankuai.meituan`)。
> 5.0
- 添加通配符匹配进程，通配符会稍微增加性能消耗，推荐优先使用精确匹配，自行斟酌。

```
#例如
com.sankuai.meituan:sandboxed_process0=4-7
com.sankuai.meituan:sandboxed_process14=4-7
com.sankuai.meituan:sandboxed_process23=4-7
com.sankuai.meituan:sandboxed_process22=4-7
com.sankuai.meituan:sandboxed_process21=4-7
#可以写成
com.sankuai.meituan:sandboxed_process*=4-7
#游戏渠道服
#荒野行动
com.netease.hyxd.mi{Thread-*}=7
com.netease.hyxd.aligames{Thread-*}=7
#可以写成
#荒野行动
com.netease.hyxd.*{Thread-*}=7
```

- 适配游戏荒野行动(`com.netease.hyxd.mi`, `com.netease.hyxd.aligames`, `com.netease.hyxd.nearme.gamecenter`, `com.netease.hyxd.wyzymnqsd_cps`)，三角洲行动(`com.tencent.tmgp.dfm`)，部落冲突(`com.tencent.tmgp.supercell.clashofclans`)
> 5.1
- 调整`applist.prop`部分应用线程。
- 加回`Scene`版本判定(这么久了，应该改好了吧)。
> 5.2
- 调整`6+2`配置，避免`sdm710`都分配给大核，部分场景卡顿。
- 修复一个**配置文件因为错误规则**卡死的bug。
- 添加kazumi(`com.predidit.kazumi`)和Animeko(`me.him188.ani`)适配。
> 5.3
- 添加SD Maid(`eu.thedarken.sdm`,`eu.darken.sdmse`)，Telegram(`org.telegram.messenger`,`org.telegram.messenger.web`,`org.telegram.messenger.beta`)适配。


### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)
- [1.3.5版本 密码: 111](https://aloazny.lanzouo.com/b00jeipeeb)
- [实时模式 密码:111](https://aloazny.lanzouo.com/b00jeku6cd)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)
- [点击查看适配应用列表](https://aloazny.github.io/AppOpt_Aloazny/#%E9%80%82%E9%85%8D%E5%88%97%E8%A1%A8)
- **Flags文件**创建或者删除后，需要**重新刷模块压缩包入生效**。
- 例如我下载了`线程优化二改211.zip`刷入后。
- 想要实现(取消)增加更新，那么我在创建(删除)`/data/adb/modules/AppOpt_Aloazny/keep_custom_rule`后，**需要再次重新刷模块压缩包(`线程优化二改211.zip`)入生效**。

### 更新日志
> 21.1
- 添加Nullgram (`top.qwq2333.nullgram`)，Cherrygram (`uz.unnarsx.cherrygram`)适配。
- 限制Tg第三方客户端，Neko/Nag一个异常负载的线程`decodeQueueorg.`。
- 调整**MIUI桌面线程**。
- 调整`Aloazny.sh`脚本。
> 21.0
- 添加Tubular (`org.polymorphicshade.tubular`)，Google play商店 (`com.android.vending`)，Aurora (`com.aurora.store`)，Fdroid (`org.fdroid.fdroid`)，Droidfy (`com.looker.droidify`)适配。
- 优化内存占用。
> 20.9
- 优化内存占用。
> 20.8
- 添加`persist.sys.miui_animator_sched.enabled=false`值，**用于禁用MIUI自带线程绑定**。
- 调整网易云/`lspd`线程。
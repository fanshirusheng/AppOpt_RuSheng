[[ -f /data/adb/magisk/util_functions.sh ]] && . /data/adb/magisk/util_functions.sh
[[ ! -d "${MODPATH}" ]] && MODPATH="${0%/*}"
export PATH="${PATH}:/data/adb/magisk:/data/adb/ksu/bin:/data/adb/ap/bin"
export TZ="Asia/Shanghai"
awk --help >/dev/null 2>&1 || alias awk="busybox awk"
[ "$(which -a busybox)" != "" ] && alias sed="busybox sed"
[ "$(which -a busybox)" != "" ] && alias diff="busybox diff"
ui_print "" >/dev/null 2>&1 || alias ui_print="echo"
grep_prop >/dev/null 2>&1 || grep_prop() { local REGEX="s/^$1=//p"; shift ;local FILES="${@}"; [ -z "$FILES" ] && FILES='/system/build.prop'; cat "${FILES}" 2>/dev/null | dos2unix | sed -n "${REGEX}" | head -n 1; }

function cpu_name_get(){
local cpuname="$(getprop ro.soc.model)"
[ "${cpuname}" = "" ] && cpuname="$(getprop | sed -E "/ro\.(system|vendor|product|odm|system_ext).*\.soc_model/!d;s/.*\]://g;s/\].*//g;s/.*\[//g" | head -n 1)"
[ "${cpuname}" = "" ] && cpuname="$(getprop ro.board.platform)"
[ "${cpuname}" = "" ] && cpuname="$(getprop | sed -E "/ro\.(system|vendor|product|odm|system_ext).*\.platform/!d;s/.*\]://g;s/\].*//g;s/.*\[//g" | head -n 1)"
[ "${cpuname}" != "" ] && echo "${cpuname}" || echo "未知"
}

function get_cpu_core_Info(){
local core_architect="$(wc -w /sys/devices/system/cpu/cpufreq/*/related_cpus | sed -E 's/^[[:space:]]+//g;s/(^[0-9]+) total/共\1个CPU核心/;s/(^[0-9]+)([[:space:]].*)/\1/g' | sed -E ':a;$!N;s/([0-9])\n/\1\+/g;ta;s/\+([^0-9])/ \1/g;s/^([0-9])/核心配置为: \1/g')"
ui_print "**************************************************"
ui_print "- CPU代号: $(cpu_name_get)"
ui_print "- 核心信息:"
ui_print "- ${core_architect} "
for i in /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq; do
freq=$(cat "$i")
core_relate_Info="$(cat "${i%/*}/related_cpus" | tr '[[:space:]]' '\n')"
if [ $(echo "${core_relate_Info}" | wc -l) = "1" ];then
	core="${core_relate_Info}"
else
	core_start="$(echo "${core_relate_Info}" | head -n 1)"
	core_end="$(echo "${core_relate_Info}" | tail -n 1)"
	core="${core_start}-${core_end}"
fi
ui_print "Core (${core}) ${i##*/}: $((freq / 1000)) MHz"
done | sort -n | uniq -c #| sort -rn  | sed -E "s/^[[:space:]]+//g"
ui_print "**************************************************"
ui_print ""
}

function check_program_Running(){
local check_program=`pgrep -lf "AppOpt|CuDaemon|uperf" | sed -E 's/^(.*)/- \1/g' `
local check_program_count=`echo "${check_program}" | wc -l`
if [ "${check_program_count}" -gt "1" ];then
echo "
- 注意
- 可能有其他相同程序影响模块运行
${check_program}
"
fi
}

function get_other_module(){
for i in /data/adb/*modules/asoul_affinity_opt /data/adb/*modules/AppOpt_Aloazny /data/adb/*modules/AppOpt /data/adb/*modules/thread_opt
do
	description_file="${i}/module.prop"
	if [[ -f "${description_file}" ]] && [ ! -f "${i}/disable" ];then
		if [[ -f "${TMPDIR}/module.prop" ]];then
			module_own_id=$(grep_prop id "${TMPDIR}/module.prop" )
		else
			module_own_id=`readlink -f "${0%/*}"`
			module_own_id="${module_own_id##*/}"
		fi
	module_id=$(grep_prop id "${description_file}" )
	[ "${module_own_id}" = "${module_id}" ] && continue
	module_name=$(grep_prop name "${description_file}" )
	module_author=$(grep_prop author "${description_file}" )
	module_description=$(grep_prop description "${description_file}" )
	ui_print "
- 名称:${module_name}
- 作者:${module_author}
- 描述:${module_description}
- 路径:${i}"
	fi
done
}


function write_core_information(){
local module_config="${1}"
[[ ! -f "${module_config}" ]] && return 
local core_content="$(echo "$(get_cpu_core_Info)" | sed -E 's/^(.*)/#\1/g' )"
sed -E -i '/^\#[[:space:]]您的核心信息/,/^\#[[:space:]]END/d' "${module_config}"
local module_config_content="$(cat "${module_config}")"
cat << Aloazny > "${module_config}"
# 您的核心信息
${core_content}
# END
${module_config_content}
Aloazny
}

function write_cpu_information_to_module_description(){
local file="${MODPATH}/module.prop"
local Device_Name update_sate modtify_sate dexota_sate game_config_sate dynamic_update_sate
[ ! -f "$file" ] && return
local bin_file="${MODPATH}/AppOpt"
[ -f "${bin_file}" ] && chmod 755 "${bin_file}" || return
local architect=$(wc -w /sys/devices/system/cpu/cpufreq/*/related_cpus | sed -E 's/^[[:space:]]+//g;/total/d;s/(^[0-9]+)([[:space:]].*)/\1/g' | sed ':a;$!N;s/\n/+/g;ta;s/+$//g')
[ "${architect}" = "" ] && architect="未知"
if test "`getprop ro.vendor.oplus.market.name`" != "" ;then
	Device_Name="$(getprop ro.vendor.oplus.market.name)"
elif test "`getprop ro.product.marketname`" != "" ;then
	Device_Name="$(getprop ro.product.marketname)"
else
	Device_Name="$(getprop ro.product.model)"
fi
[ "${Device_Name}" = "" ] && Device_Name="未知"
[ -f "${MODPATH}/update_config" ] && update_sate="[ 始终覆盖配置文件: ✅ ]" || update_sate="[ 始终覆盖配置文件: ❎️ ]"
[[ -f "${MODPATH}/modtify_config" || "${architect}" = "4+3+1" ]] && modtify_sate="[ 机械性适配: ✅ ]" || modtify_sate="[ 机械性适配: ❎️ ]"
[[ -f "${MODPATH}/dexota_modtify" && "$(grep 'pm.dexopt.cmdline=' "${MODPATH}/system.prop" 2>/dev/null )" != "" ]] && dexota_sate="[ 优化dex2ota: ✅ ]" || dexota_sate="[ 优化dex2ota: ❎️ ]"
[ -f "${MODPATH}/delete_game_config" ] && game_config_sate="[ 保留游戏配置: ❎️ ]" || game_config_sate="[ 保留游戏配置: ✅ ]"
[ -f "${MODPATH}/keep_custom_rule" ] && dynamic_update_sate="[ 增量更新: ✅ ]" || dynamic_update_sate="[ 增量更新: ❎️ ]"
local Appopt_version=`${bin_file} -v`
local word="设备: ${Device_Name}，当前处理器: [ $(cpu_name_get) ] (${architect})，模块配置情况: ${update_sate} ${modtify_sate} ${dexota_sate} ${game_config_sate} ${dynamic_update_sate}，一个支持自定义规则的安卓应用线程优化程序，基于Suto大佬的$Appopt_version二改。"
sed -i "/description=/d" "${file}"
echo -e "description=${word}" >> "${file}"
sed -i "/^[[:space:]]*$/d" "${file}"
}

#再次抄袭10007代码
#获取magisk类型
function get_magisk_lite(){
local until_function=/data/adb/magisk/util_functions.sh
local Apatch_version=${APATCH_VER_CODE}
local Ksu_version=${KSU_KERNEL_VER_CODE}
if [ "${Apatch_version}" != "" ];then
	echo "- 😥当前环境非Magisk……"
	echo "- 疑似Apatch◎${Apatch_version}……"
	return
elif [ "${Ksu_version}" != "" ];then
	echo "- 😥当前环境非Magisk……"
	echo "- 疑似kernelsu◎${Ksu_version}……"
	return
fi
if grep -q lite_modules $until_function >/dev/null 2>&1 ;then
	echo "- 🌙当前为: Magisk Lite◎$MAGISK_VER_CODE"
else
	if [ "${MAGISK_VER_CODE}" = "" ];then
		echo "- 🤔当前环境非Magisk/Ksu/Apatch……"
	else
case "${MAGISK_VER}" in
*alpha)
	echo "- ☀当前为: Magisk Alpha◎$MAGISK_VER_CODE"
;;
*delta)
	echo "- ☀当前为: Magisk Delta◎$MAGISK_VER_CODE"
;;
*kitsune)
	local magisk_type="${MAGISK_VER%-*}"
	if [[ -n $(echo "${magisk_type}" | grep -E '[0-9]{2}\.[0-9]') ]] ;then
		echo "- ☀当前为: Kitsune Mask◎$MAGISK_VER_CODE"
	else
		echo "- ☀当前为: Kitsune Mask(${magisk_type})◎$MAGISK_VER_CODE"
	fi
;;
*-*)
	local magisk_others="$(echo "${MAGISK_VER##*-}" | tr '[:lower:]' '[:upper:]')"
	echo "- ☀当前为: Magisk ${magisk_others}◎$MAGISK_VER_CODE"
;;
*)
	echo "- ☀当前为: Magisk Official◎$MAGISK_VER_CODE"
;;
esac
	fi
fi
}

function Move_platform_bin(){
local platform="${ABI}"
[ ! -f "${TMPDIR}/module.prop" ] && return
[ "${platform}" = "" ] && platform="$(getprop ro.product.cpu.abi)"
[ "${platform}" = "" ] && platform="$(grep_prop ro.product.cpu.abi)"
if [ "${platform}" = "" ] ;then
	ui_print "- 无法获取您的设备架构"
	abort >/dev/null 2>&1
else
	local bin_file_name="AppOpt"
	local bin_file="${MODPATH}/bin/${platform}/${bin_file_name}"
	local bin_Info="$(file "${bin_file}" | sed "s|${bin_file}:||g" | tr ',' '\n' | sed -E 's/^(.*)/-\1/g' )"
	ui_print ""
	ui_print "**************************************************"
	ui_print "- 架构: ${bin_file##*/bin/} "
	ui_print "- 构建信息: 
${bin_Info} "
	cp -rf "${bin_file}" "${MODPATH}/${bin_file_name}"
	rm -rf "${MODPATH}/bin"
	ui_print "**************************************************"
	ui_print ""
fi
}

function get_other_thread(){
[[ -f "${1}" ]] && ui_print "- 检查可能的冲突……" || return
#查找Scene线程配置文件
local Asoul_package="
Nekootan.kfkj
age.of.civilizations2.jakowski.lukasz
brownmonster.app.game.rushrally3
com.AlfaBravo.Combat
com.CarXTech.highWay
com.ChillyRoom.DungeonShooter
com.EtherGaming.PocketRogues
com.Flanne.MinutesTillDawn.roguelike.shooting.gp
com.GameCoaster.ProtectDungeon
com.HoYoverse.hkrpgoversea
com.LanPiaoPiao.PlantsVsZombiesRH
com.MOBGames.PoppyMobileChap1
com.ProjectMoon.LimbusCompany
com.RoamingStar.BlueArchive
com.ShinyShoe.MonsterTrain.mtap
com.Shooter.ModernWarfront
com.Shooter.ModernWarships
com.Sunborn.SnqxExilium
com.TechTreeGames.TheTower
com.YoStarEN.Arknights
com.YoStarEN.MahjongSoul
com.YoStarJP.MajSoul
com.YostarJP.BlueArchive
com.ZeroCastleGameStudio.StrikeBusterPrototype
com.ZeroCastleGameStudioINTL.StrikeBusterPrototype
com.actgames.bbee
com.activision.callofduty.shooter
com.activision.callofduty.warzone
com.albiononline
com.aligames.kuang.kybc
com.and.games505.Terraria
com.axlebolt.standoff2
com.bairimeng.dmmdzz
com.bandainamcoent.idolmaster_gakuen
com.bandainamcoent.imas_millionlive_theaterdays
com.bandainamcoent.sao
com.bandainamcoent.shinycolorsprism
com.bandainamcogames.dbzdokkanww
com.bf.sgs.hdexp.bd
com.bhvr.deadbydaylight
com.bilibili.azurlane
com.bilibili.deadcells.mobile
com.bilibili.fatego
com.bilibili.heaven
com.bilibili.priconne
com.bilibili.star.bili
com.bilibili.warmsnow
com.biligamekr.aggp
com.bingkolo.kleins.cn
com.blizzard.diablo.immortal
com.blizzard.wtcg.hearthstone
com.bscotch.crashlands2
com.bushiroad.d4dj
com.bushiroad.lovelive.schoolidolfestival2
com.chucklefish.stardewvalley
com.cnvcs.xiangqi
com.crunchyroll.princessconnectredive
com.denachina.g13002010
com.denchi.vtubestudio
com.dfjz.moba
com.dgames.g15002002
com.dragonli.projectsnow.lhm
com.dts.freefireth
com.ea.games.r3_row
com.epicgames.fortnite
com.fantablade.icey
com.gaijingames.wtm
com.gameloft.android.ANMP.GloftA9HM
com.garena.game.codm
com.garena.game.df
com.garena.game.kgtw
com.garena.game.nfsm
com.gbits.funnyfighter.android.overseas
com.gryphline.exastris.gp
com.guigugame.guigubahuang
com.guyou.deadstrike
com.h73.jhqyna
com.halo.windf.hero
com.heavenburnsred
com.hermes.j1game
com.hermes.mk
com.hermes.mk.asia
com.hg.lbw
com.hottapkgs.hotta
com.humo.yqqsqz.yw
com.hypergryph.arknights
com.hypergryph.exastris
com.idreamsky.klbqm
com.ignm.raspberrymash.jp
com.ilongyuan.implosion
com.infoldgames.infinitynikkien
com.jacksparrow.jpmajiang
com.jumpw.mobile300
com.komoe.kmumamusumegp
com.kurogame.aki
com.kurogame.haru
com.kurogame.mingchao
com.kurogame.wutheringwaves.global
com.leiting.wf
com.levelinfinite.sgameGlobal
com.lilithgames.hgame.cn
com.longe.allstarhmt
com.madfingergames.legends
com.miHoYo.GenshinImpact
com.miHoYo.Nap
com.miHoYo.Yuanshen
com.miHoYo.bh3
com.miHoYo.enterprise.NGHSoD
com.miHoYo.hkrpg
com.miHoYo.ys
com.miHoYo.zenless
com.minidragon.idlefantasy
com.miniworldgame.creata.vn
com.miraclegames.farlight84
com.mobile.legends
com.modx.daluandou
com.mojang.minecraftpe
com.nanostudios.games.twenty.minutes
com.neowizgames.game.browndust2
com.netease.AVALON
com.netease.EVE
com.netease.aceracer
com.netease.allstar
com.netease.dfjs
com.netease.dunkcd
com.netease.dwrg
com.netease.eve.en
com.netease.g93na
com.netease.h73hmt
com.netease.h75na
com.netease.hyxd
com.netease.idv
com.netease.jddsaef
com.netease.ko
com.netease.l22
com.netease.lglr
com.netease.ma84
com.netease.moba
com.netease.mrzh
com.netease.newspike
com.netease.nshm
com.netease.nshmhmt
com.netease.onmyoji
com.netease.party
com.netease.pes
com.netease.qrsj
com.netease.race
com.netease.sky
com.netease.soulofhunter
com.netease.tj
com.netease.tom
com.netease.wotb
com.netease.wyclx
com.netease.x19
com.netease.yhtj
com.netease.yyslscn
com.nexon.bluearchive
com.nexon.kartdrift
com.nexon.mdnf
com.nexon.mod
com.nianticlabs.monsterhunter
com.nianticproject.ingress
com.oninou.FAPI
com.papegames.infinitynikki
com.pinkcore.tkfm
com.playdigious.deadcells.mobile
com.playmini.miniworld
com.proxima.dfm
com.proximabeta.nikke
com.prpr.musedash
com.pubg
com.pubg.imobile
com.pubg.krmobile
com.pubg.newstate
com.pwrd.hotta.laohu
com.pwrd.huanta
com.pwrd.p5x
com.pwrd.persona5x.laohu
com.r2games.myhero.bilibili
com.rayark.implosion
com.rekoo.pubgm
com.riotgames.league.teamfighttactics
com.riotgames.league.wildrift
com.roblox.client
com.seasun.jx3
com.sega.ColorfulStage.en
com.sega.pjsekai
com.shangyoo.neon
com.shatteredpixel.shatteredpixeldungeon
com.shenlan.m.reverse1999
com.sofunny.Sausage
com.soulgamechst.majsoul
com.supercell.boombeach
com.sy.dldlhsdj
com.t2ksports.nba2k20and
com.tencent.KiHan
com.tencent.hhw
com.tencent.ig
com.tencent.jkchess
com.tencent.letsgo
com.tencent.lolm
com.tencent.mf.uam
com.tencent.nba2kx
com.tencent.nfsonline
com.tencent.tmgp.WePop
com.tencent.tmgp.bh3
com.tencent.tmgp.cf
com.tencent.tmgp.cod
com.tencent.tmgp.dfjs
com.tencent.tmgp.dfm
com.tencent.tmgp.dnf
com.tencent.tmgp.dwrg
com.tencent.tmgp.ffom
com.tencent.tmgp.gnyx
com.tencent.tmgp.kr.codm
com.tencent.tmgp.pubgmhd
com.tencent.tmgp.sgame
com.tencent.tmgp.speedmobile
com.tencent.tmgp.supercell.boombeach
com.tencent.tmgp.toaa
com.tencent.tmgp.wuxia
com.tencent.tmgp.yys.zqb
com.tencent.toaa
com.tgc.sky.android
com.the10tons.dysmantle
com.tipsworks.android.pascalswager
com.tipsworks.pascalswager
com.trampolinetales.lbal
com.tungsten.fcl
com.ubisoft.rainbowsixmobile.r6.fps.pvp.shooter
com.unity.mmd
com.valvesoftware.cswgsm
com.valvesoftware.source
com.vng.pubgmobile
com.xd.TLglobal
com.xd.dxlzz.taptap
com.xd.rotaeno.googleplay
com.xd.rotaeno.tapcn
com.xd.sce.promotion
com.xd.terraria
com.xd.xdt
com.xindong.torchlight
com.yinhan.hunter
com.yongshi.tenojo
com.zlongame.mhmnz
com.ztgame.bob
com.ztgame.yyzy
com.zy.wqmt.cn
gplay.punishing.grayraven
jp.YoStarJP.BlueArchive
jp.YoStarJP.MajSoul
jp.co.bandainamcoent.BNEI0242
jp.co.craftegg.band
jp.co.cygames.princessconnectredive
jp.konami.masterduel
jp.konami.pesam
me.mugzone.emiria
me.tigerhix.cytoid
minitech.miniworld
moe.low.arc
net.kdt.pojavlaunch
net.wargaming.wot.blitz
org.flos.phira
org.maxbytes.lfs
sh.ppy.osulazer
supercell.brawlstars
supercell.clashofclans
supercell.squad
tw.sonet.allbw
tw.sonet.princessconnect
xd.sce.promotion
"
local local_thread_config="$(grep -Ev '^[[:space:]]*$|#' "${1}" | sed 's/{.*//g;s/=.*//g;s/:.*//g' | sort -u)"
local package_config=`echo "${local_thread_config}" | tr '\n' '|' | sed -E 's/\|$//g;s/\?//g;s/\*//g' `
local scene_version=`dumpsys package com.omarea.vtools 2>/dev/null | grep -i "versioncode" | sed -E 's/.*=([0-9]{9,11}).*/\1/g'`
for i in /data/user/0/com.omarea.*/files/threads.json
do
	[ "${scene_version}" -ge "820250518" ] && ui_print "- Scene 版本: ${scene_version} " && break
	haspackage=$(grep -Eo "${package_config}" "${i}" 2>/dev/null | sed -E 's/^(.)/- \1/g')
	[[ "${haspackage}" != "" ]] && ui_print "- Scene核心分配找到和用户自定义重复的包名
- 请自行确认Scene的核心配置已关闭(Scene顶部→调节→Scene xx齿轮⚙️→核心分配)。
- 如果关闭了就不用管！如果关闭了就不用管！如果关闭了就不用管！
- 模块不能检测Scene的开关！模块不能检测Scene的开关！模块不能检测Scene的开关！
${haspackage}"
done
[ -d "/data/adb/modules/asoul_affinity_opt" -a ! -f "/data/adb/modules/asoul_affinity_opt/disable" ] && local Asoul_conflict=$(echo "${Asoul_package}" | grep -Eo "${package_config}" | sed -E 's/^(.)/- \1/g' )
[[ "${Asoul_conflict}" != "" ]] && ui_print "- 找到配置文件和A-soul模块冲突的包名，请不要重复配置
${Asoul_conflict}
"
#查找冲突模块
[[ "$(get_other_module)" != "" ]] && ui_print "
- 检测到可能冲突模块
- 确保不要重复配置应用$(get_other_module)"
#get_other_module
[ "${haspackage}" = "" -a "${Asoul_conflict}" = "" -a "$(get_other_module)" = "" -a "$(get_other_module)" = "" ] && ui_print "- 未找到对应模块冲突或者应用冲突……"
}

function get_app_cpu_Info(){
#检测代码来源于@coolapk 10007
[[ "${0##*/}" = "action.sh" ]] && ui_print "- 检测程序运行状况……" || return
local cpuinfo_show=`dumpsys cpuinfo | grep -Eo '[0-9]{1,3}(\.[0-9])?%[[:space:]]+[0-9]{1,6}\/AppOpt'`
local Check_cpuinfo="$(echo "${cpuinfo_show}" | sed -E 's|[[:space:]][0-9]{1,6}/AppOpt||g' )"
case "${Check_cpuinfo}" in
0.[0-9]%|0%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 正常……"
;;
[0-9]%|[0-9].[0-9]%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 占用过大！？
"
;;
[0-9][0-9]%|[0-9][0-9].[0-9]%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 异常占用！
- 建议反馈给开发者！
"
[ -f "${0%/*}/service.sh" ] && nohup "${0%/*}/service.sh" >/dev/null 2>&1
;;
[0-9][0-9][0-9]%|[0-9][0-9][0-9].[0-9]%)
ui_print "- ●AppOpt●
- ${cpuinfo_show}
- 核心爆炸了，哥们！
- 我给你重启了进程，3秒后再执行action(操作)查看吧……
"
[ -f "${0%/*}/service.sh" ] && nohup "${0%/*}/service.sh" >/dev/null 2>&1
;;
*)
if [ "$(pgrep -lf AppOpt | sed "/${0##*/}/d;/App_GET_Thread/d;/^[[:space:]]*$/d" )" != "" ];then
ui_print "- ●AppOpt●
- AppOpt进程正常运行……
- 命令行 `pgrep -lf AppOpt | sed "/${0##*/}/d;/App_GET_Thread/d;/^[[:space:]]*$/d"`
"
else
ui_print "- ●AppOpt●
- 未找到AppOpt进程……
- 尝试重启AppOpt……
"
[ -f "${0%/*}/service.sh" ] && nohup "${0%/*}/service.sh" >/dev/null 2>&1
[ "$(pgrep -lf AppOpt | sed "/${0##*/}/d;/App_GET_Thread/d;/^[[:space:]]*$/d" )" != "" ] && ui_print "- 重启完成……" || ui_print "- 重启失败……"
fi
;;
esac
}

#限制日志大小
function limit_log_file() {
	local logfile="${1}"
	local maxsize=$((1024 * 100))
	filesize="$(ls -l "${logfile}" | awk '{ print $5 }' | tr -cd '[0-9]' )"
	if test $filesize -gt $maxsize; then
		echo "[`date '+%F %T'`] [I] 日志达到上限，以清空日志。" > "${logfile}"
	fi
}

#查找错误日志
function show_error_log_content(){
local log_file="/data/adb/modules/AppOpt_Aloazny/affinity_manager.log"
[ ! -f "${log_file}" -o "${0%##*/}" = "action.sh" ] && return
limit_log_file "${log_file}"
local error="$(grep -v '\[I\]' "$log_file" | sed '/^[[:space:]]*$/d' | head -n 10)"
if [[ "${error}" != "" ]];then
ui_print "
- 有错误日志输出
- 点击magisk右上角保存
- 在/sdcard/Download(/storage/emulated/0/Download/)目录能找到错误日志。
${error}
"
local log_error_output_file="/storage/emulated/0/Download/AppOpt错误日志.log"
mkdir -p "${log_error_output_file%/*}"
cp -af "${log_file}" "$log_error_output_file"
[ -f "${module_config}" ] && echo -e "\n#配置文件$(cat "${module_config}" )\n#END" >> "$log_error_output_file"
fi
}

function fix_applist_conf(){
local target_file="${1}"
#local cpu_range=$(cat /sys/devices/system/cpu/present 2>/dev/null )
[[ ! -f "$target_file" ]] && return
sed -E -i '/^[[:space:]]*$/N;/\n$/d' "${target_file}"
sed -E -i 's/(=.*[0-9])([[:space:]]+#.*)/\1/g' "${target_file}"
sed -E -i 's/--/-/g' "${target_file}"
sed -E -i 's/(=)([^0-9]+)([0-9])/\1\3/g' "${target_file}"
sed -E -i 's/^(\}|\})/#\1/g' "${target_file}"
sed -E -i 's/[[:space:]]$//g' "${target_file}"
sed -E -i 's/^([^#a-zA-Z0-9.-]+)/#\1/g' "${target_file}"
sed -E -i 's/=([0-9]|[0-9]-?[0-9]?,[0-9]-?[0-9]?|[0-9]-[0-9])([^0-9]+)$/=\1/g' "${target_file}"
sed -E -i 's/(^[^#][^=]*$)/#\1/g' "${target_file}"
#grep -E "(=[0-9]{2,}|=[0-9]{2,}-[0-9]+|=[0-9]+-[0-9]{2,}|=[0-9]{2,}\,[0-9]?|=[0-9]?\,[0-9]{2,})" "${target_file}" | sed -E 's/(.*)=(.*)/核心配置貌似不对？内容:\1=\2/g;/^[[:space:]]*$/d'
#[ "${cpu_range}" != "" ] && grep -E "=[^${cpu_range}]|=[0-9]+\,[^${cpu_range}]$|=[0-9]+-[^${cpu_range}]$" "${target_file}" | sed -E '/#/d;/^[[:space:]]*$/d;/Debug_AppOpt=/d;s/(.*)=(.*)/不存在的核心 内容:\1=\2/g;/^[[:space:]]*$/d'
grep -Ev '^[[:space:]]*$|^#' "${target_file}" | sed -E 's/=([0-9].*)/=/g' | uniq -d | while read -r same
do
	ui_print "- 检测到重复行……"
	ui_print "- 进程名称: ${same} : `grep -n "${same}" "${target_file}" | sed -E 's|([0-9]{1,3})\:(.*)|\1行|g;s/\|$//g' |  tr '\n' ' ' `"
done | sort -u 
}

function core_architect_set(){
[ ! -f "${TMPDIR}/module.prop" ] && return
local file="${1}"
local flag_modtify="${2}"
[ ! -f "${file}" ] && return
local architect=$(wc -w /sys/devices/system/cpu/cpufreq/*/related_cpus | sed -E 's/^[[:space:]]+//g;/total/d;s/(^[0-9]+)([[:space:]].*)/\1/g' | sed ':a;$!N;s/\n/+/g;ta;s/+$//g')
if [ "${architect}" = "" ];then
	echo "- 核心信息无法获取？"
	return
else
[ ! -f "${flag_modtify}" -a -f "/data/adb/modules/AppOpt_Aloazny/applist.prop" ] && return
[  -f "${flag_modtify}" ] && touch "${MODPATH}/modtify_config"
echo "- 正在修改成: ${architect} 的核心配置……"
case "${architect}" in
4+3+1)
	echo "- 同核心配置，跳过配置……"
;;
3+4+1)
	echo "- 修改中……"
	sed -E -i -e 's/=4-([5|6|7])$/=3-\1/g' \
	-e 's/=0-[5|6]$/=0-5/g' \
	-e 's/=2-4$/=1-3/g' \
	-e 's/=0-3$/=0-2/g' \
	-e 's/=0-4$/=0-3/g' "${file}" && echo "- 完成……"
;;
6+2)
	echo "- 修改中……"
	sed -E -i -e 's/=4-[5|6|7]$/=4-7/g' \
	-e 's/=0-[5|6]$/=0-6/g' \
	-e 's/=[5|6]$/=6/g' \
	-e 's/=4$/=6/g' \
	-e 's/=7\,([0-9])$/=6-7/g' \
	-e 's/=0-3$/=0-5/g' "${file}" && echo "- 完成……"
;;
4+4)
	echo "- 修改中……"
	sed -E -i -e 's/=4-[5|6]$/=4-7/g' \
	-e 's/\*\}=6$/\*\}=4-6/g' "${file}" && echo "- 完成……"
;;
2+3+2+1)
	echo "- 修改中……"
	sed -E -i -e 's/=2-4$/=0-2/g' \
	-e 's/=6-7$/=7\,4/g' \
	-e 's/=[4|5]-6$/=2-4/g' \
	-e 's/=0-3$/=5-6/g' \
	-e 's/=2-3$/=0-1/g' \
	-e 's/=[5|6]$/=3/g' \
	-e 's/=4-5$/=5-6/g' \
	-e 's/=0-[5|6]$/=2-6/g' "${file}" && echo "- 完成……"
;;
*)
	echo "- 暂未适配……"
	echo "- 可能需要您手动调整成自己的核心配置(${architect})……"
;;
esac
fi
}

function mtk_remove_app_cfg(){
[ ! -f "${TMPDIR}/module.prop" ] && return
local file="/system/vendor/etc/power_app_cfg.xml"
if [ -f "${file}" ];then
	mkdir -p "$MODPATH/${file%/*}"
	cp -af "${file}" "$MODPATH/${file}" >/dev/null 2>&1
echo '<?xml version="1.0" encoding="UTF-8"?>
<WHITELIST>
</WHITELIST>' > "$MODPATH/${file}"
fi
}

function set_miui_booster() {
[ ! -f "${TMPDIR}/module.prop" ] || [ "$(getprop | grep -E 'miui|mi\.os')" = "" ] && return
local architect=$(wc -w /sys/devices/system/cpu/cpufreq/*/related_cpus | sed -E 's/^[[:space:]]+//g;/total/d;s/(^[0-9]+)([[:space:]].*)/\1/g' | sed ':a;$!N;s/\n/+/g;ta;s/+$//g')
case "${architect}" in
4+3+1|4+4) booster_cpus="6-7" ;;
3+4+1) booster_cpus="7,3-4" ;;
2+3+2+1) booster_cpus="5-7" ;;
6+2) booster_cpus="6-7" ;;
*) return ;;
esac
echo -e "#MIUI动画亲和值加速\npersist.sys.miui_animator_sched.bigcores=${booster_cpus}\npersist.sys.miui_animator_sched.big_prime_cores=${booster_cpus}" > "${MODPATH}/system.prop"
resetprop --delete persist.sys.miui_animator_sched.bigcores
resetprop --delete persist.sys.miui_animator_sched.big_prime_cores
resetprop --file "${MODPATH}/system.prop"
}

function add_dexota_prop(){
local system_prop_file="${MODPATH}/system.prop"
local flag_file="${1}"
[ ! -f "${TMPDIR}/module.prop" ] && return
[ -f "${flag_file}" ] && touch "${MODPATH}/${flag_file##*/}" || return
local architect=$(wc -w /sys/devices/system/cpu/cpufreq/*/related_cpus | sed -E 's/^[[:space:]]+//g;/total/d;s/(^[0-9]+)([[:space:]].*)/\1/g' | sed ':a;$!N;s/\n/+/g;ta;s/+$//g')
case "${architect}" in
4+3+1|4+4)
dexota_cpus="4,5,6,7"
;;
3+4+1)
dexota_cpus="3,4,5,6,7"
;;
2+3+2+1)
dexota_cpus="3,4,5,6,7"
;;
6+2)
dexota_cpus="3,4,5,6,7"
;;
*) return ;;
esac
thread_total="$(echo "${dexota_cpus}" | tr ',' '\n' | wc -l)"
#指定编译过滤器具体参考下面源码
#https://source.android.com/docs/core/runtime/configure?hl=zh-cn#compiler_filters
local dexota_mode="speed-profile"
local modtify_content="
#具体请参考Google官方文档
#https://source.android.com/docs/core/runtime/configure?hl=zh-cn
#https://source.android.com/docs/core/runtime/configure/art-service?hl=zh-cn
#场景编译
#everything比speed省内存
#但是everything体积太大而且不适合国内流氓软件
#speed比较均衡
#speed-profile只编译热点函数
#比speed稍微节省一点占用空间
pm.dexopt.ab-ota=${dexota_mode}
pm.dexopt.bg-dexopt=${dexota_mode}
pm.dexopt.boot-after-ota=${dexota_mode}
pm.dexopt.cmdline=${dexota_mode}
#下面这条Android14以上已经被删除弃用
pm.dexopt.install=${dexota_mode}

#启动安装时编译
dalvik.vm.bg-dex2oat-threads=${thread_total}
dalvik.vm.boot-dex2oat-threads=${thread_total}
dalvik.vm.dex2oat-threads=${thread_total}
dalvik.vm.dex2oat64.enabled=true
dalvik.vm.image-dex2oat-threads=${thread_total}
persist.dalvik.vm.dex2oat-threads=${thread_total}
ro.sys.fw.dex2oat_thread_count=${thread_total}
system_perf_init.bg-dex2oat-threads=${thread_total}
system_perf_init.boot-dex2oat-threads=${thread_total}
system_perf_init.dex2oat-threads=${thread_total}

#设置指定编译的CPU
dalvik.vm.background-dex2oat-cpu-set=${dexota_cpus}
dalvik.vm.boot-dex2oat-cpu-set=${dexota_cpus}
dalvik.vm.default-dex2oat-cpu-set=${dexota_cpus}
dalvik.vm.dex2oat-cpu-set=${dexota_cpus}
dalvik.vm.image-dex2oat-cpu-set=${dexota_cpus}
"
if [ -f "${system_prop_file}" ];then
	echo -e "\n#修改dex2ota内容\n${modtify_content}" >> "${system_prop_file}"
else
	echo -e "\n#修改dex2ota内容\n${modtify_content}" > "${system_prop_file}"
fi
	resetprop --file "${system_prop_file}"
	cp -af "${system_prop_file}" "/data/adb/modules/AppOpt_Aloazny/system.prop" 2>/dev/null
}

function update_bin_file(){
local original_bin_file="/data/adb/modules/AppOpt_Aloazny/AppOpt"
local update_bin_file="${original_bin_file/modules/modules_update}"
[ ! -f "${update_bin_file}" ] && return
if ! cmp "${original_bin_file}" "${update_bin_file}" >/dev/null 2>&1 ;then
	echo "- 升级 ${original_bin_file##*/} 文件……"
	cp -af "${update_bin_file}" "${original_bin_file}" >/dev/null 2>&1
	cp -af "${update_bin_file%/*}/service.sh" "${original_bin_file%/*}/service.sh"
	cp -af "${update_bin_file%/*}/cpu_control.sh" "${original_bin_file%/*}/cpu_control.sh" >/dev/null 2>&1
	cp -af "${update_bin_file%/*}/program_ctrl.sh" "${original_bin_file%/*}/program_ctrl.sh" >/dev/null 2>&1
	chmod a+x "${original_bin_file%/*}/service.sh"
	nohup "${original_bin_file%/*}/service.sh" >/dev/null 2>&1 && echo -e "- 已经重启AppOpt……\n- 理论上无需重启手机……"
fi
if ! cmp "${original_bin_file%/*}/cpu_control.sh" "${update_bin_file%/*}/cpu_control.sh" >/dev/null 2>&1 ;then
	cp -af "${update_bin_file%/*}/cpu_control.sh" "${original_bin_file%/*}/cpu_control.sh" >/dev/null 2>&1
	chmod a+x "${original_bin_file%/*}/cpu_control.sh"
	nohup "${original_bin_file%/*}/cpu_control.sh" >/dev/null 2>&1 &
fi
if ! cmp "${original_bin_file%/*}/program_ctrl.sh" "${update_bin_file%/*}/program_ctrl.sh" >/dev/null 2>&1 ;then
	cp -af "${update_bin_file%/*}/program_ctrl.sh" "${original_bin_file%/*}/program_ctrl.sh" >/dev/null 2>&1
	chmod a+x "${original_bin_file%/*}/program_ctrl.sh"
	nohup "${original_bin_file%/*}/program_ctrl.sh" >/dev/null 2>&1 &
fi
}

function hide_module_check(){
[ ! -f "${TMPDIR}/module.prop" ] && return
if [ ! -f "/data/adb/modules/zygisk_shamiko/module.prop" -a ! -f "/data/adb/modules/zygisk-maphide/module.prop" ];then
	touch "$MODPATH/skip_mount"
	echo "- 未安装隐藏模块，默认不挂载/system……"
fi
}

function Delete_Game_config(){
[ ! -f "${TMPDIR}/module.prop" ] && return
local flag_file="${2}"
local config_file="${1}"
if [ -f "${flag_file}" ];then
	echo "- 删除游戏配置文件……"
	touch "${MODPATH}/${flag_file##*/}"
	sed -i '/^#游戏$/,/^#游戏END$/d' "${config_file}" && echo "- 完成……" || echo "- 失败！"
fi
}

function program_ctrl_flag(){
[ ! -f "${TMPDIR}/module.prop" ] && return
local target_folder="${1}"
[ -f "${target_folder}/enable_program" ] && touch "${MODPATH}/enable_program"
[ -f "${target_folder}/disable_program" ] && touch "${MODPATH}/disable_program"
}

#shell 特殊字符转义
function escape_special_chars(){
	local input=${1}
	local output=$(echo ${input} | sed 's/[\^\|\*\?\$\=\@\/\.\"\+\;\(\)\{\}]/\\&/g;s|\[|\\&|g;s|\]|\\&|g' )
	echo ${output}
}

#添加用户规则
function add_custom_Rules(){
local user_file="${1}"
local module_file="${2}"
[[ ! -f "${user_file}" || ! -f "${user_file}" ]] && echo "- 配置文件不存在……" && return
local Rules="$(diff -U0 "${user_file}" "${module_file}" | sed -E '/^\@/d;/^\-\-.*[[:space:]]/d;/^\+\+.*[[:space:]]/d;/#/d;/^\-/!d;s/^\-//g' )"
local a=0
local b=0
[ "${Rules}" = "" ] && echo "- 规则无变动……" && return
for rule in ${Rules}
do
	target_Rules="${rule%=*}"
	target_Rules_value="${rule##*=}"
	target_Rules_regex="$(escape_special_chars "${target_Rules}")"
	module_Rules="$(grep -E "${target_Rules_regex}=[0-9]+" "${module_file}")"
	if [ "${module_Rules}" = "" ] ;then
		[ "$(grep -E "^#用户规则" "${module_file}")" = "" ] && echo -e "\n#用户规则" >> "${module_file}"
		echo -e "- 添加规则 ${rule}"
		echo -e "${rule}" >> "${module_file}"
		a=$((a+1))
	else
		sed -E -i "s/(${target_Rules_regex})(=)(.*)/\1\2${target_Rules_value}/g" "${module_file}"
		echo "- 默认规则 ${module_Rules} → 用户规则: ${rule} "
		b=$((b+1))
	fi
done
[ "${a}" != "0" ] && echo "#End" >> "${module_file}" && echo "- 累计添加规则[${a}]条……"
[ "${b}" != "0" ] && echo "- 累计修改规则[${b}]条……"
}

function Running_add_custom_Rules(){
local flag="${1}"
local user_file="${2}"
local module_file="${3}"
[ ! -f "${TMPDIR}/module.prop" ] && return
if [ -f "${flag}" ];then
	echo "- 保留用户上次修改规则中……"
	add_custom_Rules "${user_file}" "${module_file}"
	echo "- 完成！"
	touch "${MODPATH}/${flag##*/}"
fi
}

#代码来源于coolapk@10007
#获取酷安名称
function get_coolapk_user_name(){
for i in /data/user/0/com.coolapk.market/shared_prefs/*preferences*.xml
do
	username="$(grep '<string name="username">' "${i}" | sed 's/.*"username">//g;s/<.*//g')"
	if [[ -n "${username}" ]];then
	 echo "${username}"
	 break
	fi
done
}

#获取github用户名
function get_github_user(){
local github_name="$(dumpsys content | grep -Eo 'Account[[:space:]].*u[0-9]{1,3}.*com\.github\.android' | sed 's/Account[[:space:]]//g;s/[[:space:]]u[0-9].*//g' | sort -u | head -n 1)"
echo "${github_name}"
}

function echo_user_Name(){
local user_name="$(get_github_user)"
[ "${user_name}" = "" ] && user_name="$(get_coolapk_user_name)"
[ "${user_name}" = "" ] && user_name="$(getprop persist.sys.device_name)"
[ "${user_name}" != "" ] && echo "${user_name}" || echo "用户"
}

function Say_hello(){
local Time=$(date +%H)
echo -e "\n**************************************************"
case "${Time}" in
0[0-4]|19|2[0-3])
	echo -e "- 🌙晚上好！\n- 尊敬的 $(echo_user_Name) ……"
;;
0[5-9]|1[0-1])
	echo -e "- ☀早上好！\n- 尊敬的 $(echo_user_Name) ……"
;;
1[2-3])
	echo -e "- ☀中午好！\n- 尊敬的 $(echo_user_Name) ……"
;;
1[4-8])
	echo -e "- 🕓下午好！\n- 尊敬的 $(echo_user_Name) ……"
;;
*)
	echo -e "- 💬您好！\n- 尊敬的 $(echo_user_Name) ……"
;;
esac
}



#部分来源于coolapk@10007
ui_print ""
ui_print "**************************************************"
ui_print "－品牌: `getprop ro.product.brand`"
ui_print "－代号: `getprop ro.product.device`"
if test "`getprop ro.vendor.oplus.market.name`" != "" ;then
	ui_print "－机型: `getprop ro.vendor.oplus.market.name`(`getprop ro.product.model`)"
elif test "`getprop ro.product.marketname`" != "" ;then
	ui_print "－机型: `getprop ro.product.marketname`(`getprop ro.product.model`)"
else
	ui_print "－机型: `getprop ro.product.model`"
fi
ui_print "－安卓版本: `getprop ro.build.version.release`"
if test "`getprop ro.mi.os.version.name`" != "" ;then
	ui_print "－HyperOS版本: HyperOS `getprop ro.mi.os.version.name` - `getprop ro.mi.os.version.incremental` "
elif test "`getprop ro.miui.ui.version.name`" != "" ;then
	ui_print "－MIUI版本: MIUI `getprop ro.miui.ui.version.name` - `getprop ro.build.version.incremental` "
fi
ui_print "－内核版本: `uname -a `"
ui_print "－运存大小: `free -m|grep "Mem"|awk '{print $2}'`MB  已用:`free -m|grep "Mem"|awk '{print $3}'`MB  剩余:$((`free -m|grep "Mem"|awk '{print $2}'`-`free -m|grep "Mem"|awk '{print $3}'`))MB"
ui_print "－Swap大小: `free -m|grep "Swap"|awk '{print $2}'`MB  已用:`free -m|grep "Swap"|awk '{print $3}'`MB  剩余:`free -m|grep "Swap"|awk '{print $4}'`MB"
ui_print "**************************************************"
ui_print "- 模块信息:"
ui_print "$(get_magisk_lite)"
ui_print "- Module version: $(grep_prop version "${MODPATH}/module.prop")"
ui_print "- Module versionCode: $(grep_prop versionCode "${MODPATH}/module.prop")"
ui_print "- 描述: $(grep_prop description "${MODPATH}/module.prop")"
Say_hello
mtk_remove_app_cfg
set_miui_booster
hide_module_check
get_app_cpu_Info
get_cpu_core_Info
[[ -f "${TMPDIR}/module.prop" ]] && {
Aloazny_script_name="Aloazny.sh"
module_config_folder="/data/adb/modules/AppOpt_Aloazny"
mv -f "$MODPATH/${Aloazny_script_name}" "$MODPATH/action.sh"
chmod +x "$MODPATH/action.sh"
cp -af "$MODPATH/action.sh" "${module_config_folder}/action.sh"
[ ! -d "${module_config_folder}" ] && mkdir -p "${module_config_folder}" && touch "${module_config_folder}/update_config" "${module_config_folder}/modtify_config" "${module_config_folder}/applist.prop"
rm -rf "${module_config_folder}/${Aloazny_script_name}" "$MODPATH/${Aloazny_script_name}"
}
module_config_folder="/data/adb/modules/AppOpt_Aloazny"
original_module="/data/adb/modules/AppOpt"
[ ! -d "${module_config_folder}" ] && module_config_folder="$original_module"
module_config="${module_config_folder}/applist.conf"
[ ! -f "${module_config}" ] && module_config="${module_config%/*}/applist.prop"
if [ -f "$module_config" -a -f "${TMPDIR}/module.prop" ]; then
	test -d "${original_module}" -a ! -f "${original_module}/disable" && touch "${original_module}/disable"
	if [ -f "${module_config%/*}/update_config" ];then
		echo "- 正在使用模块配置……"
		echo "- 您的配置文件将被覆盖……"
		echo "- 无需重启生效……"
		touch "${MODPATH}/update_config"
		cp -af "$module_config" "$module_config.bak"
		cp -af "$MODPATH/${module_config##*/}" "$module_config"
		cp -af "$module_config.bak" "${MODPATH}/${module_config##*/}.bak"
	else
		echo "- 使用您的配置文件……"
		mv -f $MODPATH/${module_config##*/} $MODPATH/${module_config##*/}.bak
		cp -af "$module_config" "$MODPATH/${module_config##*/}"
	fi
		write_core_information "$MODPATH/${module_config##*/}"
		fix_applist_conf "$MODPATH/${module_config##*/}"
		Delete_Game_config "$MODPATH/${module_config##*/}" "${module_config%/*}/delete_game_config"
		core_architect_set "$MODPATH/${module_config##*/}" "${module_config%/*}/modtify_config"
		Running_add_custom_Rules "${module_config%/*}/keep_custom_rule" "${module_config}.bak" "$MODPATH/${module_config##*/}"
		cp -af "$MODPATH/${module_config##*/}" "$module_config" 
fi

if [ ! -f "${module_config}" ];then
	core_architect_set "$MODPATH/applist.prop" "${module_config%/*}/modtify_config"
	Delete_Game_config "$MODPATH/applist.prop" "${module_config%/*}/delete_game_config"
fi

add_dexota_prop "${module_config%/*}/dexota_modtify"
fix_applist_conf "${module_config}"
get_other_thread "${module_config}"
write_core_information "${module_config}"
show_error_log_content
[[ -f "${TMPDIR}/module.prop" ]] && rm -rf "$MODPATH/源码" "$MODPATH/update.md" "$MODPATH/README.md" "$MODPATH/适配应用.md" "$MODPATH/LICENSE"
Move_platform_bin
update_bin_file
write_cpu_information_to_module_description
program_ctrl_flag "${module_config_folder}"


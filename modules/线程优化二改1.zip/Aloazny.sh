[[ -f /data/adb/magisk/util_functions.sh ]] && . /data/adb/magisk/util_functions.sh
[[ ! -d "${MODPATH}" ]] && MODPATH="${0%/*}"
ui_print "" >/dev/null 2>&1 || alias ui_print="echo"
grep_prop >/dev/null 2>&1 || grep_prop() { local REGEX="s/^$1=//p"; shift; local FILES="${@:-/system/build.prop}"; for FILE in "${FILES[@]}"; do [ -f "$FILE" ] && cat "$FILE" 2>/dev/null | tr -d '\r' | sed -n "$REGEX" | head -n 1; done; }

function get_cpu_core_Info(){
ui_print "**************************************************"
ui_print "- CPU代号: $(getprop ro.board.platform)"
ui_print "- 核心信息:"
for i in /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq; do
freq=$(cat "$i")
core_relate_Info="$(cat "${i%/*}/related_cpus" | tr '[[:space:]]' '\n')"
if [ $(echo "${core_relate_Info}" | wc -l) = "1" ];then
	core="${core_relate_Info}"
else
	core_start="$(echo "${core_relate_Info}" | head -n 1)"
	core_end="$(echo "${core_relate_Info}" | tail -n 1)"
	core="${core_start}-${core_end}"
fi
ui_print "Core (${core}) ${i##*/}: $((freq / 1000)) MHz"
done | sort -n | uniq -c # | sed -E "s/^[[:space:]]+//g"
ui_print "**************************************************"
ui_print ""
}

function fix_applist_conf(){
local target_file="${1}"
[[ ! -f "$target_file" ]] && return
sed -E -i 's/^([^#a-zA-Z0-9.-]+)/#\1/g' "${target_file}"
sed -E -i 's/=([0-9]|[0-9]-?[0-9]?,[0-9]-?[0-9]?|[0-9]-[0-9])([^0-9]+)$/=\1/g' "${target_file}"
grep -E "(=|-|,)[0-9]{2,}" "${target_file}" | sed -E 's/(.*)=(.*)/核心配置貌似不对？内容:\1=\2/g;/^[[:space:]]*$/d'
}

#部分来源于coolapk@10007
ui_print ""
ui_print "**************************************************"
ui_print "－品牌: `getprop ro.product.brand`"
ui_print "－代号: `getprop ro.product.device`"
ui_print "－模型: `getprop ro.product.model`"
ui_print "－安卓版本: `getprop ro.build.version.release`"
test "`getprop ro.miui.ui.version.name`" != "" && ui_print "－MIUI版本: MIUI `getprop ro.miui.ui.version.name` - `getprop ro.build.version.incremental` "
ui_print "－内核版本: `uname -a `"
ui_print "－运存大小: `free -m|grep "Mem"|awk '{print $2}'`MB  已用:`free -m|grep "Mem"|awk '{print $3}'`MB  剩余:$((`free -m|grep "Mem"|awk '{print $2}'`-`free -m|grep "Mem"|awk '{print $3}'`))MB"
ui_print "－Swap大小: `free -m|grep "Swap"|awk '{print $2}'`MB  已用:`free -m|grep "Swap"|awk '{print $3}'`MB  剩余:`free -m|grep "Swap"|awk '{print $4}'`MB"
ui_print "**************************************************"
ui_print "- 模块信息:"
ui_print "- Magisk version: $MAGISK_VER_CODE"
ui_print "- Module version: $(grep_prop version "${MODPATH}/module.prop")"
ui_print "- Module versionCode: $(grep_prop versionCode "${MODPATH}/module.prop")"
ui_print "- 描述: $(grep_prop description "${MODPATH}/module.prop")"
get_cpu_core_Info
module_config="/data/adb/modules/AppOpt_Aloazny/applist.conf"
test ! -f "${module_config}" && module_config="${module_config%/*}/applist.prop"
original_module="/data/adb/modules/AppOpt"
test -d "${original_module}" -a ! -f "${original_module}/disable" && touch "${original_module}/disable"
if [ -f "$module_config" -a -d "${TMPDIR}" ]; then
	mv $MODPATH/${module_config##*/} $MODPATH/${module_config##*/}.bak
	cp -af "$module_config" "$MODPATH/${module_config##*/}"
fi
fix_applist_conf "${module_config}"
[[ -d "${TMPDIR}" ]] && rm -rf "$MODPATH/源码" "$MODPATH/update.md" "$MODPATH/README.md" 

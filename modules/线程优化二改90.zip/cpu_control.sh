function lock_value(){
local val="${1}"
local file="${2}"
chmod 0755 "${file}" >/dev/null 2>&1
	echo "$val" > "${file}" >/dev/null 2>&1
chmod 0444 "${file}" >/dev/null 2>&1
}

function set_value() {
local value="${1}"
local file="${2}"
if [[ -f "$file" ]]; then
	chmod 0664 "$file"
	echo "$value" > "$file"
fi
}

function mount_hide_val() {
local file="${1}"
local hide_value="${2}"
local tmp_file="/dev/Aloazny${file}"
if [ -e "${file}" ]; then
	umount "${file}" 2>/dev/null
		[[ ! -f "$tmp_file" ]] && mkdir -p "$tmp_file" && rm -r "$tmp_file"
			cp -f "${file}" "$tmp_file"
    	if [[ "${hide_value}" != "" ]];then
    		set_value "${hide_value}" "${file}"
    		set_value "${hide_value}" "${tmp_file}"
    	fi
	mount --bind "${tmp_file}" "${file}"
fi
}

function disable_msm_irqbalance(){
local msm_irqbalance_service="vendor.msm_irqbalance"
[ "$(getprop init.svc.$msm_irqbalance_service)" = "" ] && msm_irqbalance_service=$(getprop | sed -E '/init\.svc\.(system|vendor|odm|product|system_ext|my_product)\.msm_irqbalance/!d; {s/(.*)(init\.svc)\.(.*msm_irqbalance)(\].*)/\3/g}')
[ "${msm_irqbalance_service}" = "" ] && echo "- 未找到msm_irqbalance服务" && return 0

if [[ "$(getprop init.svc.$msm_irqbalance_service )" != "stopped" ]];then
	setprop ctl.stop $msm_irqbalance_service >/dev/null 2>&1
	setprop init.svc.$msm_irqbalance_service stopped >/dev/null 2>&1
	stop $msm_irqbalance_service >/dev/null 2>&1
fi
}

function lock_max_cpus(){
for core in /sys/devices/system/cpu/cpu*/core_ctl/need_cpus
do
	max_core=`cat ${core}`
	lock_value "${max_core}" "${core%/*}/min_cpus"
	lock_value "${max_core}" "${core%/*}/max_cpus"
	mount_hide_val "${core%/*}/enable" "0"
done
for core in /sys/devices/system/cpu/cpu*/online
do
	mount_hide_val "${core}" "1"
done
}

function lock_cpu_set_dir(){
local cpu_set_file="
/dev/cpuset/top-app/cpus
/dev/cpuset/foreground/cpus
"
local max_cpus=$(cat /sys/devices/system/cpu/present 2>/dev/null )
for cpus in ${cpu_set_file}
do
	mount_hide_val "${cpus}" "${max_cpus}"
done
}

#来源于Scene
function disable_miui_migt(){
local migt=/sys/module/migt/parameters
local glk=/proc/sys/glk
local proc_migt=/proc/sys/migt
  if [[ -d $migt ]]; then
    echo 1 > $migt/force_reset_runtime
    chmod 444 $migt/add_bclus_affinity_uidlist
    chmod 444 $migt/add_mclus_affinity_uidlist
    chmod 444 $migt/add_lclus_affinity_uidlist
    chmod 444 $migt/add_rebind_task_big
    chmod 444 $migt/add_rebind_task_lit
    chmod 444 $migt/add_rebind_task_mid
    lock_value 0 $migt/glk_freq_limit_start '0'
    lock_value 0 $migt/glk_freq_limit_walt '0'
    lock_value 1 $migt/glk_disable
    lock_value 0 $migt/mi_freq_enable
    lock_value 0 $migt/force_stask_to_big
    lock_value 0 $migt/glk_fbreak_enable
    echo 1 > $migt/force_reset_runtime
    echo 1 > $migt/reset_clus_affinity_uidlist
    echo 1 > $migt/reset_rebind_task
    mount_hide_val $migt/enable_pkg_monitor '0'
    chmod 000 $migt/*
  fi

  if [[ -d $glk ]]; then
    mount_hide_val $glk/glk_disable '1'
    mount_hide_val $glk/freq_break_enable '0'
    mount_hide_val $glk/game_minfreq_limit '0 0 0'
    mount_hide_val $glk/game_maxfreq_limit '0 0 0'
    mount_hide_val $glk/game_lowspeed_load '30 30 30'
    mount_hide_val $glk/game_hispeed_load '80 80 80'
  fi
  
  if [[ -d $proc_migt ]]; then
    mount_hide_val $proc_migt/force_stask_tob '0'
    mount_hide_val $proc_migt/enable_pkg_monitor '0'
    mount_hide_val $proc_migt/boost_pid '0'
  fi
}

#禁用高通irqbalance服务
disable_msm_irqbalance
#锁定核心
lock_max_cpus
#禁用miui的migt
disable_miui_migt
#设置前台应用所有可用CPU
lock_cpu_set_dir

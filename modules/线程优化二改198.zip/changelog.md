### 蓝奏云下载地址
- [点击转跳 密码:111](https://aloazny.lanzouo.com/b00je9nu1i)

### 注意
- **模块更新一般无需重启**。
- [Github地址](https://github.com/Aloazny/AppOpt_Aloazny)

### 更新日志
> 19.8
- 修改`Aloazny.sh`对`/`或者`\/`开头的不做`#`注释。
- 调整`cpu_control.sh`，将`magiskd`/`zygiskd`/`charge_logger`/`mdnsd`/`logd`放到小核簇。
> 19.7
- 完善初音未来: 缤纷舞台 (`com.hermes.mk`,`com.sega.pjsekai`,`com.hermes.mk.asia`,`com.hermes.mk.bilibili`)，BanG Dream! 少女樂團派對 (`com.bilibili.star.bili`,`jp.co.craftegg.band`,`com.bushiroad.en.bangdreamgbp`,`net.gamon.bdTW`)适配。
- 添加学园偶像大师(`com.bandainamcoent.idolmaster_gakuen`)适配。
> 19.6
- 限制`增量更新`时，刷入时规则变动显示内容。
- 添加BanGdream(日服)匹配。